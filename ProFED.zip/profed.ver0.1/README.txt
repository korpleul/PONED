Installation Instructions
=========================

1) The RShiny application requires Shiny Server to be installed on the local system.
    https://www.rstudio.com/products/shiny/download-server/
    Refer to the above link on how to install it.
    
2) Installing RStudio might be helpful incase one wants to develop this software
    https://www.rstudio.com/products/rstudio/download/
    
    Visit the above link to download the software.

3) This package requires that you have R Statistical Software
    https://www.r-project.org/
    Refer to the above link on how to install R for your respective operating system.

4) The application depends on the following R packages. It is required to install all of them.
    shiny, shinyBS, shinyjs, DT, ggplot2, rmarkdown, markdown, knitr, googleCharts,
    dplyr, scales, pheatmap, RColorBrewer

5) Place the unzipped folder at the following location.
    /srv/shiny-server/
    
6) Restart the shiny server
    sudo service shiny-server restart
    
7) The ProFED app should now be available at 
    http://127.0.0.1:3838/profed.ver0.1
