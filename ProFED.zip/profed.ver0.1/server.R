# Author: Nikhil Vinod Mallela
# Copyright: 2016,2017 Institute of Bioinformatics, University of Muenster
# License : GNU GPLv3

library(shinyBS)

function(input, output, session) {

  # Load all the core functions
  source("countdata_diagPlot_functions.R")
  source("countdata_helper_functions.R")
  source("countdata_normalization_functions.R")

  
  #### global variables ####
  # to keep track if the data is loaded via the checkbox and reset accordingly
  

  # reactive variables
    values <- reactiveValues()
    values$inFile = NULL
    values$load.example = FALSE
    values$data.org = data.frame()
    values$data.uploaded = FALSE
    # analyse tab
    values$anno_cols = character()
    values$anno_cols_extra = character()
    values$use.means = TRUE
    values$normalize = character()
    values$show.design_image = TRUE
    values$next_button.count = 1
    values$logfc.list = list() # reactive variable meant for consistent data exchange.
    values$hit.table.abc = data.frame()
    values$hit.table.d = data.frame()
    values$sample.list = list() 
    values$d.computable = FALSE
    values$abc.computable = FALSE
    values$dont.exp.plot = FALSE
    values$data.abc = data.frame()
    values$g.scatterchart = FALSE
    
    # initial disables
    shinyjs::disable("import_add_plus_one")

  #### IMPORT: tab.import.table ####
  output$tab.import.table <- DT::renderDataTable({
    
    # input$file1 will be NULL initially. After the user selects
    # and uploads a file, it will be a data frame with 'name',
    # 'size', 'type', and 'datapath' columns. The 'datapath'
    # column will contain the local filenames where the data can
    # be found.

    inFile <- input$file1
    values$inFile = inFile
    
    if (is.null(inFile)) {
      return(NULL)
    } else {
      # disable the load example check box and inform below the checkbox
      shinyjs::disable("load.example")
      output$load.example.info <- renderUI({ helpText("This button is now disabled for caution. 
                                                      If you want to see an example execution, reload the page and check this button.
                                                      'Hard Reload' is the best option to clear the browser cache. Press Ctrl+F5 in Chrome or Firefox.")})
      
  #     data.org <- read.csv(inFile$datapath, header=input$header, sep=input$sep, 
  # 			 quote=input$quote, stringsAsFactors = FALSE)

      data.org <- read.csv(inFile$datapath, stringsAsFactors = FALSE)

      # # zero counts create a problem. eg. 0/248 = -Inf
      # # especially during the logfold change calculation
      # # NOTE:!! (data.org+1) converts the columns with "string" to NA
      # 
      # for(i in 1:dim(data.org)[2]) {
      #   if(class(data.org[[i]])=="integer") {
      #     data.org[[i]] <- (data.org[[i]]+1)
      #     class(data.org[[i]]) = "integer"
      #     # after adding the +1, the class of the column changes from `int` to `num`
      #   }
      #   if(class(data.org[[i]])=="numeric") {
      #     data.org[[i]] <- (data.org[[i]]+1)
      #     class(data.org[[i]]) = "numeric"
      #     # after adding the +1, the class of the column changes from `int` to `num`
      #   }          
      # }
      
      # feed it to the reactive variable.
      values$data.org <- data.org
      values$data.uploaded <- TRUE
      func_add_plus_one(import_add_plus_one=TRUE, data.org=data.org )
      shinyjs::enable("import_add_plus_one")  # enable after the data is uploaded.
      
     # Import Panel
      updateCheckboxInput(session, 'import_add_plus_one', value = TRUE)
      
     # Annotate Panel
      updateSelectInput(session,'anno_cols', choices = colnames(data.org))
      updateSelectizeInput(session,'anno_cols_extra', choices = colnames(data.org))
      updateSelectizeInput(session,'input_ctrl', choices = colnames(data.org))
      updateSelectizeInput(session,'ctrl_a', choices = colnames(data.org))
      updateSelectizeInput(session,'select_a', choices = colnames(data.org))
      updateSelectizeInput(session,'ctrl_b', choices = colnames(data.org))
      updateSelectizeInput(session,'select_b', choices = colnames(data.org))
      updateSelectInput(session, 'normalize')
      updateCheckboxInput(session, 'use.means', value=TRUE)
       
    # Data Exploration Panel
      updateSelectInput(session, 'exp_normalize')
      updateSelectInput(session, 'annotate_plot', choices = c("None"="",colnames(data.org)))
      updateSelectizeInput(session, 'scatter_pairwise_input_cols', choices = colnames(data.org))
      updateSelectizeInput(session, 'scatter_matrix_input_cols', choices = colnames(data.org))
      updateSelectizeInput(session, 'boxplot_input_cols', choices = colnames(data.org))
      updateCheckboxInput(session, 'remove.max.value', value = TRUE )
      updateSelectInput(session, 'fit.line', selected = c("lmFit"))      
      
    }

    DT::datatable(data.org)
    
  })

    
    
  
  #### headmsg: import-tab #### 
  output$tab.import.datauploaded <- renderText({
    inFile <- values$inFile
    
    if(is.null(inFile)){
      paste('You will see your data here, after you have uploaded it.')
    } else {
      paste('If your uploaded data is looking right, proceed to the next tab to analyse your data.')
    }
      
  })


     
  #### headmsg: annotate-tab ####
  output$tab.annotate.datauploaded <- renderText({
    inFile <- values$inFile
    
    if(is.null(inFile)){
      paste('Visit this panel after you have uploaded your data.')
    } else {
      paste('Please annotate the your data according to the design below.')  
    }
    
  })
    
    
    
      
  
#### observe: LOAD EXAMPLE ####
  # on the event of checking the load.example checkbox
observeEvent(input$load.example, {
    if(input$load.example == TRUE){
          # feed this value to the reactive variable for conditional computation in the analyze()
          values$load.example = TRUE
      
          # disable the other upload options
            shinyjs::disable("file1")           
            shinyjs::disable("header")
            shinyjs::disable("sep")
            shinyjs::disable("quote")
            shinyjs::disable("load.example")

          # reset some stuff in case the user is messing around before loading the example
            output$anno_form_feedback <- renderText({paste("")})

          # tell the users that they have to freshly load the page
            showModal (modalDialog(
              title = "Important message",
              "You have chosen to see an example.
              As a caution, all other uploading features are disabled.
              If you want to work with your own data, freshly reload the page and upload it.
              You can now proceed to view the example execution.
              'Hard Reload' is the best option to clear the browser cache. Press Ctrl+F5 in Chrome or Firefox.",
              easyClose = TRUE
            ))
            
          # set the above message also in the header   
            output$tab.import.datauploaded <- renderText({
                paste(
"You have chosen to see an example. 
As a caution, all other uploading features are disabled. 
If you want to work with your own data, freshly reload the page and upload it.
'Hard Reload' is the best option to clear the browser cache. Press Ctrl+F5 in Chrome or Firefox.
Refer to the Help section for more information.")
            })
          
          # Create a Progress object
            progress <- shiny::Progress$new()
          # Make sure it closes when we exit this reactiv, even if there's an error
            on.exit(progress$close())
          # set a progress message
            progress$set(message = "Data Display", detail = "loading data ...",value=50)
                      

          data.org <- read.csv("raw_counts_unscrambled_hek_labels.csv", stringsAsFactors = FALSE)
          
          # add +1 to the dataset of numerical or integer columns
          func_add_plus_one(import_add_plus_one=TRUE, data.org=data.org )
          data.org <- values$data.org
  
          values$data.uploaded <- TRUE
          shinyjs::enable("import_add_plus_one") # enable after the data is uploaded.
          

          # progress::
          progress$set(detail = "rendering data ...",value=75)
  


          # Analyze Panel

            # == Ver0.3 data names ==#
            updateSelectInput(session,'anno_cols', choices = colnames(data.org), selected = c("Vendor.Clone.Id"))
            updateSelectInput(session,'anno_cols_extra', choices = colnames(data.org), selected = c("Gene.Symbol"))
            updateSelectizeInput(session,'input_ctrl', choices = colnames(data.org), selected = c("decode_ctrl_r1", "decode_ctrl_r2"))
            updateSelectizeInput(session,'ctrl_a', choices=colnames(data.org), selected = c("ctrl_a_r1", "ctrl_a_r2"))
            updateSelectizeInput(session,'select_a', choices=colnames(data.org), selected = c("exp_a_r1", "exp_a_r2") )
            updateSelectizeInput(session,'ctrl_b', choices=colnames(data.org), selected = c("ctrl_b_r1", "ctrl_b_r2"))
            updateSelectizeInput(session,'select_b', choices=colnames(data.org), selected = c("exp_b_r1", "exp_b_r2"))
            updateNumericInput(session, 'ctrlfilter', value = 50)
            updateSelectInput(session, 'normalize', selected = c("TMM"))
            updateCheckboxInput(session, 'use.means', value=TRUE)   
            
            # Exploration Panel
             #== Ver0.3 data names ==#          
            updateSelectInput(session, 'annotate_plot', choices = c("None"="",colnames(data.org)), selected = c("Vendor.Clone.Id"))
            updateSelectizeInput(session, 'scatter_pairwise_input_cols', choices = colnames(data.org), selected = c("decode_ctrl_r1", "decode_ctrl_r2"))
            updateSelectizeInput(session, 'scatter_matrix_input_cols', choices = colnames(data.org), selected = c("ctrl_b_r1", "ctrl_b_r2", "exp_b_r1", "exp_b_r2"))
            updateSelectizeInput(session, 'boxplot_input_cols', choices = colnames(data.org), selected = c("decode_ctrl_r1", "decode_ctrl_r2",
                                                                                                           "ctrl_b_r1", "ctrl_b_r2", "exp_b_r1", "exp_b_r2",
                                                                                                           "ctrl_a_r1", "ctrl_a_r2", "exp_a_r1", "exp_a_r2"))

            updateSelectInput(session, 'exp_normalize', selected = c("TMM"))
            updateCheckboxInput(session, 'remove.max.value', value = TRUE )
            updateSelectInput(session, 'fit.line', selected = "lmFit") 
            
                      

            # == Ver0.3 data names ==#
            # :: File = "raw_counts_unscrambled_hek_labels.csv"                        
            values$sample.list <-
            list(anno_cols = c("Vendor.Clone.Id"),
                 anno_cols_extra = c("Gene.Symbol"),
                 input_ctrl = c("decode_ctrl_r1", "decode_ctrl_r2"),
                 ctrl_a = c("ctrl_b_r1", "ctrl_b_r2"),
                 select_a = c("exp_b_r1", "exp_b_r2"),
                 ctrl_b = c("ctrl_a_r1", "ctrl_a_r2"),
                 select_b = c("exp_a_r1", "exp_a_r2"))

            
            values$anno_cols = values$sample.list$anno_cols
            values$anno_cols_extra = values$sample.list$anno_cols_extra
            values$use.means = TRUE
            values$normalize = "TMM"

            # compute numerical columns from the sample list for the sake of validation.
            sample.list <- values$sample.list
            numeric_cols <- unlist(sample.list[3:length(sample.list)])
                        
            # auto execute the analyze function "after" loading the sample.list reactive variable.
            # validate(
            #   need(is.null(analyze()) != TRUE, ""),
            #   need(any(unlist(data.org[,numeric_cols]) == 0) == FALSE, "")
            #   )

            analyze()
            
            # set this to false after the first computation.
            # otherwise, it takes the sample.list from the reactive variables.
            values$load.example = FALSE

    }    
})


  #### observe: +1 checked ####
  observeEvent(input$import_add_plus_one, { 
  # By default, the +1 will be added to the numerical data set.
  # But if they manually uncheck, we will subtract 1 from what we have added.
  # If they check it again, then we will add +1 from the dataset. and so on.

  # zero counts create a problem. eg. 0/248 = -Inf
  # especially during the logfold change calculation
  # NOTE:!! (data.org+1) converts the columns with "string" to NA

    if(values$data.uploaded == TRUE){ 
      # get data
        data.org <- values$data.org
    
        func_add_plus_one(import_add_plus_one=input$import_add_plus_one, data.org=data.org )
        
    }
  })    
  
  func_add_plus_one <- function(import_add_plus_one, data.org ) {
    #import_add_plus_one = logical
    #data.org = dataframe
        if(import_add_plus_one == TRUE){
            for(i in 1:dim(data.org)[2]) {
              if(class(data.org[[i]])=="integer") {
                data.org[[i]] <- (data.org[[i]]+1)
                class(data.org[[i]]) = "integer"
                # after adding the +1, the class of the column changes from `int` to `num`
              }
              if(class(data.org[[i]])=="numeric") {
                data.org[[i]] <- (data.org[[i]]+1)
                class(data.org[[i]]) = "numeric"
                # after adding the +1, the class of the column changes from `int` to `num`
              }          
            }
        } else if(import_add_plus_one == FALSE){
             for(i in 1:dim(data.org)[2]) {
              if(class(data.org[[i]])=="integer") {
                data.org[[i]] <- (data.org[[i]]-1)
                class(data.org[[i]]) = "integer"
                # after adding the +1, the class of the column changes from `int` to `num`
              }
              if(class(data.org[[i]])=="numeric") {
                data.org[[i]] <- (data.org[[i]]-1)
                class(data.org[[i]]) = "numeric"
                # after adding the +1, the class of the column changes from `int` to `num`
              }          
            }     
        }  
        values$data.org <- data.org
        output$tab.import.table <- DT::renderDataTable({ DT::datatable(data.org, rownames=FALSE, selection = "none") })
  }    
  
  #### observe: analyse > submit ####
  # builds a reactive expression that only invalidates 
  # when the value of input$goButton becomes out of date 
  # (i.e., when the button is pressed)
  observeEvent(input$go_anno, {
    analyze()
  })
  
  #### observe: analyze > normalize  ####
  observeEvent(input$normalize, {
    # we are taking the slider values as a hint.
    # so, if the slider values are calculated, then
    # it means that the first run has already been made.
    # and that it just needs to be updated based on the selected "normalization"
    if(is.null(input$a_slide) == FALSE) {
      if(input$normalize != values$normalize) {
        # i.e if there is a change in the selection of normalization,
        # recompute
        analyze()
      }
    }
  })
  
  #### observe: analyze > use.means ####
  observeEvent(input$use.means, {
    # we are taking the slider values as a hint.
    # so, if the slider values are calculated, then
    # it means that the first run has already been made.
    # and that it just needs to be updated based on the "use.means" logical value changes

    if(is.null(input$a_slide) == FALSE) {
      if(input$use.means != values$use.means){
        # i.e if there is a change in the selection,
        # recompute
        analyze()
      }

    }
  })
    
  
  
  #### func: analyze() ####
  analyze <- function() {  
  # upon the submit, check if all the required data is filled up
  
    # Create a Progress object
      progress <- shiny::Progress$new()
    # Make sure it closes when we exit this reactiv, even if there's an error
      on.exit(progress$close())
    # set a progress message
      progress$set(message = "Analyzing", detail = "calculating log fold changes ...",value=50)
    
      
  # take the values from the ractive variable
    data.org = values$data.org
    
    
    if(values$load.example == TRUE & is.null(input$a_slide) == TRUE){
      # don't feed the reactive variables
      # because we already fed it in the load.example function.
      # therefore the values should be available.
    } else if(values$load.example == TRUE & is.null(input$a_slide) == FALSE) {
      # i.e after the results from the example is loaded, the user can tweak around other parameters
      values$anno_cols = input$anno_cols
      values$anno_cols_extra = input$anno_cols_extra
      values$use.means = input$use.means
      values$normalize = input$normalize
    } else {
      values$anno_cols = input$anno_cols
      values$anno_cols_extra = input$anno_cols_extra
      values$use.means = input$use.means
      values$normalize = input$normalize
    }
    
       
  # get the input list.  
    if(values$load.example == TRUE) {
      sample.list <- values$sample.list
    } else {
      sample.list <- get.sample.list() 
      values$sample.list = sample.list
    }

    # get all the non-annotation columns
    numeric_cols <- unlist(sample.list[3:length(sample.list)])
    if(any(unlist(data.org[,numeric_cols]) == 0) == TRUE) {
          createAlert(session, "analyse_alert", "deseq2_analyse_alert", title = "Oops",
           content = gsub("\n","",
                          paste0("Some of your data contains zero values.
                                  Zero values in the data set create a computational problem. eg. 0/248 = -Inf.
                                  Please go to the import tab and add +1 to your data set and then click the Submit button to update your results.
                                  ")
                          ), 
           append = FALSE)
           showModal (modalDialog(
              title = "Some of your data contains zero values.
                      Zero values in the data set create a computational problem. eg. 0/248 = -Inf.
                      Please go to the import tab and add +1 to your data set and then click the Submit button to update your results.",
              easyClose = TRUE
            ))      
      validate(
        need(any(unlist(data.org[,numeric_cols]) == 0) == FALSE, "")
      )
    }
    
  # check if all the data has been submitted
  # !!NOTE!! anno_cols_extra is not mandatory to have
  sample.unit.length <- unlist(lapply(sample.list[c("anno_cols","anno_cols_extra","input_ctrl","ctrl_a","select_a","ctrl_b","select_b")], length))
  
  
  # ::CHECK::
  # 4:7 are ctrl_a, select_a, ctrl_b, select_b
  if(all(sample.unit.length[4:7] == sample.unit.length[length(sample.unit.length)]) == TRUE) {
    # i.e if they are equal samples
    values$abc.computable = TRUE
    values$dont.exp.plot = FALSE
    output$anno_form_feedback <- renderText({ return(NULL) })

    
  } else {
    if(values$use.means == TRUE) {
      
      # then you can compute the stuff with means although you have unequal number of samples.
      values$abc.computable = TRUE
      values$dont.exp.plot = FALSE
      output$anno_form_feedback <- renderText({ return(NULL) })
 
    } else {
      
      # indicate the user to select the mean because you have unequal number of samples.
      output$anno_form_feedback <- renderText({ paste("You have unequal number of samples for non-optional fields.
                                                      Please perform the analysis with the mean counts (check box).") })
      # reset the analysis panel
        # this parameter should do it automatically.
      values$abc.computable = FALSE
      values$d.computable = FALSE
      values$dont.exp.plot = TRUE
      
    }
  }
  
  # 1. anno_cols
  # 2. anno_cols_extra
  # 3. input_ctrl
  # 4. ctrl_a
  # 5. select_a
  # 6. ctrl_b
  # 7. select_b

  # CHECK if D is computable.
    # execute the D check code only if abc.computable is TRUE
  if(values$abc.computable == TRUE) {
    if(all(sample.unit.length[c(3,4)])!=0) {
      # 1. calculate parameter D
      # 2. display the table
      # 3. if anno_cols_extra is available, integrate it.
      values$d.computable = TRUE
      output$anno_form_feedback <- renderText({ return(NULL) })
      
    } else {
      values$d.computable = FALSE
      # notify the user
      #output$anno_form_feedback <- renderText({paste("parameter 'D' will not be calculated without input_ctrl." ,sep = " ")})
      output$anno_form_feedback <- renderText({return(NULL)})
    } 
  }
  
  if(all(sample.unit.length[c(4,5,6,7)] !=0) && values$abc.computable == TRUE ) {
    # 1. calculate the #diff_table
    # 2. display the #diff_table
    #   a. if anno_cols_extra is available, integrate it
    # 3. display the expression plot
    

    

    # Annotate the Rows of the input data 
    if(any(duplicated(data.org[,as.character(values$anno_cols)]) == TRUE) != TRUE) {
      rownames(data.org) <- data.org[,as.character(values$anno_cols)]
    } else {
      output$anno_form_feedback <- renderText({paste("The annotation column you've selected does not contain unique elements." ,sep = " ")})      
      return(NULL)
    }
    
    # update the data.org after assigning the rownames
    values$data.org = data.org

    
    # calculate the foldchanges
    logfc.list <- foldchange_calculate(use.means = values$use.means, 
                                       normalize = values$normalize, 
                                       sample.list = sample.list)     
    
    # if logfc.list is NULL then, something is wrong.
    if(is.null(logfc.list) == TRUE) return(NULL)
    
    # this will 
    #   1. trigger the slider appearances.
    #   2. trigger the diff effect table appearance
    values$logfc.list <- logfc.list

    
    
    # while plot is being shown, toggle the design.
    if(values$show.design_image == TRUE) {
      values$show.design_image = FALSE
      toggle("show_design_image")
    }
    
        
   
    
  } 
}

  
  #### react: slider-UI ####
  output$sliderInputUI <- 
      renderUI({
  
        # take logfc from the reactive variable
        # NOTE: logfc.list also contains 'counts' dataframe
        logfc.list = values$logfc.list

        if(length(logfc.list)!=0 && values$abc.computable != FALSE ){
          
          # if the logfc.list is available, you can calculate the slider.range.list
          
          if(values$d.computable == FALSE) {
              slider.range.list = lapply(logfc.list[-which(names(logfc.list)%in%c("counts","par_d.list"))], function(x) unlist(x))
            } else {
              slider.range.list = lapply(logfc.list[-which(names(logfc.list)=="counts")], function(x) unlist(x))          
            }
          
          
          slider.range.list = lapply(slider.range.list, function(x) range(x))
          
          # ::BEFORE::
           # List of 5
           # $ par_a.list: num [1:2] -8.7 8
           # $ par_b.list: num [1:2] -7.98 3.55
           # $ par_c.list: num [1:2] -8.98 12.28
           # $ par_d.list: num [1:2] -6.99 7.62
           # $ par_e.list: num [1:2] -4.58 7.8
          
          slider.range.list = lapply(slider.range.list, function(x) return(c(floor(x[1]), ceiling(x[2]))))
          
          # ::AFTER::
          # List of 5
          #  $ par_a.list: num [1:2] -9 8
          #  $ par_b.list: num [1:2] -8 4
          #  $ par_c.list: num [1:2] -9 13
          #  $ par_d.list: num [1:2] -7 8
          #  $ par_e.list: num [1:2] -5 8
          
          # By using the "floor" for the first one and "ceiling" for the second,
          # We avoid missing any targets being filtered at the extremes.

          
          
    
          if(length(slider.range.list)!=0){
           return( 
             list(
               # The initial default slider values (the `value` variable) is set to c(max, min) of the data.
             helpText("numbers indicate the range of log fold change values per comparison"),
             sliderInput("a_slide", "A (log2FC exp_a/ctrl_a) ", min=slider.range.list$par_a.list[1], max =slider.range.list$par_a.list[2], step=0.5, value = c(slider.range.list$par_a.list[1], slider.range.list$par_a.list[2] )),
             sliderInput("b_slide", "B (log2FC exp_b/ctrl_b)", min=slider.range.list$par_b.list[1], max =slider.range.list$par_b.list[2], step=0.5, value = c(slider.range.list$par_b.list[1], slider.range.list$par_b.list[2] )),
             sliderInput("c_slide", "C (difference A minus B)", min=slider.range.list$par_c.list[1], max =slider.range.list$par_c.list[2], step=0.5, value = c(slider.range.list$par_c.list[1], slider.range.list$par_c.list[2] )),
             if(values$d.computable == TRUE) {
 #              list(
                #hr(),
                sliderInput("d_slide", "D (log2FC ctrl_a/input_ctrl)", min=slider.range.list$par_d.list[1], max =slider.range.list$par_d.list[2], step=0.5, value = c(slider.range.list$par_d.list[1], slider.range.list$par_d.list[2] ))
#                )
               } else {
                list(
                sliderInput("d_slide", "D (log2FC ctrl_a/input_ctrl)", min=0, max =0, step=0.5, value = c(0, 0)),
                renderUI(
                  addTooltip(session, id="d_slide", 
                             title = paste0("The Table D cannot be computed without the appropriate 
                                            samples in the input_ctrl field. The D input slider is 
                                            also disabled for this reason."),
                          "left", options = list(container = "body"))
                  )
                )
               },
             sliderInput("e_slide", "E (log2FC ctr_b/ctrl_a)", min=slider.range.list$par_e.list[1], max =slider.range.list$par_e.list[2], step=0.5, value = c(slider.range.list$par_e.list[1], slider.range.list$par_e.list[2] )),
             


             hr())
           )
          }

          
        } else {
            return(NULL)
          }
  })
  
  
  #### foldchange_calculate #### 
  foldchange_calculate <- function(use.means=FALSE, normalize=NULL, sample.list=sample.list) {

    validate(
      need(values$data.uploaded==TRUE, "")
    )
    
    # get the values from the reactive variable
    data.org = values$data.org
    use.means = use.means

    # sample.list = has the user selected columns
    
    # get all the non-annotation columns
    numeric_cols <- unlist(sample.list[3:length(sample.list)])

    # assign the phenoData for the normalization purposes
    phenoData <- data.frame(experiment=numeric_cols, condition=numeric_cols, label=numeric_cols, stringsAsFactors = FALSE)
    rownames(phenoData) <- as.character(phenoData$experiment)
   
    
    #!!
    # data.org[,phenoData$experiment] selects entirely different columns as opposed to 
    # data.org[,as.character(phenoData$experiment)]
    # because it seems to select with the factor levels !!
    # specify by column names as much as possible. !!

    if((any(is.integer(unlist(data.org[,numeric_cols])) == FALSE) == TRUE) & normalize != "None") {
         createAlert(session, "analyse_alert", "deseq2_analyse_alert", title = "Oops",
           content = paste0("DESeq2 and TMM are the RNASeq normalizations. 
                            They require integer data. Some of the selected samples have non-integers values."), 
           append = FALSE)
           showModal (modalDialog(
              title = "DESeq2 and TMM are the RNASeq normalizations. 
                       They require integer data. Some of the selected samples have non-integer values.",
              easyClose = TRUE
            ))      
        return(NULL)
    } else {
      
      if(normalize=="DESeq2") {
        closeAlert(session, "deseq2_analyse_alert")
        counts <- normalize.deseq2(counts=data.org[,numeric_cols], phenoData = phenoData)$normalized.counts
      } else if(normalize=="TMM") { 
        closeAlert(session, "deseq2_analyse_alert")
        counts <- normalize.edger(counts=data.org[,numeric_cols], phenoData = phenoData)$normalized.counts
      } 
      
    }
    
    if(normalize=="None") {
      closeAlert(session, "deseq2_analyse_alert")
      # use the raw counts if none specified.
      counts <- data.org[,numeric_cols]
    }
    
    

    # 1. if all the conditions have equal number of biological replicates,
    #     we go with logfold change calculation per "biological replicate set".
    #
    # 2. we go with the average counts and calculate the logFCs.
    #     a. if the user has choosen for it
    #     b. if there are unequal number of replicates for each condition (except input_ctrl)
    
    sample.unit.length <- unlist(lapply(sample.list[3:length(sample.list)], length))

    par_a.list <- list()
    par_b.list <- list()
    par_c.list <- list()
    
    par_d.list <- numeric()
    par_e.list <- list()

    # Block-B : ctrl_a, select_a, ctrl_b, select_b
    sample.unit.length.B <- sample.unit.length[c("ctrl_a","select_a","ctrl_b","select_b")]
    
    if(use.means == TRUE) {
      # then, compute the parameters on the mean counts
      if(all(sample.unit.length.B >= 1) == FALSE) {
        # i.e if one of the columns are not filled with the samples,
        # then inform the user
        output$anno_form_feedback <- renderText({paste("one of the non-optional fields are empty")})
      } else {
        par_a.list <- list(single= 
          log2(rowMeans(counts[,sample.list$select_a, drop=FALSE])/rowMeans(counts[,sample.list$ctrl_a, drop=FALSE])))
        
        par_b.list <- list(single=
          log2(rowMeans(counts[,sample.list$select_b, drop=FALSE])/rowMeans(counts[,sample.list$ctrl_b, drop=FALSE])))
        
        par_c.list <- list(single=
          (par_a.list[[1]]-par_b.list[[1]]))
        
        par_e.list <- list(single=
          log2(rowMeans(counts[,sample.list$ctrl_b, drop=FALSE])/rowMeans(counts[,sample.list$ctrl_a, drop=FALSE])))
  
        if(sample.unit.length["input_ctrl"]==0){
          # if the input controls are not given,
          # Do nothing.
        } else {            
              par_d.list <- list(single=
                  log2(rowMeans(counts[,sample.list$ctrl_a, drop=FALSE]) / rowMeans(counts[,sample.list$input_ctrl, drop=FALSE])))      
            }
    }
    return(list(
       par_a.list=par_a.list, par_b.list=par_b.list, 
       par_c.list=par_c.list, par_d.list=par_d.list,
       par_e.list=par_e.list, counts=counts)) 
      
      
      # 2. if use.means is unselected       
    } else {
      # then compute the paramters (log2FC) per "biological replicate set"
      
        # except input_ctrl, if all the conditions have equal number or replicates    
        if(all(sample.unit.length.B == sample.unit.length.B[length(sample.unit.length.B)]) == FALSE) {
          # then inform the user that ctrl_a, select_a, ctrl_b, select_b doesn't have equal number of replicates
          output$anno_form_feedback <- renderText({paste("You don't have equal number samples in the non-optional fields.
                                                         Click the checkbox to calculate with 'mean counts'")})
          return(NULL)
        } else {
          # if they are equal, 
          # then calculate log2FC per "biological replicate set"

          # > sample.unit.length
          # input_ctrl     ctrl_a   select_a     ctrl_b   select_b 
          #          0          2          2          2          2 
          #
          # In case such as above, 1:sample.unit.length[1] will fail.
          # Therefore, 1:sample.unit.length[2] is the safe.
     
          par_a.list <- lapply(1:sample.unit.length[2], function(x) 
            log2(counts[,sample.list$select_a[x]]/counts[,sample.list$ctrl_a[x]]))
          
          par_b.list <- lapply(1:sample.unit.length[2], function(x)
            log2(counts[,sample.list$select_b[x]]/counts[,sample.list$ctrl_b[x]]))
          
          par_c.list <- lapply(1:sample.unit.length[2], function(x)
            (par_a.list[[x]]-par_b.list[[x]]))
          
          par_e.list <- lapply(1:sample.unit.length[2], function(x)
            log2(counts[,sample.list$ctrl_b[x]]/counts[,sample.list$ctrl_a[x]]))
    
          
          # par_d is calculated differently from the other parameters.
          # 1. because, one might have many number of input controls
          # 2. they may not have any input controls at all.
          # 3. if they have input controls, they may not be of the same number of replicates 
          #     as the ctrl_a, select_a, ctrl_b, select_b
          #
          # Therefore, it is calculated this way:
          # 1. If there are equal number of biological technical replicates,
          #     par_d will be calculated per replicate.
          # 2. If there are unequal, par_d will be calculated with the mean counts of ctrl_a & input_ctrl
          
          
          # par_d : method 1 calculation : per replicate
          if(length(sample.list$input_ctrl) == sample.unit.length["ctrl_a"]) {
            par_d.list <- lapply(1:sample.unit.length[1], function(x)
              log2(counts[,sample.list$ctrl_a[x]]/counts[,sample.list$input_ctrl[x]]))
          } else {
          # par_d : inform the user that there are unequal replicates and that things can't be calculated by "mean"
            output$control.input.heading <- renderUI({HTML(paste("Unequal Replicates: Parameter d can't be calculated"))})
          }
          
        }      

    # run a recursive function to get the log fold change parameters on the mean of the counts.
    # this is done for the convinience sake, otherwise for for `n` number of replicates, 
    # one would generate `n` number of parameter a, parameter b, and parameter c.
    # its simply meaningless to put such a data in the output table.
    lfc.mean <- foldchange_calculate(use.means=TRUE, normalize=normalize, sample.list=sample.list)
      
    return(list(
           par_a.list=par_a.list, par_b.list=par_b.list, 
           par_c.list=par_c.list, par_d.list=par_d.list,
           par_e.list=par_e.list, counts=counts, lfc.mean = lfc.mean))      
    }
        
  }
  
  
  
  
  


    
get.result.table <- function(wanted, logfc.list) {
  
  # get the values from the reactive variable
  data.org = values$data.org
  
  # logfc.list also contains `counts` dataframe

  # reset the next_button counter after retriving the new data.
  values$next_button.count = 1
  
  # disable the previous button
  shinyjs::disable("previous_button")
  

  # convert the list of log fold changes to a dataframe  
  df.list <- lapply(logfc.list[c("par_a.list","par_b.list","par_c.list","par_d.list","par_e.list")], function(x)
    if(length(x)!=0){
      # if the parameter `d` is not calculated.
      # this code segment will throw an error.
      data.frame(
        matrix(unlist(x), nrow = dim(logfc.list$counts)[1], byrow = F),
           row.names=rownames(logfc.list$counts), 
        stringsAsFactors=FALSE)
      } else {
        return (NULL)
      }
  )    
 
  # ---- depreciated code of par_a, b, c, e, d calculated on the mean of the log folds ------#
  # # calculate the mean log fold changes to report in the final table.
  # df.list.mean <- lapply(df.list, function(x) rowMeans(x))
  # 
  # df.lfc.mean.abc <- data.frame("par_a" = df.list.mean$par_a.list,
  #                               "par_b" = df.list.mean$par_b.list,
  #                               "par_c" = df.list.mean$par_c.list,
  #                               stringsAsFactors = FALSE,
  #                               row.names = names(df.list.mean$par_a.list))
  # 
  # df.lfc.mean.e <- data.frame("par_e" = df.list.mean$par_e.list,
  #                             stringsAsFactors = FALSE,
  #                             row.names = names(df.list.mean$par_e.list))
  # 
  # if(length(df.list$par_d.list) !=0) {
  #   df.lfc.mean.d <- data.frame("par_d" = df.list.mean$par_d.list,
  #                               stringsAsFactors = FALSE,
  #                               row.names = names(df.list.mean$par_d.list))
  # }
  # 

    
  if(is.null(logfc.list$lfc.mean) == FALSE){
    # i.e if the mean data is computed, then it means, that the calculation
    # is computed "per replicate"
    
    df.lfc.mean.abc <- data.frame("par_a" = logfc.list$lfc.mean$par_a.list$single,
                                  "par_b" = logfc.list$lfc.mean$par_b.list$single,
                                  "par_c" = logfc.list$lfc.mean$par_c.list$single,
                                  "par_e" = logfc.list$lfc.mean$par_e.list$single,
                                  stringsAsFactors = FALSE,
                                  row.names = names(logfc.list$lfc.mean$par_a.list$single))
    
    # df.lfc.mean.e <- data.frame("par_e" = logfc.list$lfc.mean$par_e.list$single,
    #                             stringsAsFactors = FALSE,
    #                             row.names = names(logfc.list$lfc.mean$par_e.list$single))
    
    if(length(logfc.list$lfc.mean) != 0) {
      if(length(logfc.list$lfc.mean$par_d.list) !=0) {
        if(length(logfc.list$lfc.mean$par_d.list$single) !=0) {
          df.lfc.mean.d <- data.frame("par_d" = logfc.list$lfc.mean$par_d.list$single,
                                      stringsAsFactors = FALSE,
                                      row.names = names(logfc.list$lfc.mean$par_d.list$single))
        }
      }
    }
    # i.e when the logfc.list$lfc.mean is not found,
    # then it means that the calculation is computed on the "mean counts"
  } else {
    df.lfc.mean.abc <- data.frame("par_a" = logfc.list$par_a.list$single,
                                  "par_b" = logfc.list$par_b.list$single,
                                  "par_c" = logfc.list$par_c.list$single,
                                  "par_e" = logfc.list$par_e.list$single,
                                  stringsAsFactors = FALSE,
                                  row.names = names(logfc.list$par_a.list$single))
    
    # df.lfc.mean.e <- data.frame("par_e" = logfc.list$par_e.list$single,
    #                             stringsAsFactors = FALSE,
    #                             row.names = names(logfc.list$par_e.list$single))
    if(length(logfc.list$par_d.list) != 0){
      # Cause if $single is not present (calculated), then you'll get this error
      #   Error in $: $ operator is invalid for atomic vectors
      if(length(logfc.list$par_d.list$single) !=0) {
        df.lfc.mean.d <- data.frame("par_d" = logfc.list$par_d.list$single,
                                    stringsAsFactors = FALSE,
                                    row.names = names(logfc.list$par_d.list$single))
      }     
    }
  }
  
  
  
  if(wanted == "abc"){
    # which logfcs of `par_a` are within the slider limits ?
    par_a.ids <- rownames(logfc.list$counts) [
      apply(df.list$par_a.list,1, function(x) all(x>=input$a_slide[1] & x<=input$a_slide[2]))]
    
    par_b.ids <- rownames(logfc.list$counts) [
      apply(df.list$par_b.list,1, function(x) all(x>=input$b_slide[1] & x<=input$b_slide[2]))]  
  
    par_c.ids <- rownames(logfc.list$counts) [
      apply(df.list$par_c.list,1, function(x) all(x>=input$c_slide[1] & x<=input$c_slide[2]))] 
    
    par_e.ids <- rownames(logfc.list$counts) [
      apply(df.list$par_e.list,1, function(x) all(x>=input$e_slide[1] & x<=input$e_slide[2]))]
    
    
  diff.venids <- Reduce(intersect, list(par_a.ids,par_b.ids,par_c.ids,par_e.ids))
  hit.table.abc <- logfc.list$counts[diff.venids,]

  ### annotate result table ###
  if(length(values$anno_cols_extra)!=0) {
    anno.table.abc <- merge(data.org[,values$anno_cols_extra, drop=FALSE], 
                            df.lfc.mean.abc, by="row.names", all.y=TRUE, stringsAsFactors = FALSE)
    rownames(anno.table.abc) <- as.character(anno.table.abc$Row.names)
    anno.table.abc <- anno.table.abc[,-1]
    hit.table.abc <- merge(anno.table.abc, hit.table.abc, by="row.names", all.y=TRUE, stringsAsFactors = FALSE)
    colnames(hit.table.abc)[1] <- "anno_id"
  } else {
    anno.table.abc <- merge(data.org[, values$anno_cols, drop=FALSE],
                            df.lfc.mean.abc, 
                            by="row.names", all.y=TRUE, stringsAsFactors = FALSE)
    rownames(anno.table.abc) <- as.character(anno.table.abc$Row.names)
    anno.table.abc <- anno.table.abc[,-1]
    hit.table.abc <- merge(anno.table.abc, hit.table.abc, by="row.names", all.y=TRUE, stringsAsFactors = FALSE)
    hit.table.abc <- hit.table.abc[,-1]
    colnames(hit.table.abc)[1] <- "anno_id"  
  }
  
    # order by `par_c` i.e differential effect parameter.
  hit.table.abc <- hit.table.abc[order(hit.table.abc$par_c, decreasing=TRUE),]
  ###
  

  
  return(hit.table.abc)  
  }

 




  if(wanted == "d"){
    if(length(logfc.list$par_d.list)==0){
      return(NULL)
    } else {
    par_d.ids <- rownames(logfc.list$counts) [
      apply(df.list$par_d.list,1, function(x) all(x>=input$d_slide[1] & x<=input$d_slide[2]))]  

    hit.table.d <- logfc.list$counts[par_d.ids,]
    
    ### annotate result table ###
    if(length(values$anno_cols_extra)!=0) {
      # values$anno_cols_extra
      anno.table.d <- merge(data.org[,values$anno_cols_extra, drop=FALSE], 
                              df.lfc.mean.d, by="row.names", all.y=TRUE, stringsAsFactors = FALSE)
      rownames(anno.table.d) <- as.character(anno.table.d$Row.names)
      anno.table.d <- anno.table.d[,-1]
      hit.table.d <- merge(anno.table.d, hit.table.d, by="row.names", all.y=TRUE, stringsAsFactors = FALSE)
      colnames(hit.table.d)[1] <- "anno_id"      

    } else {
      # values$anno_cols
      anno.table.d <- merge(data.org[,values$anno_cols, drop=FALSE], 
                            df.lfc.mean.d, by="row.names", all.y=TRUE, stringsAsFactors = FALSE)
      rownames(anno.table.d) <- as.character(anno.table.d$Row.names)
      anno.table.d <- anno.table.d[,-1]
      hit.table.d <- merge(anno.table.d, hit.table.d, by="row.names", all.y=TRUE, stringsAsFactors = FALSE)
      hit.table.d <- hit.table.d[,-1]
      colnames(hit.table.d)[1] <- "anno_id"       

    }
    


    # order by `par_d` i.e differential effect parameter.
    hit.table.d <- hit.table.d[order(hit.table.d$par_d, decreasing=TRUE),]    
    ###
        
    return(hit.table.d)      
    }
  }


  # == depreciated: par_e is not integrated into abc. So that it can also control the output ==#
  #
  # if(wanted == "e") {
  #   par_e.ids <- rownames(logfc.list$counts) [
  #     apply(df.list$par_e.list,1, function(x) all(x>=input$e_slide[1] & x<=input$e_slide[2]))]    
  # 
  # hit.table.e <- logfc.list$counts[par_e.ids,]
  # 
  #   ### annotate result table ###
  #   if(length(values$anno_cols_extra)!=0) {
  #     anno.table.e <- merge(data.org[,values$anno_cols_extra, drop=FALSE], 
  #                             df.lfc.mean.e, by="row.names", all.y=TRUE, stringsAsFactors = FALSE)
  #     rownames(anno.table.e) <- as.character(anno.table.e$Row.names)
  #     anno.table.e <- anno.table.e[,-1]
  #   }
  #   
  #   hit.table.e <- merge(anno.table.e, hit.table.e, by="row.names", all.y=TRUE, stringsAsFactors = FALSE)
  #   colnames(hit.table.e)[1] <- "anno_id"
  # 
  #   # order by `par_e` i.e differential effect parameter.
  #     hit.table.e <- hit.table.e[order(hit.table.e$par_e, decreasing=TRUE),]    
  #   ###
  # 
  # return(hit.table.e)
  # }
  
}  


  
get.sample.list <- function() {

    # put all the info together to process things easily. 
    sample.list <- 
    list(anno_cols = input$anno_cols,
         anno_cols_extra = input$anno_cols_extra, 
         input_ctrl = input$input_ctrl, 
         ctrl_a = input$ctrl_a,
         select_a = input$select_a,
         ctrl_b = input$ctrl_b,
         select_b = input$select_b)
    
    return(sample.list)  
  }
  


#### render: expression plot ####
  output$exp.plot.firsthit <- renderUI({

    # Create a Progress object
      progress <- shiny::Progress$new()
    # Make sure it closes when we exit this reactiv, even if there's an error
      on.exit(progress$close())
    # set a progress message
      progress$set(message = "Rendering", detail = "expression plot ...",value=50)
     
    if(values$dont.exp.plot == TRUE) {
      # i.e if there is no sufficient data
      # then quit plotting.
      return(NULL)
    }
      
    # take the reactive values
    logfc.list = values$logfc.list
    #data.abc = values$hit.table.abc
    data.abc = values$data.abc

      
    if(length(logfc.list)!=0) {

      if(nrow(data.abc) == 0) {
        return(list(br(), br(),
                    br(), br(),
                    paste("NO RESULTS for DIFFERENTIAL EFFECT TABLE: please adjust the sliders to appropriate ranges.")))
      } else {
      
        output$rp <- renderPlot({
                  # initialize the call to the function.
                  data <- data.abc
                  p <- get.exp.plot(data=data, row.num = values$next_button.count)
                  print(p)
              })
    
        return(list(
          h4("Your First Hit - looks like this."),
          hr(),
          plotOutput("rp", width = "480px", height = "480px")
        ))
        
      }
    
    } else {
      return(NULL)
    }
    
 }) 

#### next and previous buttons ####
observeEvent(input$next_button, {
  # Take values from reactive variable
  logfc.list = values$logfc.list
  #data.abc = values$hit.table.abc
  data.abc = values$data.abc
  
  if(values$next_button.count <= dim(data.abc)[1]){
      
      # increase the value of the next button.
      values$next_button.count = (values$next_button.count+1)
      
      if(values$next_button.count >= dim(data.abc)[1]){
          shinyjs::disable("next_button")
          shinyjs::enable("previous_button")
      }
      
      if(values$next_button.count > 1) {
        shinyjs::enable("previous_button")
      }
      
      output$exp.plot.firsthit <- renderUI({
      output$rp <- renderPlot({
            data <- data.abc
            p <- get.exp.plot(data=data, row.num = values$next_button.count)
            print(p)
        })
  
      return(list(
        h4("Your Next Hits."), hr(),
        plotOutput("rp", width = "480px", height = "480px")
        ))
      })
      }
})

observeEvent(input$previous_button, {
  
  # Take values from the reactive variable
  logfc.list = values$logfc.list
  #data.abc = values$hit.table.abc
  data.abc = values$data.abc
  
  if(values$next_button.count == 1){
    shinyjs::disable("previous_button")
    shinyjs::enable("next_button")
  } else if(values$next_button.count > 1) {
    
    values$next_button.count = (values$next_button.count-1)
    
    if(values$next_button.count == 1){
      shinyjs::disable("previous_button")
      shinyjs::enable("next_button")
    }
    
    output$exp.plot.firsthit <- renderUI({
    output$rp <- renderPlot({
              data <- data.abc
              p <- get.exp.plot(data=data, row.num = values$next_button.count)
              print(p)
          })

      return(list(
        if(values$next_button.count == 1) h4("Your First Hit - looks like this.") else h4("Your Next Hits."),
        hr(),
        plotOutput("rp", width = "480px", height = "480px")
        ))
    })
  }
})


# plot on clicking the row
observeEvent(input$diff.effect.table_row_last_clicked, {
  
    # Take values from the reactive variable
    logfc.list = values$logfc.list
    #data.abc = values$hit.table.abc
    data.abc = values$data.abc
  
    values$next_button.count = input$diff.effect.table_row_last_clicked
    
    output$exp.plot.firsthit <- renderUI({
    output$rp <- renderPlot({
              data <- data.abc
              p <- get.exp.plot(data=data, row.num = values$next_button.count)
              print(p)
          })

      return(list(
        if(values$next_button.count == 1) h4("Your First Hit - looks like this.") else h4("Your Next Hits."),
        hr(),
        plotOutput("rp", width = "480px", height = "480px")
        ))
    }) 
})


#### renderTable: diff effect (par a,b,c,d) ####

output$diff.effect.table <- DT::renderDataTable({

    # Create a Progress object
      progress <- shiny::Progress$new()
    # Make sure it closes when we exit this reactiv, even if there's an error
      on.exit(progress$close())
    # set a progress message
      progress$set(message = "Rendering", detail = "differential effect table ...",value=50)
      
    
  # take from the reactive variable
  logfc.list = values$logfc.list
  
  if(length(logfc.list)!=0 && values$abc.computable == TRUE) {
    # load the reactive variable
    values$hit.table.abc = get.result.table(wanted = "abc", logfc.list)
    
    data.abc = values$hit.table.abc
    
    # change the labels in the table to match with the slider names
    # eg: par_a = A; par_b = B; par_c = C and so on...
    colnames(data.abc) = gsub("par_a","A",colnames(data.abc))
    colnames(data.abc) = gsub("par_b","B",colnames(data.abc))
    colnames(data.abc) = gsub("par_c","C",colnames(data.abc))
    colnames(data.abc) = gsub("par_e","E",colnames(data.abc))
    

    # Filtering the rows based on the user desired cutoff value for the controls. 
    # eg: value = 50 says that if any of the 'ctrl_(a/b)' tagged cols have a value less than 50, 
    #     then the  corresponding rows will be eliminated from the results. 
    ctrlfilter.value=input$ctrlfilter
    

    if((is.numeric(ctrlfilter.value) == TRUE) & (ctrlfilter.value > 0)){

        sample.list = values$sample.list
        cols2filter = c(sample.list$ctrl_a, sample.list$ctrl_b)
        rows.pass = if(nrow(data.abc) !=0) sapply(1:nrow(data.abc), function(x) any(data.abc[x,cols2filter] < ctrlfilter.value))
        if(length(which(rows.pass == TRUE)) !=0) {
          data.abc = data.abc[-which(rows.pass == TRUE),]
          values$data.abc = data.abc
        }
    
    } else if((is.numeric(ctrlfilter.value) == TRUE) & (ctrlfilter.value == 0)) {
      values$data.abc = data.abc
    }
    

    
    if(nrow(data.abc) !=0 ) {
    output$download.table.abc <- downloadHandler(
      filename = "diff_effect_table.csv",
      content = function(file) {
        write.csv(data.abc, file, row.names = FALSE)
      }
    )
    
    output$download.exp_plots.abc <- downloadHandler(
      filename = "diff_effect_exp_plots.pdf",
      content = function(file) {
        pdf(file)
          data <- data.abc
          for(i in 1:dim(data)[1]) {
            print(get.exp.plot(data=data, row.num = i))
          }
        dev.off()
      }
    )

    # action buttons and diff effect labels
    output$next_prev_buttons <- renderUI({
      return(list(
        actionButton("previous_button", "previous"),
        actionButton("next_button", "next"),
        br(),br(),
        h4("Differential Effect Table"),
        hr(),
        helpText("When the option `calculate log2FC with mean counts` is un-checked, 
                 the differential effect table displays only Vendor Clone IDs that 
                 satisfy Parameters A~E in all entered replicates. Parameter values 
                 displayed are calculated as per mean. To generate values of single replicates, 
                 annotate single replicates only."),
        fluidRow(
            column(
                downloadButton('download.table.abc', 'Download: diff_effect_table.csv')
            ),
            column(
                downloadButton('download.exp_plots.abc', 'Download: diff_effect_exp_plot.pdf')
            )
        ),
        #helpText("You will download the results belonging the table below.")
        br()
      ))
    })
        
    # the code after %>% is only to display the table with 2 decimal points
    # otherwise, you will have numbers with 10 decimal points which kind of looks ugly on screen
    # but for downloading, the 10 decimal point version is provided.
    return(
    DT::datatable(data.abc, rownames=FALSE, selection = "single") %>% 
      formatRound(columns=colnames(data.abc)[which(sapply(data.abc, function(x) class(x)) == "numeric")],
                  digits=2)
    )
    
    } else {
      output$next_prev_buttons <- renderUI({ return(NULL) })
      
      return(NULL)
    }

  } else { return (NULL)}

  
})






#### renderTable: control-input (par d) ####

output$control.input <- DT::renderDataTable({


    # Create a Progress object
      progress <- shiny::Progress$new()
    # Make sure it closes when we exit this reactiv, even if there's an error
      on.exit(progress$close())
    # set a progress message
      progress$set(message = "Rendering", detail = "control-input table ...",value=50)
      
    
  # take from the reactive variable
  logfc.list = values$logfc.list
  
  if(length(logfc.list)!=0 && values$d.computable == TRUE) {
    # load the reactive variable
    values$hit.table.d = get.result.table(wanted = "d", logfc.list)
    
    data.d = values$hit.table.d
 
    # change the labels in the table to match with the slider names
    # eg: par_a = A; par_b = B; par_c = C and so on...
    # here, we change it only for D
    colnames(data.d) = gsub("par_d","D",colnames(data.d))

    
    # Filtering the rows based on the user desired cutoff value for the controls. 
    # eg: value = 50 says that if any of the 'ctrl_(a/b)' tagged cols have a value less than 50, 
    #     then the  corresponding rows will be eliminated from the results. 
    ctrlfilter.value=input$ctrlfilter

    if((is.numeric(ctrlfilter.value) == TRUE) & (ctrlfilter.value > 0)){

        sample.list = values$sample.list
        cols2filter = c(sample.list$ctrl_a, sample.list$ctrl_b)
        rows.pass = if(nrow(data.d) !=0) sapply(1:nrow(data.d), function(x) any(data.d[x,cols2filter] < ctrlfilter.value))
        if(length(which(rows.pass == TRUE)) !=0) {
          data.d = data.d[-which(rows.pass == TRUE),]  
        }
    
    }    
    

    if(nrow(data.d) !=0){
      
      output$download.table.d <- downloadHandler(
        filename = "control_input_table.csv",
        content = function(file) {
          write.csv(data.d, file, row.names = FALSE)
        }
      )
      
      output$download.exp_plots.d <- downloadHandler(
        filename = "control_input_exp_plots.pdf",
        content = function(file) {
          pdf(file)
            data <- data.d
            for(i in 1:dim(data)[1]) {
              print(get.exp.plot(data=data, row.num = i))
            }
          dev.off()
        }
      )        
  
      # output the heading
      output$control.input.heading <-  renderUI({
        list(
          br(),
          h4("Table D : Parameter D (log2FC ctrl_a/input_ctrl)"),
          hr(),
          fluidRow(
              column(
                  downloadButton('download.table.d', 'Download: control_input_table.csv')
              ),
              column(
                  downloadButton('download.exp_plots.d', 'Download: control_input_exp_plot.pdf')
              )
          ),
          br())      
        })
  
                  
      # the code after %>% is only to display the table with 2 decimal points
      # otherwise, you will have numbers with 10 decimal points which kind of looks ugly on screen
      # but for downloading, the 10 decimal point version is provided.
      DT::datatable(data.d, rownames=FALSE, selection = "none") %>% 
        formatRound(columns=colnames(data.d)[which(sapply(data.d, function(x) class(x)) == "numeric")],
                    digits=2)
    } else {
      output$control.input.heading <-  renderUI({ 
          if( values$d.computable == FALSE &&
              values$abc.computable == TRUE) {
                list(
                  hr(),
                  h4(HTML("<p id='table_d_feedback'>The Table D can't be computed without the 
                            appropriate samples in the `input_ctrl` field. 
                            <br>The `D` input slider is also disabled for this reason.</p>")),
                  hr()
                )
          } else {
              return(NULL)  
          }
        })
      return(NULL)
    }
  } else { 
    output$control.input.heading <- renderUI({
      if( values$d.computable == FALSE &&
          values$abc.computable == TRUE) {
            list(
              hr(),
              h4(HTML("<p id='table_d_feedback'>The Table D can't be computed without the 
                        appropriate samples in the `input_ctrl` field. 
                        <br>The `D` input slider is also disabled for this reason.</p>")),
              hr()
            )
      } else {
          return(NULL)  
      }
      
      })
    return(NULL) 
  }    
      
  
  
})


 
 

#### show design image ####
output$show_design_image <- renderUI({

    #img(src="analysis_design.png", width="40%")
  list(
    #checkboxInput('our.design', 'show example design', FALSE),
    img(src="design_general.jpeg")
  )
    
})

observeEvent(input$our.design, {
  if(input$our.design == FALSE) {
    output$show_design_image <- renderUI({
      list(
        checkboxInput('our.design', 'show example design', FALSE),
        img(src="design_general.jpeg")        
      )
    })
  } else {
    output$show_design_image <- renderUI({
      list(
        checkboxInput('our.design', 'show example design', TRUE),
        img(src="design_ours.jpeg")        
      )
    })
  }
})


#### hide/show design ####
observeEvent(input$hideshow, {
  # every time the button is pressed, alternate between hiding and showing the design
  if(values$show.design_image == TRUE){
    values$show.design_image = FALSE   # record that it is currently off/hidden
    toggle("show_design_image")
  } else {
    values$show.design_image = TRUE    # record that it is currently on/shown
    toggle("show_design_image")
  }
})
  

#### get.plot.counts: observe & normalize ####

#get.plot.counts <- reactive ({

get.plot.counts <- function(cols2filter) {
  #cols2filter = are the names of the columns that are selected.

  # get values from reactive variable
  data.org = values$data.org

    # === Filtering the rows based on the user desired cutoff value for the selected coumns ===
    # In this order
    # ---------------
    # 1) Delete the rows*
    # 2) Normalize it
    # 3) Plot it
    #
    # *eg: value = 50 says that if any of the cols have a value less than 50, 
    #     then the  corresponding rows will be eliminated from the results. 
    exp_ctrlfilter.value=input$exp_ctrlfilter

        
    if((is.numeric(exp_ctrlfilter.value) == TRUE) & (exp_ctrlfilter.value > 0)){

        rows.pass = if(nrow(data.org) !=0) sapply(1:nrow(data.org), function(x) any(data.org[x,cols2filter] < exp_ctrlfilter.value))
        if(length(which(rows.pass == TRUE)) !=0) {
          data.org = data.org[-which(rows.pass == TRUE),]
        }
    
    }  
  
    

  if(values$data.uploaded == TRUE) {  
    
    # get all the numeric columns (assuming that numeric columns are the actual data)
    numeric_cols <- names(which(sapply(data.org, function(x) is.numeric(x)) == TRUE))
    
    # assign the phenoData for the normalization purposes
    phenoData <- data.frame(experiment=numeric_cols, condition=numeric_cols, label=numeric_cols)
    rownames(phenoData) <- as.character(phenoData$experiment)


    ## check for integers and display message
    if(any(is.integer(unlist(data.org[,numeric_cols])) == FALSE) == TRUE & input$exp_normalize != "None") {
         createAlert(session, "explore_alert", "deseq2_explore_alert", title = "Oops",
           content = paste0("DESeq2 and TMM are the RNASeq normalizations. 
                            They require integer data. Some of the selected samples have non-integer values."), 
           append = FALSE)
      
           showModal (modalDialog(
              title = "DESeq2 and TMM are the RNASeq normalizations. 
                       They require integer data. Some of the selected samples have non-integer values.",
              easyClose = TRUE
            ))        
    } else {
            
        if(input$exp_normalize=="DESeq2") {
            closeAlert(session, "deseq2_explore_alert")
            plot.counts <- normalize.deseq2(counts=data.org[,numeric_cols], phenoData = phenoData)$normalized.counts
            return(plot.counts)
            
        } else if(input$exp_normalize=="TMM") {
          closeAlert(session, "deseq2_explore_alert") 
          plot.counts <- normalize.edger(counts=data.org[,numeric_cols], phenoData = phenoData)$normalized.counts
          return(plot.counts)
        } 
    }
    
    # The check is only for the normalization methods.
    if(input$exp_normalize=="None") {
          # use the raw counts if none specified.
          closeAlert(session, "deseq2_explore_alert")
          plot.counts <- data.org[,numeric_cols]
          return(plot.counts)
    }
    
  return(NULL)
  }
}



  
  
  #### Data Exploration ####

  #### ** Scatter Plot - Pairwise (interactive) ####
  output$g.scatterchart <- reactive({  
    
    # Create a Progress object
      progress <- shiny::Progress$new()
    # Make sure it closes when we exit this reactiv, even if there's an error
      on.exit(progress$close())
    
    scatter_cols <- input$scatter_pairwise_input_cols
    if(is.null(scatter_cols) != TRUE) {
    counts <- get.plot.counts(cols2filter = scatter_cols)
    
    data.org <- values$data.org
    
    if(all(colnames(data.org)%in%input$annotate_plot == FALSE) == TRUE) {
      # i.e if none of the colnames intersect with the input data,
      #     then prompt the user to select an annotation column
      # FIXME
      plot.annotation = FALSE
    } else {
      plot.annotation = TRUE
      google.anno.col <- data.org[,input$annotate_plot, drop=FALSE]
      colnames(google.anno.col) <- "google.anno.col"
      counts = merge(counts, google.anno.col, by="row.names")
      #counts = merge(counts, data.org[,input$annotate_plot, drop=FALSE], by="row.names")
      rownames(counts) = counts$Row.names
    }
    
    if((is.null(counts) != TRUE) & (values$data.uploaded==TRUE) & (length(scatter_cols)==2)){
 
      # set a progress message
      progress$set(message = "Google Scatter Plot", detail = "rendering ...",value=50)
           
      if(plot.annotation == FALSE) {
        data = googleDataTable(counts[, scatter_cols])
      } else {
        no.of.cols <- length(c(scatter_cols, input$annotate_plot))
        data = googleDataTable(counts[, c(scatter_cols, "google.anno.col")])
        for(i in 0:(length(input$annotate_plot)-1)){
          data$cols[[no.of.cols-i]]$role <- 'tooltip'
        }
      }
      

      output$gdata.out <- renderPrint({ data }) 
      # return the options for g.scatterchart
            list(
              data = data,
              
              options = list(
                
                hAxis = list(
                  title = scatter_cols[1]
                ),
                vAxis = list(
                  title = scatter_cols[2]
                )
                
              )
            )
    } else {
      return(NULL)
    }
    
    
    }
  })

#### **** renderUI ####
output$google.scatter.plot <- renderUI({

  scatter_cols <- input$scatter_pairwise_input_cols
  counts <- NULL
  
  if(is.null(scatter_cols) != TRUE) {
    counts <- get.plot.counts(cols2filter = scatter_cols)  
  }
  
  if((is.null(counts) != TRUE) & (is.null(input$scatter_pairwise_input_cols) != TRUE)){ 
  list(
        h3("Scatter Plot - Pairwise (interactive)"), hr(),
        helpText(HTML("Hover your mouse onto the blue dots to identify the data points as annotated <br>
              by the data column in the `Annotate Plot` field.<br>
              Scroll the mouse wheel to either zoom-in or zoom-out of the plot.<br>
              R Packages: googleCharts")),
        googleScatterChart("g.scatterchart", width="480px", height="480px", 
                          options = list(
                          fontName = "Source Sans Pro",
                          fontSize = 13,
                          # Allow pan/zoom
                          explorer = list(),
                          # Set fonts
                          titleTextStyle = list(
                            fontSize = 16
                          ),
                          tooltip = list(
                            textStyle = list(
                              fontSize = 12
                            )
                          )))    
        )
  }
})

  get.exp.plot <- function(data, row.num) {

       # get the first hit
    data = data[row.num, , drop=FALSE]
    # > str(data)
    # 'data.frame': 1 obs. of  15 variables:
    #  $ anno_id              :Class 'AsIs'  chr "V3LHS_636312|1"
    #  $ Gene.Symbol          : chr "GRK1"
    #  $ par_a                : num 4.6
    #  $ par_b                : num -3.83
    #  $ par_c                : num 8.44
    #  $ decode_bc.4_chip03   : num 647
    #  $ decode_bc.4_chip04   : num 655
    #  ....
    #
    rownames(data) <- as.character(data$anno_id)

    # get all the non-annotation columns
    sample.list <- get.sample.list()
    numeric_cols <- unlist(sample.list[3:length(sample.list)])
    
    if(any(numeric_cols%in%colnames(data) == FALSE) == TRUE) {
      # i.e if some of the data columns are missing,
      # then don't plot.
      # This can happen because sample.list is reactively retrieved
      values$dont.exp.plot = TRUE

    } else {
      values$dont.exp.plot = FALSE    
      data <- data[,numeric_cols]

      # assign the phenoData for the normalization purposes
      phenoData <- data.frame(experiment=numeric_cols, stringsAsFactors=FALSE)
      phenoData$condition <- gsub("[0-9]*$","",rownames(phenoData), perl=TRUE)
      phenoData$replicate <- paste("rep_", gsub("([a-z]*_[a-z]*)([0-9]*$)","\\2",rownames(phenoData), perl=TRUE), sep="")
      phenoData$label <- phenoData$replicate
      rownames(phenoData) <- phenoData$experiment

      # > phenoData
      #                        experiment  condition replicate
      # input_ctrl1    decode_bc.4_chip03 input_ctrl     rep_1
      # input_ctrl2    decode_bc.4_chip04 input_ctrl     rep_2
      # ctrl_a1       d5.hief_bc.6_chip03     ctrl_a     rep_1
      # ctrl_a2       d5.hief_bc.7_chip04     ctrl_a     rep_2
      # select_a1    d23.hief_bc.8_chip03   select_a     rep_1
      # select_a2    d23.hief_bc.8_chip04   select_a     rep_2
      # ctrl_b1      d5.hierg_bc.5_chip03     ctrl_b     rep_1
      # ctrl_b2      d5.hierg_bc.5_chip04     ctrl_b     rep_2
      # select_b1   d23.hierg_bc.7_chip03   select_b     rep_1
      # select_b2   d23.hierg_bc.6_chip04   select_b     rep_2
      
      # because the names were eventually changed.
      phenoData$condition <- gsub("select", "exp", phenoData$condition)

      return(countdata.plot_expression (counts=data, phenoData=phenoData, genename=rownames(data)) )
    }
 
  }




  
  #### ** Scatter Plot - Pairwise (static) ####
  output$scatter_plot_pairwise <- renderUI({
    
    # Create a Progress object
      progress <- shiny::Progress$new()
    # Make sure it closes when we exit this reactiv, even if there's an error
      on.exit(progress$close())
     
    
    scatter_cols <- input$scatter_pairwise_input_cols
    counts <- get.plot.counts(cols2filter = scatter_cols)
    

    
    if((is.null(counts) !=TRUE) & (values$data.uploaded==TRUE) & (length(scatter_cols)==2)){    

      # set a progress message
      progress$set(message = "Normal Scatter Plot", detail = "rendering ...",value=50)
 

      # Plot
      output$scatter_plot_pairwise.rendered <- renderPlot({
        countdata.scatterplot (counts=counts[,scatter_cols], remove.maxvalue=input$remove.max.value,
                               fit=input$fit.line)
        })   
      #

      
      return(list(
      h3("Scatter Plot - Pairwise (static)"), hr(),
      helpText(HTML("The value indicated is the \"pearson\" correlation coefficient.<br>
                    It is calculated with the`cor` function from the `stats` package of R.")),
      plotOutput("scatter_plot_pairwise.rendered", width = "600px", height = "600px")
      ))      
      
           

      }
  })

  
  #### ** Scatter Plot - Matrix ####
  output$scatter_plot_matrix <- renderUI({

    # Create a Progress object
      progress <- shiny::Progress$new()
    # Make sure it closes when we exit this reactiv, even if there's an error
      on.exit(progress$close())
   
        
    scatter_cols <- input$scatter_matrix_input_cols
    counts <- get.plot.counts(cols2filter = scatter_cols)
    
    if((is.null(counts) != TRUE) & (values$data.uploaded==TRUE) & (length(scatter_cols) >= 2)) {

    # set a progress message
      progress$set(message = "Scatter Plot Matrix", detail = "rendering ...",value=50)
              
      phenoData <- data.frame(experiment=scatter_cols, label=scatter_cols)
      
 

      output$scatter_plot_matrix.rendered <- renderPlot({
      countdata.scatterplot.matrix(counts=counts[,scatter_cols],
                             phenoData=phenoData, remove.maxvalue=input$remove.max.value,
                             fit=input$fit.line)
        })
      
      return(list(
          h3("Scatter Plot - Matrix"), hr(),
          helpText(HTML("The values indicated are the \"pearson\" correlation coefficients.<br>
                        They are calculated with the R package functions.<br>
                        - the`cor` function from the `stats` package. <br>
                        - the `pairs` function from the `graphics` package.")),
          plotOutput("scatter_plot_matrix.rendered", width = "600px", height = "600px")
      ))  

    }
    
  })
  

  #### ** Box Plot ####
  output$boxplot <- renderUI({

    # Create a Progress object
      progress <- shiny::Progress$new()
    # Make sure it closes when we exit this reactiv, even if there's an error
      on.exit(progress$close())

           
    scatter_cols <- input$boxplot_input_cols    
    counts <- get.plot.counts(cols2filter = scatter_cols)
    
    
    if((is.null(counts) != TRUE) & (values$data.uploaded==TRUE) &(length(scatter_cols) >=2 )) {

      # set a progress message
      progress$set(message = "Box Plot", detail = "rendering ...",value=50)
      
      phenoData <- data.frame(experiment=scatter_cols, condition=scatter_cols, label=scatter_cols)


      
      output$boxplot.rendered <- renderPlot({
        par(mar=c(15,5,1,1))
        countdata.boxplot.graphics(counts=counts[,scatter_cols, drop=FALSE], phenoData=phenoData)
      })
      
      return(list(
        h3("Box Plot"), hr(),
        helpText(HTML("The plot is drawn using the `boxplot` function of R's `graphics` package <br>
                      and is drawn without the outliers.")),
        plotOutput("boxplot.rendered", width = "600px", height = "600px")
      ))
      
    }
  })
  

  #### ** Dendrogram Heatmap ####
  output$dendro_plot <- renderUI({

    # Create a Progress object
      progress <- shiny::Progress$new()
    # Make sure it closes when we exit this reactiv, even if there's an error
      on.exit(progress$close())
        
    scatter_cols <- input$boxplot_input_cols
    counts <- get.plot.counts(cols2filter = scatter_cols)
    
    if((is.null(counts) != TRUE) & (values$data.uploaded==TRUE) &(length(scatter_cols) >=2 )) {


      # set a progress message
      progress$set(message = "Clustering Plot", detail = "rendering ...",value=50)

      phenoData <- data.frame(experiment=scatter_cols, condition=scatter_cols, label=scatter_cols)

 

      output$dendro_plot.rendered <- renderPlot({
        par(mar=c(15,5,1,1))
        countdata.heatmap_dendrogram(counts=counts[,scatter_cols, drop=FALSE], phenoData=phenoData)
        })
      
      return(list(
      h3("Distance Heatmap with Dendrogram"), hr(),
      helpText(HTML("The numbers in the heatmap legend represent \"euclidean distance\" between the 
               respective pairs of samples. <br> This metric is calculated by the `dist` 
               function from the `stats` package of R. <br> The heatmap is produced with the `pheatmap` package of R.")),
      plotOutput("dendro_plot.rendered", width = "600px", height = "600px")
      ))
    }
  })
  
  #### ** PCA plot ####
  
  output$pca_plot <- renderUI({

    # Create a Progress object
      progress <- shiny::Progress$new()
    # Make sure it closes when we exit this reactiv, even if there's an error
      on.exit(progress$close())
   
        
    scatter_cols <- input$boxplot_input_cols
    counts <- get.plot.counts(cols2filter = scatter_cols)
    
    if((is.null(counts) != TRUE) & (values$data.uploaded==TRUE) &(length(scatter_cols) >=2 )) {

      # set a progress message
      progress$set(message = "PCA Plot", detail = "rendering ...",value=50)

      phenoData <- data.frame(experiment=scatter_cols, condition=scatter_cols, label=scatter_cols)
      
      output$pca_plot.rendered <- renderPlot({
        par(mar=c(15,5,1,1))
        countdata.plotPCA(counts=counts[,scatter_cols, drop=FALSE], phenoData=phenoData)
      })
      
      return(list(
        h3("PCA Plot"), hr(),
        helpText(HTML("`ggplot2` package has been used to create this plot. <br>
                      The principle components are calculated using the `prcomp` function from the `stats` package.")),
        plotOutput("pca_plot.rendered", width = "600px", height = "600px")
      ))
      
    }
  })
   
    
  
}

