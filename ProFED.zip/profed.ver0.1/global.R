# Author: Nikhil Vinod Mallela
# Copyright: 2016,2017 Institute of Bioinformatics, University of Muenster
# License : GNU GPLv3

# REMARKS
# 1) Tooltips does not work if the "absolute panels" are set as "draggable". (for some reason)
#    open issue: https://github.com/ebailey78/shinyBS/issues/58
#
# 2) The "column" function in the Shiny package conflicts with the googleCharts package (for some reason)
#    solution:   # http://stackoverflow.com/questions/29423602/unused-argument-error-with-offset-in-column-for-shiny
#
# 3) The bsTooltip function doesn't work if some of the special characters like ` $ etc are use.
#    one should always check that.
#         bsTooltip("exp.normalize", .......) <- DOESN'T WORK !
#         bsTooltip(id = "exp_normalize", .....) <- WORKS !
#    Note the underscore (_) in the above example.

library(shiny)
library(shinyBS)  #used for the tooltip. i.e when you point your mouse a field, it tells you its purpose.
library(shinyjs)
# http://stackoverflow.com/questions/29423602/unused-argument-error-with-offset-in-column-for-shiny
column2 <- shiny::column

#tooltipPlace = "right"
#tooltipOptions = list(container = "body")
library(DT)
library(ggplot2)
library(rmarkdown)
library(markdown)
library(knitr)


# More info:
#   https://github.com/jcheng5/googleCharts
# Install:
#   devtools::install_github("jcheng5/googleCharts")
library(googleCharts)
library(dplyr)
library(scales)
library("pheatmap")
library("RColorBrewer")
