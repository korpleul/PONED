# Author: Nikhil Vinod Mallela
# Copyright: 2016,2017 Institute of Bioinformatics, University of Muenster
# License : GNU GPLv3


# The functions here follow the common phenoData structure as used by all other 
# count data codes.


########################### Filter Raw Data ####################################
# Filter Low Expressing Genes [edgeR Vignette]
# --------------------------------------------
#	- Genes with very low counts across all libraries provide little evidence 
#	  for differential expression.
#	- These genes should be filtered out prior to further analysis.
#	- As a rule of thumb, genes are kept if they are expressed in at least one condition. 
#	- Usually a gene is required to have a count of 5-10 in a library to be 
#	  considered expressed in that library. 
#	- Users should also filter with count-per-million (CPM) rather than 
#	  filtering on the counts directly, as the latter does not account for differences
#	  in library sizes between samples.
#	- A CPM of 1 corresponds to a count of 6-7 in the smallest sample.

lowlevel.filterRawData <- function(counts) {
	require(edgeR)
	require(genefilter)	#for rowVars function

	if(ncol(counts) >= 3){
		keep <- rowSums(cpm(counts)>1) >= 3
	} else if (ncol(counts) == 2) {
		keep <- rowSums(cpm(counts)>1) >= 1
	} else if (ncol(counts) == 1) {
		stop("lowlevel.filterRawData: Bro, you got only ONE column in your DF.")
	} else if (ncol(counts) == 0) {
		stop("lowlevel.filterRawData: Bro, you got only NO columns in your DF.")
	} else if (nrow(counts) == 0) {
		stop("lowlevel.filterRawData: The number of rows are zero at this point.
			i.e somehow all the data in the dataframe got wiped out.")
	}

	counts <- counts[keep, ]

#	# Remove the rows whose variance = 0
#	if( length(which(rowVars(counts)==0)) > 0 ){
#		# df[-0,] will erase the entire df. Therefore the above "if check"
#		counts <- counts[-which(rowVars(counts)==0),]
#	}

	return(counts)
}
################################################################################




########################### Filter Raw Data ####################################
# NOTE !!! You should almost never remove outliers from your data !!
lowlevel.remove.outliers <- function(counts) {
	if(ncol(counts)==2){
		intersecting.outliers <- Reduce(intersect, 
			list(boxplot.stats(counts[,1])$out, boxplot.stats(counts[,1])$out))
		counts <- counts[-intersecting.outliers,]
		return(counts)
	} else {
		stop("lowlevel.remove.outliers: there are more than 2 columns.")
	}
}
################################################################################




########################### Subset Count Data ##################################
lowlevel.subsetConditions <- function(counts, phenoData, subsetConditions){

	require(genefilter)	#for rowVars function

	if(!is.null(subsetConditions)){
		phenoData <- subset(phenoData, condition%in%subsetConditions)
		counts <- counts[,phenoData$experiment]
	}
	return(list(counts=counts, phenoData=phenoData))
}
################################################################################

##################### remove factors from phenoData ############################
# factors in the phenoData are often a problem while using DESeq & edgeR
# or anyother plotting functions via ggplot for labeling.
# so, this function is to remove the factors

lowlevel.remove.phenoFactors <- function(phenoData){
	phenoData$experiment <- as.vector(phenoData$experiment)
	phenoData$condition <- as.vector(phenoData$condition)
	phenoData$label <- as.vector(phenoData$label)
	phenoData$batch <- as.vector(phenoData$batch)
	phenoData$treat <- as.vector(phenoData$treat)

	return(phenoData)
}
################################################################################

##################### Mode function ############################################
Mode <- function(x) {
  ux <- unique(x)
  ux[which.max(tabulate(match(x, ux)))]
}
################################################################################