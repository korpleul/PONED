# Author: Nikhil Vinod Mallela
# Copyright: 2016,2017 Institute of Bioinformatics, University of Muenster
# License : GNU GPLv3


###################### DESeq GLM: nbinomWaldTest ###############################
normalize.deseq2 = function(counts, phenoData, subsetConditions=NULL){

require(DESeq2)		#obviously!
# The fuctions 'DESeq'
# require("BiocParallel")
# register(MulticoreParam(4))

# remove phenoFactors from the dataframe
# factor'd data is often a problem.
phenoData <- lowlevel.remove.phenoFactors(phenoData)

# subset the conditions (if the value is supplied)
subset <- lowlevel.subsetConditions(counts=counts, 
									phenoData=phenoData, 
									subsetConditions=subsetConditions)
counts <- subset[[1]]
phenoData <- subset[[2]]


# Filter the Genes with low counts and zero variance
#counts <- lowlevel.filterRawData(counts)


dds <- DESeqDataSetFromMatrix(	countData=counts[,as.character(phenoData$experiment)],
								colData=phenoData,
								design=~1)	
dds <- estimateSizeFactors(dds)
# check pheno data
colData(dds)

#dds <- DESeq(dds, parallel=TRUE)


return(list(normalized.counts=counts(dds, normalized=TRUE),
			dds=dds))
# dds = deseq data set
}
################################################################################

######################## Between Lane Normalization ############################
# Between lane normalization
# require(EDASeq)
#betweenLaneNormalization(x, which=c("median","upper","full"), offset=FALSE, round=TRUE)
#betweenLaneNormalization(x, which="upper", offset=FALSE, round=TRUE) 

#	I've tried the betweenLaneNormalization on Marc's data. And as per the 
#	expression plots, there is no profound difference except that the overall
#	were scalled a little higher than the DESeq2 normalization.

################################################################################


######################### Quantile Normalization ###############################
#	require(preprocessCore)
#	
#	norm.data.matrix <- normalize.quantiles(as.matrix(data.matrix))
#	colnames(norm.data.matrix) <- colnames(data.matrix)
#	rownames(norm.data.matrix) <- rownames(data.matrix)
################################################################################


##################### edgeR GLM: TMM normalization #############################
normalize.edger = function(counts, phenoData, subsetConditions=NULL,
	norm.method="TMM"){

require(edgeR)		#obviously!

# remove phenoFactors from the dataframe
# factor'd data is often a problem.
phenoData <- lowlevel.remove.phenoFactors(phenoData)

# subset the conditions (if the value is supplied)
subset <- lowlevel.subsetConditions(counts=counts, 
									phenoData=phenoData, 
									subsetConditions=subsetConditions)
counts <- subset[[1]]
phenoData <- subset[[2]]


# Filter the Genes with low counts and zero variance
#counts <- lowlevel.filterRawData(counts)


# DGEList object #
y <- DGEList(counts=counts[,phenoData$experiment], 
	         group=as.character(phenoData$condition))

# TMM Normalization #
y <- calcNormFactors(y, method=norm.method)
y$samples

## Estimate Dispersions #
#y <- estimateDisp(y, design, robust=TRUE)
#y$common.dispersion




#=== TMM normalized counts ===#
# NOTE: These numbers should only be used for the  Exploratory analysis
#       This normalization code is taken from the function "normalize.edger" 
#       of the metaseqR package.
#
scl <- y$samples$lib.size * y$samples$norm.factors
#normalized.counts <- round(t(t(y$counts)/scl) * mean(scl))
normalized.counts <- t(t(y$counts)/scl) * mean(scl)


return(list(normalized.counts=normalized.counts,
			DGEList=y))
}
################################################################################

