# Author: Nikhil Vinod Mallela
# Copyright: 2016,2017 Institute of Bioinformatics, University of Muenster
# License : GNU GPLv3

source("global.R")

fluidPage(
  #style="padding-top: 80px;",
    # useful for adding notices or update news at the top.

  tags$div(HTML(paste("Research application provided by ",
    tags$a(href="http://complex-systems.uni-muenster.de/index.html","Cancer and Complex Systems Research Group"),
    ", University of Muenster, Germany",
    sep=""))),

    tags$head(
        tags$style("#anno_form_feedback{color: red;
                                       font-size: 15px;
                                       font-style: italic;}
                   #table_d_feedback{
                      color: darkgrey;
                   }

                    body{
                    width: 1500px;
                    max-width: 1500px;
                    margin: 0 auto !important;
                    float: none !important;
                    }

                    div.exprelative {
                        position: relative;
    
                    }
                    div.expabsolute {
                        position: absolute;
                    }
                  "
            )
    ),
  
  
  withMathJax(),
  titlePanel("ProFED"),
  helpText(h4(HTML("[<b>Pro</b>file <b>F</b>iltering of <b>E</b>xpression <b>D</b>ata]"))),
  sidebarLayout(

    
    sidebarPanel(

# Conditional Panel ---------------------------------------------------------------------------


      # conditionalPanel(condition="input.tabs1=='Introduction'"
      #                  #h4("Introduction")
      # ),
      

      # ** Import --------------------------------------------------------------------------------------


      conditionalPanel(condition="input.tabs1=='Import'",
                
                checkboxInput('load.example', 'load example', FALSE),
                htmlOutput("load.example.info"),
                hr(),
                fileInput('file1', 'Choose CSV File',
                          accept=c('text/csv', 
          								 'text/comma-separated-values,text/plain', 
          								 '.csv')),
                hr(),
                checkboxInput('import_add_plus_one', 'add +1 to data set', TRUE),
                helpText(h6("When the checkbox is active, hover your mouse over the box to know what this means.")),
                bsTooltip("import_add_plus_one",
                          gsub("\n","",
                          paste0("By default, we add +1 to the data set because,
                                  zero counts create a computational problem. eg. 0/248 = -Inf
                                  It is recommended to keep this checked if your data set contains zeros.")
                          ), 
                          "right", options = list(container = "body"))

      ),

      # ** Analyse -------------------------------------------------------------------------------------
      conditionalPanel(condition="input.tabs1=='Analyse'",
                       textOutput('anno_form_feedback'),
                       selectInput('anno_cols','Annotation Column', choices = NULL, multiple=FALSE, selectize = FALSE),
                       helpText("Annotation Column must have unique entries. eg: vendor clone ids"),
                       selectInput('anno_cols_extra', 'Annotation Columns - Extra (opt)', choices = NULL, multiple = TRUE),
                       selectizeInput('input_ctrl','input_ctrl (optional)', choices = NULL, multiple=TRUE),
                       selectizeInput('ctrl_a','ctrl_a', choices=NULL, multiple=TRUE),
                       selectizeInput('select_a','exp_a', choices=NULL, multiple=TRUE),
                       selectizeInput('ctrl_b','ctrl_b', choices=NULL, multiple=TRUE),
                       selectizeInput('select_b','exp_b', choices=NULL, multiple=TRUE),
                       br(),
                       actionButton("go_anno", "Submit"),
                       helpText("After you've assigned the samples, click the button to start the calculation.")
                       ),
      
      # ** Explore -------------------------------------------------------------------------------------
      conditionalPanel(condition="input.tabs1=='Explore'",
                     list(
                    HTML('<div class="exprelative" style="width: auto">'),  
                     absolutePanel( fixed = TRUE,
                           #HTML('<div id="explore.div" style="overflow: scroll ;max-height: 600px; width: 100%">'),
                           HTML('<div id="explore.div" class="expabsolute" style="overflow: scroll ;max-height: 600px; width: 360px; left: -20px">'),
                           wellPanel( style = "opacity: 0.92",
                           h4("Plot Controls", align = "center"), hr(),
                                      
                           # read filter.
                           numericInput('exp_ctrlfilter', 'Read Control Filter', 0,  min = 0),
                           bsTooltip("exp_ctrlfilter", 
                                     "Rows in the data table will be eliminated before normalization, if any number in the given row of data for the selected samples, is found to be less than this number. For more info: Help section.",
                                     "right", options = list(container = "body")),
                           
                           # normalization method            
                           selectInput('exp_normalize', 'Normalize Data',
                                       choices = c("None", "TMM", "DESeq2"),
                                       multiple = FALSE, selectize = FALSE, selected = "None"),
                           bsTooltip("exp_normalize", "Select a Normalization method.", "right", options = list(container = "body")),
                           
                           # annotate plot
                           selectInput('annotate_plot','Annotate Plot*', choices = NULL, multiple=FALSE, selectize = FALSE),
                           bsTooltip("annotate_plot", "Select the columns that can be used to annotate the data points on the plot.", "right",
                                     options = list(container = "body")),
                           helpText(h6("*Used by Scatter Plot: Pairwise")),
                           

                           hr(),
                           selectizeInput('scatter_pairwise_input_cols', 'Scatter Plot: Pairwise', choices = NULL, multiple=TRUE),
                           bsTooltip("scatter_pairwise_input_cols","Select ONLY Two columns.", "right", options = list(container = "body")),
                           checkboxInput('remove.max.value', 'Remove Max Value', FALSE),
                           selectInput('fit.line','fit line', 
                           choices = c("smoothingSpline","lmFit"), 
                           multiple=FALSE, selectize = FALSE, selected = "lmFit"),
                           hr(),
                           selectizeInput('scatter_matrix_input_cols', "Scatter Plot: Matrix", choices = NULL, multiple=TRUE),
                           hr(),
                           selectizeInput('boxplot_input_cols', "Box Plot, Heatmap & PCA plots", choices = NULL, multiple=TRUE),
                           hr()),
                           HTML('</div>')
                           ),
                        HTML('</div>'))                        
                       ),
      
      width=3
      ),
      
  



# Tabset Panel --------------------------------------------------------------------------------


    mainPanel(
      tabsetPanel(
        # ** Introduction ----
        tabPanel("Introduction", br(),
                 includeMarkdown("introduction.Rmd"),
                br()
                 ),
        
        # ** Import ----
        tabPanel("Import", 
                 br(), verbatimTextOutput('tab.import.datauploaded'),
                 br(), DT::dataTableOutput("tab.import.table") 
                 ),
        
        # ** Analyse ----
        tabPanel("Analyse", 
                 br(),
                 bsAlert("analyse_alert"), 
                 # why column2 ?
                 # http://stackoverflow.com/questions/29423602/unused-argument-error-with-offset-in-column-for-shiny
                 fluidRow(
                 column2(
                     verbatimTextOutput('tab.annotate.datauploaded'),
                     useShinyjs(),
                     actionButton("hideshow", "Hide/show design"),
                     htmlOutput("show_design_image"),
                     # This line loads the Google Charts JS library
                     htmlOutput("exp.plot.firsthit"),
                     htmlOutput("next_prev_buttons"),
                 width = 8),
                   column2(
                    HTML('
                          <div style="overflow: scroll ;max-height: 700px; width: 100%">
                         '),
                    wellPanel( style = "opacity: 0.92",
                               htmlOutput("sliderInputUI"),
                               #sliderInput("a.slide", "A", min=-10, max =9, step=1, value = 0),
                               checkboxInput('use.means', "calculate log2FC with mean counts", TRUE),
                               helpText(h6("unchecked will calculate log2FC per replicate.")),
                               hr(),
                               selectInput('normalize','Normalize Data', 
                                    choices = c("None", "TMM","DESeq2"), 
                                    multiple=FALSE, selectize = FALSE, selected = "None"),
                               # radioButtons('normalize', 'Normalize Data',
                               #              c(None="None",
                               #                TMM='tmm.norm',
                               #                DESeq2='deseq2.norm'),
                               #              'deseq2.norm')
                               HTML(paste('<b>Read Count Filter</b>',helpText(h6("(applies to ctrl_a and ctrl_b only)")))),
                               numericInput('ctrlfilter', label=NULL, 0,
                               min = 0)                               
                               
                    ),
                    HTML(' </div> '),
                    width = 4)
                 ),
                 
                 fluidRow(
                   column2(
                   #plotOutput("exp.plot.firsthit", width = "480px", height = "480px"),
                   DT::dataTableOutput("diff.effect.table"),
                   htmlOutput("control.input.heading"),
                   DT::dataTableOutput("control.input"),                    
                   width = 12)
                 ),

                 bsTooltip("use.means", "unchecked will calculate log2FC per replicate", "left", options = list(container = "body")),
                 bsTooltip("ctrlfilter", "Rows in both Final-Result-Tables will be removed if the counts of Any sample in ctrl_a or ctrl_b is found to be less than this number. ", "left", options = list(container = "body"))
                 
                 ),

        
        
        
        # ** Explore ----
        tabPanel("Explore",
                
                 fluidRow(
                   column2(br()
                     , width = 2),
                   
                   column2(
                     br(),
                     bsAlert("explore_alert"), 
                     # This line loads the Google Charts JS library
                     googleChartsInit(),
                     br(),
                     htmlOutput("google.scatter.plot"),
                     htmlOutput("scatter_plot_pairwise", width = "480px", height = "480px"),
                     htmlOutput("scatter_plot_matrix", width = "480px", height = "480px"),
                     htmlOutput("boxplot", width = "600px", height = "600px"),
                     htmlOutput("dendro_plot", width = "600px", height = "600px"),
                     htmlOutput("pca_plot", width = "600px", height = "600px")
                     #verbatimTextOutput("gdata.out")
                
                     ,width = 7),
                   
                   column2(br(),width=3)
                 )),

        
        # ** Help ----
        tabPanel("Help", br(),
                 includeHTML("help.html")
                 ),
        
        # ** About ----
        tabPanel("About", br(),
                 includeMarkdown("about.Rmd"))
        
      , id="tabs1")
    ,width=9)
    
    
  )
)
