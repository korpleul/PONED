# Author: Nikhil Vinod Mallela
# Copyright: 2016,2017 Institute of Bioinformatics, University of Muenster
# License : GNU GPLv3


# NOTE:
#     All the functions below are written based on the phenoData format below.

#   > phenoData
#     experiment condition     label
#   1 SRR1039508     untrt untrt_508
#   2 SRR1039512     untrt untrt_512
#   3 SRR1039516     untrt untrt_516
#   4 SRR1039520     untrt untrt_520
#   5 SRR1039509       trt   trt_509
#   6 SRR1039513       trt   trt_513
#   7 SRR1039517       trt   trt_517
#   8 SRR1039521       trt   trt_521

# This will label the samples on x-axis in the order of the levels.
#   phenoData$label <- factor(phenoData$label, levels=phenoData$experiment)

######################### BOX PLOT (with ggplot) ###############################
# The below function uses the following two columns
#   experiment    : corresponds to the colname of the input matrix
#   label         : used to label the x-axis ticks
#   condition     : used for coloring by group

countdata.boxplot <- function(counts, phenoData, transform=NULL, subsetConditions=NULL){
require(ggplot2)
require(edgeR)

  if(is.matrix(counts)){
    counts <- as.data.frame(counts)
  }

  # subset the conditions (if the value is supplied)
  subset <- lowlevel.subsetConditions(counts=counts, 
                    phenoData=phenoData, 
                    subsetConditions=subsetConditions)
  counts <- subset[[1]]
  phenoData <- subset[[2]]


df <- stack(counts)
colnames(df) <- c("counts", "experiment")
df <- merge(df, phenoData, by="experiment")


if(length(transform)==0){
  ggplot(aes(y=counts, x=label, fill=condition),data=df) + 
  stat_boxplot(geom ='errorbar') + geom_boxplot() +  
  theme(axis.text.x = element_text(angle = 90, hjust = 1)) +
  ylim(0, as.numeric(summary(df$counts)["3rd Qu."])) +
  xlab("library groups")
  # + ylab("counts") +  ggtitle("Before DESeq normalization")
} else if(transform == "log2"){
  ggplot(aes(y=log2(counts), x=label, fill=condition),data=df) + 
  stat_boxplot(geom ='errorbar') + geom_boxplot() +
  theme(axis.text.x = element_text(angle = 90, hjust = 1)) +
  ylim(as.numeric(summary(log2(df$counts))["1st Qu."]), 
    as.numeric(summary(log2(df$counts))["3rd Qu."])) +
  xlab("library groups")
} else if (transform == "cpm"){
  ggplot(aes(y=as.numeric(cpm(counts)), x=label, fill=condition),data=df) + 
  stat_boxplot(geom ='errorbar') + geom_boxplot() +
  theme(axis.text.x = element_text(angle = 90, hjust = 1)) +
  ylim(as.numeric(summary(as.numeric(cpm(df$counts)))["1st Qu."]), 
    as.numeric(summary(as.numeric(cpm(df$counts)))["3rd Qu."])) +
  xlab("library groups") + ylab("cpm(counts)")
} 

}

# USAGE:
#   countdata.boxplot(counts, phenoData)
#   countdata.boxplot(counts, phenoData, transform = "log2")
#   countdata.boxplot(counts, phenoData, transform = "cpm")
################################################################################


######################### BOX PLOT (with graphics) #############################
# The box plots from the ggplot's geom_boxplot() and the graphic's boxplot() 
# functions produce slightly altered box plots because the calculation of
# the quantiles differ slightly.
#
# Here, I try to use the graphic's boxplot() but emulating the beauty of the ggplot.
# for the following drawbacks in the geom_boxplot() :
# - There is no straight forward option to remove the outliers.
# - Plots with the outliers is hiding the actual distribution.
# - There is no straight way to auto adjust the y-axis scale


countdata.boxplot.graphics <- 
          function(counts, phenoData, transform=NULL, subsetConditions=NULL, ...){
  require(scales)
  require(edgeR)

  if(is.matrix(counts)){
  counts <- as.data.frame(counts)
  }

  # # subset the conditions (if the value is supplied)
  # subset <- lowlevel.subsetConditions(counts=counts, 
  #                   phenoData=phenoData, 
  #                   subsetConditions=subsetConditions)
  # counts <- subset[[1]]
  # phenoData <- subset[[2]]
  # 
  # # Filter the Genes with low counts and zero variance
  # counts <- lowlevel.filterRawData(counts)

  # count transformation
  if(is.null(transform)==TRUE){
    # do nothing.
  } else if(transform == "log2") { 
      counts = log2(counts) 
  } else if(transform == "cpm") { 
    counts = cpm(counts) 
  }

  # adjust the color pallet
  sample.unique <- unique(phenoData$condition)
  sample.colors <- hue_pal()(length(sample.unique))
  sample.colors <- adjustcolor(sample.colors, alpha.f=0.5)
  names(sample.colors) <- sample.unique
  sample.colors <- as.data.frame(sample.colors)
  sample.colors$condition <- rownames(sample.colors)
  phenoData <- merge(phenoData, sample.colors, by="condition", stringsAsFactors=FALSE)
  phenoData$sample.colors <- as.character(phenoData$sample.colors)


  # order according to the phenoData
  counts <- counts[,phenoData$experiment]

  # at this point, phenoData object will loose its rownames
  # so, give it back
  rownames(phenoData) <- phenoData$experiment

  # change the colnames of the count data
  colnames(counts) <- phenoData[colnames(counts),]$label



  # boxplot
  boxplot(counts, las=2, outline=FALSE, col=phenoData$sample.colors, ..., ylab="counts")
  
}

#countdata.boxplot.rbase(counts=counts.org, phenoData=phenoData.org)
################################################################################



############################### PCA PLOT #######################################
# The function below uses only the 'condition' column
# Sure that the colnames of the object counts corresponds to the data in the column.
countdata.plotPCA = function(counts, phenoData, ntop=500, returnData=FALSE, 
  color.by.condition=TRUE, subsetConditions=NULL)
{

  if(is.matrix(counts)){
    counts <- as.data.frame(counts)
  }

  # subset the conditions (if the value is supplied)
  subset <- lowlevel.subsetConditions(counts=counts, 
                    phenoData=phenoData, 
                    subsetConditions=subsetConditions)
  counts <- subset[[1]]
  phenoData <- subset[[2]]


  if(is.data.frame(counts)){
    counts <- as.matrix(counts)
  }

  require(genefilter) # for rowVars function

  # calculate the variance for each gene
  rv <- rowVars(counts)

  # select the ntop genes by variance
  select <- order(rv, decreasing=TRUE)[seq_len(min(ntop, length(rv)))]

  # perform a PCA on the data in counts for the selected genes
  pca <- prcomp(t(counts[select,]))

  # the contribution to the total variance for each component
  percentVar <- pca$sdev^2 / sum( pca$sdev^2 )

  if (!all("condition" %in% names(phenoData))) {
    stop("the argument 'condition' should specify columns of colData(dds)")
  }
  
  # add the condition factors together to create a new grouping factor
  if(color.by.condition==TRUE){
    condition.df <- as.data.frame(phenoData[, "condition", drop=FALSE])
    group <- factor(apply( condition.df, 1, paste, collapse=" : "))
  } else { # then color by label
    condition.df <- as.data.frame(phenoData[, "label", drop=FALSE])
    group <- factor(apply( condition.df, 1, paste, collapse=" : "))
  }
  # assembly the data for the plot
  d <- data.frame(PC1=pca$x[,1], PC2=pca$x[,2], group=group, condition.df, names=colnames(counts))
  attr(d, "percentVar") <- percentVar[1:2]

  if (returnData) {
      return(d)
  }

  percentVar <- round(100 * attr(d, "percentVar"))
  p <- ggplot(d, aes(PC1, PC2, color=group, shape=group)) + geom_point(size=3) +
  xlab(paste0("PC1: ",percentVar[1],"% variance")) +
  ylab(paste0("PC2: ",percentVar[2],"% variance"))
  
  if (length(unique(d$group)) > 6){
    p + scale_shape_manual(values=seq(0,length(unique(d$group))))
  } else {
    p
  }
}
################################################################################


############################# Expression Plots #################################
# Usage Explained in dokuwiki at
#   tech:r_wiki:plots:ngs_count_data_plots:start
#
# eg: subsetConditions=c("noSort", "noStain", "nonSP", "SP")
#
# The order of the x-axis will be derived from the levels(phenoData$condition)
# If the subsetConditions is set to a vector, then the order of the x-axis will
# follow the order of the subsetConditions vector.     
countdata.plot_expression <- function(counts, phenoData, genename, subsetConditions=NULL)
{

  if(is.matrix(counts)){
    counts <- as.data.frame(counts)
  }

  if(is.null(levels(phenoData$condition))==TRUE){
    levels(phenoData$condition) <- unique(phenoData$condition) 
  }

  # subset the conditions (if the value is supplied)
  # subset <- lowlevel.subsetConditions(counts=counts, 
  #                   phenoData=phenoData, 
  #                   subsetConditions=subsetConditions)
  # counts <- subset[[1]]
  # phenoData <- subset[[2]]

  # if(is.null(subsetConditions)==FALSE) {
  #   levels(phenoData$condition) <- subsetConditions
  # }

  genedata <- counts[which(rownames(counts)==genename),]
  plotdata <- stack(genedata)
  colnames(plotdata) <- c("counts", "experiment")
  plotdata <- merge(plotdata,phenoData, by="experiment", stringsAsFactors=FALSE)

  plotdata$experiment <- ordered(plotdata$experiment, levels= as.character(phenoData$experiment))
  plotdata$condition <- ordered(plotdata$condition, levels= levels(phenoData$condition))

  samplemean <- aggregate(plotdata$counts, list(condition=plotdata$condition),subset=counts, mean)
  samplemean$label <- rep("mean",dim(samplemean)[1])
  colnames(samplemean)[2] <- "mcounts"
  #    condition mcounts label
  # 1        trt  233.75  mean
  # 2      untrt  250.25  mean

  p <- ggplot() +
  geom_point(data=plotdata, mapping=aes(x=condition, y=counts, color=replicate), size=3, show.legend=T) +
  geom_text(data=plotdata, mapping=aes(x=condition, y=counts, label=label, color=replicate), hjust=0, vjust=0, size=4, show.legend=F) +
  geom_point(aes(x=condition, y=mcounts, fill="mean"), data=samplemean, size=3, show.legend=F) +
  theme(legend.title=element_blank()) +
  ggtitle(genename) +
  xlab("Sample Name")  

  #==== old code snippet ====#
  # samplemean <- aggregate(plotdata$counts, list(condition=plotdata$condition),subset=counts, mean)
  # samplemean$label <- rep("mean",dim(samplemean)[1])
  # #    condition      x label
  # # 1        trt 233.75  mean
  # # 2      untrt 250.25  mean
  # 
  # p <- ggplot() +
  # geom_point(aes(y=counts, x=condition,  label=label, color=replicate), 
  #   data=plotdata, position=position_jitter(width=.1,height=0), size=3) + 
  # geom_text(aes(y=counts, x=condition,  label=label, color=replicate), 
  #   data=plotdata, hjust=0, vjust=0, size=4) +
  # geom_point(aes(y=x, x=condition), data=samplemean, shape=17,size=3) +
  # ggtitle(genename) +
  # xlab("Sample Name") +
  # guides(colour=FALSE)

  return(p)
}
# This is to visualize a vector of expression plots one by one by clicking enter.
iterate.expression_plots <- function(counts, phenoData, genenames, 
  subsetConditions=NULL){
  op <- par(ask=TRUE)
  for (n in genenames){
      print(countdata.plot_expression(counts, phenoData, n, 
        subsetConditions=subsetConditions))
  }
  par(op)
}

################################################################################


########################### HEATMAP & DENDROGRAM ###############################
countdata.heatmap_dendrogram = function (counts, phenoData, subsetConditions=NULL, ...){

  if(is.matrix(counts)){
    counts <- as.data.frame(counts)
  }

  # subset the conditions (if the value is supplied)
  subset <- lowlevel.subsetConditions(counts=counts, 
                    phenoData=phenoData, 
                    subsetConditions=subsetConditions)
  counts <- subset[[1]]
  phenoData <- subset[[2]]

  colnames(counts) <- 
    sapply(colnames(counts), function(x) 
      as.vector(phenoData$label)[which(phenoData$experiment==x)]
      )

  library("pheatmap")
  library("RColorBrewer")

  # calculate the euclidean distance.
  sampleDists <- dist( t( counts ) )
  sampleDistMatrix <- as.matrix( sampleDists )

  colors <- colorRampPalette( rev(brewer.pal(9, "Blues")) )(255)
  pheatmap(sampleDistMatrix,
           clustering_distance_rows=sampleDists,
           clustering_distance_cols=sampleDists,
           col=colors, ...)
}
################################################################################


############################# edgeR MDS plot ###################################

countdata.edger_mds = function(counts, phenoData, subsetConditions=NULL, ...) {

  # subset the conditions (if the value is supplied)
  subset <- lowlevel.subsetConditions(counts=counts, 
                    phenoData=phenoData, 
                    subsetConditions=subsetConditions)
  counts <- subset[[1]]
  phenoData <- subset[[2]]

  require(ggplot2)
  require(edgeR)


  # Filter Low Expressing Genes [edgeR Vignette]
  # --------------------------------------------
  # - Genes with very low counts across all libraries provide little evidence 
  #   for differential expression.
  # - These genes should be filtered out prior to further analysis.
  # - As a rule of thumb, genes are kept if they are expressed in at least one 
  #   condition. 
  # - Usually a gene is required to have a count of 5-10 in a library to be 
  #   considered expressed in that library. 
  # - Users should also filter with count-per-million (CPM) rather than 
  #   filtering on the counts directly, as the latter does not account for 
  #   differences in library sizes between samples.
  # - A CPM of 1 corresponds to a count of 6-7 in the smallest sample.

                    #####################################

  # renames the columns to short names to produce a readable plot.
  colnames(counts) <- 
    sapply(colnames(counts), function(x) 
      as.vector(phenoData$label)[which(phenoData$experiment==x)]
      )

  # groups #
  Treat <- factor(phenoData$condition)

  # DGEList object #
  y <- DGEList(counts=counts, group=Treat)

  # Filtering #
  keep <- rowSums(cpm(y)>2) >= 3
  table(keep)
  y <- y[keep,, keep.lib.sizes=FALSE]

  # TMM Normalization #
  y <- calcNormFactors(y)
  y$samples

  # Data exploration #
  plotMDS(y,...)

}
################################################################################


########################### Scatter Plot Matrix ################################
# helps in identifying and speculating if the samples are mislabelled.
countdata.scatterplot.matrix <- function(counts, phenoData, subsetConditions=NULL,
            remove.maxvalue=FALSE, fit=c("lmFit", "smoothingSpline"), ...) {
# USAGE: 
#   countdata.scatterplot.matrix(counts=counts.org[,-c(1:3)], 
#     phenoData=phenoData.org, 
#     subsetConditions=c("d6.hierg.pcr","d16.hierg","d16.hierg.pcr"),
#     main="Scatter Plot Matrix (RAW Counts)")


# subset the conditions (if the value is supplied)
subset <- lowlevel.subsetConditions(counts=counts, 
                  phenoData=phenoData, 
                  subsetConditions=subsetConditions)
counts <- subset[[1]]
phenoData <- subset[[2]]

# Filter the Genes with low counts and zero variance
counts <- lowlevel.filterRawData(counts)

# Remove max values in the data
  # get the index of all the max values
if(remove.maxvalue == TRUE){
  maxval.ind <- apply(counts, 2, function(x) which(x==max(x) ))
  counts <- counts[-maxval.ind,]
}

# Change the colnames of the count data
colnames(counts) <- 
  sapply(colnames(counts), function(x) 
    as.vector(phenoData$label)[which(phenoData$experiment==x)]
    )


#> Normalized correlation plots of all the libraries

  # panel.smooth function is built in.
  # panel.cor puts correlation in upper panels, size proportional to correlation
  panel.cor <- function(x, y, digits=2, prefix="", cex.cor, ...)
  {
    usr <- par("usr"); on.exit(par(usr))
    par(usr = c(0, 1, 0, 1))
    r <- abs(cor(x, y))
    txt <- format(c(r, 0.123456789), digits=digits)[1]
    txt <- paste(prefix, txt, sep="")
    if(missing(cex.cor)) cex.cor <- 0.8/strwidth(txt)
    text(0.5, 0.5, txt, cex = cex.cor * r)
  }
  
  panel.lmFit <- function (x, y, col = par("col"), bg = NA, pch = par("pch"), 
    cex = 1, col.smooth = "red", span = 2/3, iter = 3, ...) 
  {
      points(x, y, pch = pch, col = col, bg = bg, cex = cex)
      ok <- is.finite(x) & is.finite(y)
      if (any(ok)) 
          abline(lm(y[ok] ~ x[ok]), col="red", lwd=2)
  }

  # fit based plot
  if(fit[1] == "smoothingSpline"){
    pairs(counts, lower.panel=panel.cor, upper.panel = panel.smooth, pch=20, lwd=2, ...)
  } else if (fit[1] == "lmFit"){
    pairs(counts, lower.panel=panel.cor, upper.panel = panel.lmFit, pch=20, ...)
  }  
  
  
  
  # pairs(counts, lower.panel=panel.cor, upper.panel = panel.smooth, pch=20,
  #     main="Scatterplot Matrix", sub="normalized counts", ylim=c(0,threshold), xlim=c(0,threshold) )
  
  #title(sub="normalized counts with correlation values")
  #title(main="Scatterplot Matrix")
}
####################################################################################################



########################## Pairwise Scatter Plot ###############################
#> right: Pairwise Scatterplot of BC3 and BC4. - with normalized counts & without extreme values
#   - correction: The colors and the legend were removed from the scatter plot. Because you are plotting
#                 BC3 & BC4 against each other. You can't distinguish them from each other on the scatter plot.
#   - pairwise scatterplots can identify biases in gene expresssion between two particular conditions

countdata.scatterplot <- function(counts, remove.outliers=FALSE, remove.maxvalue=FALSE, color=FALSE, 
                                  fit=c("lmFit", "smoothingSpline")) {
# you have to supply the X and Y as a data frame. 


  # Filter the Genes with low counts and zero variance
  # counts <- lowlevel.filterRawData(counts)

  # You should almost never remove outliers from your data!!!
  # if(remove.outliers==TRUE) {
  #   counts <- lowlevel.remove.outliers (counts)
  # }

  # Sometimes, a single max value can make your plot look ugly. remove such values.
  if(remove.maxvalue==TRUE) {
    # if the max value of both the columns in a data frame if found at the same row
    if(which(counts[,1]==max(counts[,1])) == which(counts[,2]==max(counts[,2])) )
    counts <- counts[-which(counts[,1]==max(counts[,1])),]
  }

  # plot the dummy
  # plot(counts,ylim=c(0,threshold), xlim=c(0,threshold), xlab="BC3 normalized counts", ylab="BC4 normalized counts")
  plot(counts, xlab=colnames(counts)[1], ylab=colnames(counts)[2], pch=20)
  #plot(counts, xlab=colnames(counts)[1], ylab=colnames(counts)[2], pch=20, xlim=c(-11,11), ylim=c(-11,11))
  if(any(counts < 0)) {
      abline(h = 0, v = 0, col = "black")
    }
  #main="title name"

    #== calculate correlation
    # if `abs` is used, -1 becomes 1; but correlation coefficient lies between -1 and +1
      #cortable <- abs(cor(counts)) # absolute correlation value
      cortable <- cor(counts) # correlation value

  # type the correlation on to the plot
  # anything in .() will be evaluated; ~ adds some space
  #text(bquote("r" ~ "=" ~ .(round(cortable[1,2], digits=2)) ) )


    # add the gray background
  #rect(par("usr")[1],par("usr")[3],par("usr")[2],par("usr")[4],col = "gray93")

    # add the white grid
  #grid(col="white", lwd=2, lty=1)

  # plot the points
  #   col=c("dodgerblue1","darkgoldenrod1") # will alternate the colors for the points
  if(color==TRUE){
    points(counts, col=c("dodgerblue1","darkgoldenrod1"), pch=20)
    title(main=bquote("r" ~ "=" ~ .(round(cortable[1,2], digits=2)) ))
    } else {
    #points(counts, pch=20)
    title(main=bquote("r" ~ "=" ~ .(round(cortable[1,2], digits=2)) ))
    }
  
  # add the fit
  if(fit[1] == "smoothingSpline"){
    smoothingSpline = smooth.spline(counts[,1], counts[,2], spar=1)
    lines(smoothingSpline, col='red', lwd=2)
  } else if (fit[1] == "lmFit"){
    abline(lm(counts[,2] ~ counts[,1]), col="red", lwd=2)
  }
}
