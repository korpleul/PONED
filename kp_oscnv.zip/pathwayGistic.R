# TODO: Add comment
# 
# Author: kathrin
###############################################################################


# memory
memory.limit(8000)

# required packages
require("graph")
require("BioNet")
require("igraph")
require("RBGL")

# load cn genes
load(file='rd/genes_GISTIC.Rd')
load(file='rd/HPDRrelease9.rd') # release 9
#	[1] "gistic.genes" "hprd.ids"     "ppi"          "ppi.nel"

# map genes on ppi
ppi.nodes <- nodes(ppi.nel)
ppi.nodes <- ppi.nodes[ppi.nodes!="-"]
(ppi.nel <- (subNetwork(ppi.nodes, ppi.nel)))
#A graphNEL graph with undirected edges
#Number of Nodes = 9520 
#Number of Edges = 37048 
entrez.idx <- match(gistic.genes[,1], ppi.nodes)
#  	> sum(is.na(entrez.idx))
#	[1] 377
sub.nodes <- gistic.genes[!is.na(entrez.idx),] # 449 included in biogrid!

# linker matrix
ppi.matrix <- as(ppi.nel, "matrix")
sub.ft <- list()
counter <- 1
for(i in 1:length(sub.nodes[,1])){
	neighbors <- rownames(ppi.matrix)[which(ppi.matrix[sub.nodes[i,1],]>0)]
	if(length(neighbors)>0){
		sub.ft[[counter]] <- cbind(Altered=sub.nodes[i,1], Linker=neighbors[!(neighbors%in%sub.nodes[i,1])])
		counter <- counter+1
	}
}
sub.ft <- do.call("rbind", sub.ft)
sub.ft <- unique(t(apply(sub.ft, 1, sort)))
con.matrix <- ftM2adjM(as.matrix(sub.ft), edgemode="undirected")
idx.degree <- which(rowSums(con.matrix) >= 1) # 2815
con.matrix <- con.matrix[idx.degree, idx.degree]
linker.nodes <- rownames(con.matrix)[-which(rownames(con.matrix)%in%sub.nodes[,1])] # 2367
no.linker <- linker.nodes[which(rowSums(con.matrix[linker.nodes,])==1)] # 1650
altered.nodes <-  rownames(con.matrix)[which(rownames(con.matrix)%in%sub.nodes[,1])] #  449 altered genes
con.matrix <- con.matrix[!(rownames(con.matrix)%in%no.linker), !(rownames(con.matrix)%in%no.linker)] # 1928
idx.degree <- which(rowSums(con.matrix) >= 1) # 1091
con.matrix <- con.matrix[idx.degree, idx.degree]
linker.nodes <- rownames(con.matrix)[-which(rownames(con.matrix)%in%sub.nodes)] # 716 linker
altered.nodes <-  rownames(con.matrix)[which(rownames(con.matrix)%in%sub.nodes)] #  374 altered genes
##
degree.biogrid <- graph::degree(ppi.nel)
p.linker <- NULL
for(i in 1:length(linker.nodes)){
	degree.sub <- sum(con.matrix[linker.nodes[i],])
	degree.global <- degree.biogrid[linker.nodes[i]]
	p.linker <- c(p.linker, phyper(degree.sub, degree.global,length(degree.biogrid)-degree.global,length(sub.nodes[,1]), lower.tail=FALSE))	
}
fdr.linker <- p.adjust(p.linker, method="fdr")
names(p.linker) <- names(fdr.linker) <- linker.nodes
sig.linker <- linker.nodes[fdr.linker < 0.05] # 35 0.01, 253 0.05
all.nodes <- c(sig.linker, altered.nodes) # 627
sig.matrix <- con.matrix[all.nodes, all.nodes]
idx.degree <- which(rowSums(sig.matrix) >= 1) # 519
sig.matrix <- sig.matrix[idx.degree, idx.degree]
sig.matrix[sig.matrix > 0] <- 1
(sig.nel <- largestComp(as(sig.matrix, "graphNEL")))
#	A graphNEL graph with undirected edges
#	Number of Nodes = 190 - 501
#	Number of Edges = 197 - 835 
saveNetwork(sig.nel, name="AlteredGenes linker", file='tables/gistic_genes_linker_0.5', type='sif')
linker <- nodes(sig.nel)[!(nodes(sig.nel)%in%sub.nodes)] # 247
altered <- nodes(sig.nel)[(nodes(sig.nel)%in%sub.nodes)] # 254
linker.na <- paste(linker,"= linker")
altered.na <- paste(altered, "= altered")
type.na <- c("nodeType",altered.na, linker.na)
write(type.na, file="tables/nodeType.NA")
##
sig.igraph <- igraph.from.graphNEL(sig.nel, weight=FALSE)
communitites <-  edge.betweenness.community (sig.igraph, directed = FALSE, edge.betweenness = TRUE, merges = TRUE, bridges = TRUE, modularity = TRUE, membership = TRUE)
community.na <- paste(communitites$names,"=",communitites$membership)
community.na <- c("community",community.na)
modularity.na <- paste(communitites$names,"=",communitites$modularity)
modularity.na <- c("modularity",modularity.na)
write(community.na, file="tables/community.NA")
write(modularity.na, file="tables/modularity.NA")
##
observed.mod <- modularity(sig.igraph, communitites$membership) # observed 0.6570935
save(observed.mod, sig.nel, fdr.linker, p.linker, communitites, file="rd/GISTIC_network.Rd")


### significant connectivity within network sample 449 nodes without replacment
set.seed(21)
ppi.matrix <- as(ppi.nel, "matrix")
ppi.nodes <- nodes(ppi.nel)
rand.edges <- NULL
rand.comp <- NULL
perm <- 1:1000
for(i in perm){
	rand.nodes <- sample(ppi.nodes, size=length(sub.nodes[,1]), replace=FALSE) 
	# linker matrix
	sub.ft <- list()
	counter <- 1
	for(j in 1:length(rand.nodes)){
		neighbors <- rownames(ppi.matrix)[which(ppi.matrix[rand.nodes[j],]>0)]
		if(length(neighbors)>0){
			sub.ft[[counter]] <- cbind(Altered=rand.nodes[j], Linker=neighbors[!(neighbors%in%rand.nodes[j])])
			counter <- counter+1
		}
	}
	sub.ft <- do.call("rbind", sub.ft)
	sub.ft <- unique(t(apply(sub.ft, 1, sort)))
	con.matrix <- ftM2adjM(as.matrix(sub.ft), edgemode="undirected")
	
	idx.degree <- which(rowSums(con.matrix) >= 1) # 2816
	con.matrix <- con.matrix[idx.degree, idx.degree]
	linker.nodes <- rownames(con.matrix)[-which(rownames(con.matrix)%in%rand.nodes)] # 2367
	no.linker <- linker.nodes[which(rowSums(con.matrix[linker.nodes,])==1)] # 1650
	altered.nodes <-  rownames(con.matrix)[which(rownames(con.matrix)%in%rand.nodes)] #  449 altered genes
	con.matrix <- con.matrix[!(rownames(con.matrix)%in%no.linker), !(rownames(con.matrix)%in%no.linker)] # 1928
	idx.degree <- which(rowSums(con.matrix) >= 1) # 1091
	con.matrix <- con.matrix[idx.degree, idx.degree]
	linker.nodes <- rownames(con.matrix)[-which(rownames(con.matrix)%in%rand.nodes)] # 716 linker
	altered.nodes <-  rownames(con.matrix)[which(rownames(con.matrix)%in%rand.nodes)] #  374 altered genes
	##
	degree.biogrid <- graph::degree(ppi.nel)
	p.linker <- NULL
	for(j in 1:length(linker.nodes)){
		degree.sub <- sum(con.matrix[linker.nodes[j],])
		degree.global <- degree.biogrid[linker.nodes[j]]
		p.linker <- c(p.linker, phyper(degree.sub, degree.global,length(degree.biogrid)-degree.global,length(rand.nodes), lower.tail=FALSE))	
	}
	fdr.linker <- p.adjust(p.linker, method="fdr")
	names(p.linker) <- names(fdr.linker) <- linker.nodes
	sig.linker <- linker.nodes[fdr.linker < 0.05] # 35 0.01, 253 0.05
	all.nodes <- c(sig.linker, altered.nodes) # 627
	sig.matrix <- con.matrix[all.nodes, all.nodes]
	idx.degree <- which(rowSums(sig.matrix) >= 1) # 519
	sig.matrix <- sig.matrix[idx.degree, idx.degree]
	sig.matrix[sig.matrix > 0] <- 1
	sig.nel <- largestComp(as(sig.matrix, "graphNEL"))
	rand.comp <- c(rand.comp, numNodes(sig.nel))
	rand.edges <- c(rand.edges, length(sig.nel@edgeData@data)/2)	
}
# store number nodes, number edges
save(rand.comp, rand.edges, file="rd/Test_connectivity.Rd")
#> sum(rand.edges > 835)/1000
#[1] 0.035
#> sum(rand.comp > 501)/1000
#[1] 0.025
pdf(file="figures/Connectivity_gistic.pdf")
hist(rand.edges, breaks=100, col="lightblue", main="Edges", xlab="number of interactions",ylab="frequency")
abline(v=835, col="red")
text(x=835, y =15, labels="observed edges\n835, p-value=0.035" , pos=4)
hist(rand.comp, breaks=100, col="lightblue", main="Nodes", xlab="number of genes",ylab="frequency")
abline(v=501, col="red")
text(x=501, y =15, labels="observed genes\n501, p-value=0.025" , pos=4)
dev.off()


## modularity significance
##
load(file="rd/GISTIC_network.Rd")
set.seed(7)
ppi.m <- as(sig.nel, 'matrix')
save(ppi.m, file="rd/PPIgistic_matrix.Rd")
idx.array <- which(ppi.m==1,arr.ind=TRUE)
idx.array <- idx.array[idx.array[,1] > idx.array[,2],] # as matrix is symetric! length 112848
save(idx.array, file="rd/PPIgistic_index.Rd")
gc()
perm <- 1:1000
rand.modularity <- NULL
counter <- 1
for(i in 1:length(perm)){
	load(file="rd/PPIgistic_matrix.Rd")
	load(file="rd/PPIgistic_index.Rd")
	edge.swapping <- 4*dim(idx.array)[1] # 
	for(j in 1:edge.swapping){
		idx.nodes <- sample(1:dim(idx.array)[1],size=2,replace=FALSE)
		ww.swap <- idx.array[idx.nodes,] 
		a1 <- ww.swap[1,1]
		a2 <- ww.swap[1,2]
		b1 <- ww.swap[2,1]
		b2 <- ww.swap[2,2]
		if((a1!=b1)&(a1!=b2)&(a2!=b1)&(a2!=b2)){
			if(runif(1) > 0.5){
				if((ppi.m[a1,b1]==0)&(ppi.m[a2,b2]==0)){
					ppi.m[a1,a2] <- 0
					ppi.m[b1,b2] <- 0
					ppi.m[a2,a1] <- 0
					ppi.m[b2,b1] <- 0            
					ppi.m[a1,b1] <- 1
					ppi.m[a2,b2] <- 1
					ppi.m[b1,a1] <- 1
					ppi.m[b2,a2] <- 1
					# swap index of columns
					idx.array[idx.nodes[1],2] <- b1
					idx.array[idx.nodes[2],1] <- a2
				}
			}else{
				if((ppi.m[a1,b2]==0)&(ppi.m[a2,b1]==0)){
					ppi.m[a1,a2] <- 0
					ppi.m[b1,b2] <- 0
					ppi.m[a2,a1] <- 0
					ppi.m[b2,b1] <- 0            
					ppi.m[a1,b2] <- 1
					ppi.m[a2,b1] <- 1
					ppi.m[b2,a1]<- 1
					ppi.m[b1,a2] <- 1
					# swap index of columns
					idx.array[idx.nodes[1],2] <- b2
					idx.array[idx.nodes[2],2] <- a2				
				}
			}	
		}
	}
	r <- graph.adjacency(ppi.m, mode="undirected")
	rand.comm <- edge.betweenness.community (r, directed = FALSE, edge.betweenness = TRUE, merges = TRUE, bridges = TRUE, modularity = TRUE, membership = TRUE)
	rand.modularity <- c(rand.modularity, modularity(r, rand.comm$membership))
	counter <- counter+1
	if(i%%10 == 0){
		gc()
		print(paste("Round:",i))
	}
}
## save random modularity due to edge swapping
mean.mod <- mean(rand.modularity)
sd.mod <- sd(rand.modularity)
scaled.mod <- (observed.mod - mean.mod)/sd.mod # 15.9
p.val <- sum(rand.modularity > observed.mod)/1000
pdf(file="figures/Modularity_gistic.pdf")
hist(rand.modularity, breaks=50, xlim =c(0.54,0.68),col="lightblue", main="Network modularity", xlab="average modularity",ylab="frequency")
abline(v=observed.mod, col="red")
text(x=observed.mod, y =20, labels="observed modularity\n0.66, p-value=0\nscore=15.9" , pos=2)
dev.off()
save(scaled.mod, rand.modularity, file="rd/Test_modularity.Rd")
save(scaled.mod, rand.modularity, file="rd/Test_modularity.Rd")


