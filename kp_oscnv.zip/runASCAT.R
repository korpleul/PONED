# ASCAT acc von Loo et al.,
# 
# Author: kathrin
###############################################################################

#####
source("ASCAT2.1/ascat.R")
memory.limit(8000)
ascat.bc = ascat.loadData("ASCAT2.1/LRR.txt","ASCAT2.1/BAF.txt")
save(ascat.bc, file='rd/AscatBC.Rd')
load(file='rd/AscatBC.Rd')
#
ascat.plotRawData(ascat.bc)
#
source("ASCAT2.1/predictGG.R")
platform = "AffySNP6"
ascat.gg = ascat.predictGermlineGenotypes(ascat.bc, platform)
save(ascat.gg, file='AscatGG.Rd')
load(file='rd/AscatGG.Rd')
#
ascat.bc = ascat.aspcf(ascat.bc,ascat.gg=ascat.gg)
save(ascat.bc, file='AscatBC.Rd')
load(file='rd/AscatBC.Rd')
#
ascat.plotSegmentedData(ascat.bc)
#
ascat.output = ascat.runAscat(ascat.bc) --> totoro_ascat on local lab PC!
save(ascat.output, file='rd/AscatOutput.Rd')

##
load(file='rd/AscatOutput.Rd')
load(file='rd/AscatBC.Rd')
#> summary(ascat.output$ploidy)
#Min. 1st Qu.  Median    Mean 3rd Qu.    Max. 
#1.521   1.962   2.850   2.862   3.384   5.516 
#> summary(ascat.output$aberrantcellfraction)
#Min. 1st Qu.  Median    Mean 3rd Qu.    Max. 
#0.44    0.61    0.69    0.69    0.77    0.96 

# organize ascat segs
organize.ascat.segments <- function(ascat.output, markers){
	samp.names <- colnames(ascat.output$nA)
	failed.names <- ascat.output$failedarrays
	if(length(failed.names) >= 1) {
		failed.locations <- which(is.na(ascat.output$segments))
		new.samp.names <- 1:length(ascat.output$segments)
		new.samp.names[-c(failed.locations)] <- samp.names
		new.samp.names[failed.locations] <- failed.names
		samp.names <- new.samp.names
	}
	out.seg <- matrix(0, 0, ncol = 7)
	colnames(out.seg) <- c("SampleID", "Chr", "Start", "End",
			"nProbes", "nA", "nB")
	if(length(ascat.output$segments) != length(samp.names)) {
		stop
	}
	for(i in 1:length(ascat.output$segments)) {
		sample.segs <- ascat.output$segments[[i]]
		if (class(sample.segs) != "matrix") {
			next
		}
		if(class(sample.segs) == "matrix") {
			for(j in 1:nrow(sample.segs)) {
				tmp <- markers[sample.segs[j, 1]:sample.segs[j,2], ]
				if(!all(tmp[, 1] == tmp[1, 1])) {
					stop("Error in segmentation")
				}
				chr <- as.character(tmp[1, 1])
				seg.start <- as.character(tmp[1, 2])
				seg.end <- as.character(tmp[nrow(tmp), 2])
				nProbes <- nrow(tmp)
				out.seg <- rbind(out.seg, c(samp.names[i], chr,
								seg.start, seg.end, nProbes, sample.segs[j,3:4]))
			}
			gc()
		}
	}
	out.seg[out.seg[, 2] == "X", 2] <- 23
	out.seg <- as.data.frame(out.seg)
	out.seg[, 2:7] <- apply(out.seg[, 2:7], 2, function(x) {
				as.numeric(as.character(x))
			})
	out.seg[, 1] <- as.character(out.seg[, 1])
	return(out.seg)
}
ascat.segments <- organize.ascat.segments(ascat.output, ascat.bc$SNPpos)
save(ascat.segments, file='rd/AscatSegmentsAllele.Rd')

## exclude non OS samples and failed arrays
targets <- read.table(file="ASCAT2.1/targets.csv", header=T, sep=";", stringsAsFactors=F)
no.os <- targets$Probe[which(targets$OS==0)]
failed <- ascat.output$failedarrays
no.os <- unique(c(failed, no.os)) # 4 samples no OS and failed arrays
#	[1] "OS_017" "OS_026" "OS_118" "OS_113"
idx.os <- which(ascat.segments$SampleID%in%no.os) # 41 remain
ascat.segments <- ascat.segments[-idx.os,]
rownames(ascat.segments) <- 1:dim(ascat.segments)[1]
save(ascat.segments, file='rd/AscatSegmentsAllele.Rd')
load(file='rd/AscatSegmentsAllele.Rd')

# total cn acc to aspcf segments see ascta.bc$Tumor_LogR_segmented values to enter gistic
#First, add the allele specific copy numbers to get total copy number (tcn)
ascat.segments.tcn <- cbind(ascat.segments[,1:5], ascat.segments[,6]+ascat.segments[,7])
colnames(ascat.segments.tcn)[6] <- "tcn"
save(ascat.segments.tcn, file='rd/AscatSegmentsTCN.Rd')
load(file='rd/AscatSegmentsTCN.Rd')

#ASCAT fits its output to a model with a given ploidy, so tcn must be corrected for ploidy to determine gain and loss
#Extract ploidy calls
ploidy <- ascat.output$ploidy
names(ploidy) <- colnames(ascat.output$nA)

#Correct TCN for ploidy
ascat.segments.tcn.p <- cbind(ascat.segments.tcn[,1:5], TCN=ascat.segments.tcn[,6] - ploidy[match(ascat.segments.tcn[,1], names(ploidy))])
head(ascat.segments.tcn.p)
save(ascat.segments.tcn.p, file='rd/AscatSegmentsTCNploidy.Rd')
load(file='rd/AscatSegmentsTCNploidy.Rd')

### filter segmental duplications, DGVs, gaps, segments having less than 10 markers, < -0.6 AND < 0.6!
require("GenomicRanges")
gaps <- read.table(file="data/gaps_hg19.txt", header=T, sep='\t')
idx.tc <- which(gaps$type=="telomere" | gaps$type=="centromere")
gaps <- gaps[idx.tc,]
gaps <- sort(GRanges(seqnames=gaps$chrom, ranges=IRanges(start=gaps$chromStart, end=gaps$chromEnd)))
dgv <- read.table(file="data/dgvMerged_hg19.bed", header=F, sep='\t',skip=1)
dgv <- sort(GRanges(seqnames=dgv$V1, ranges=IRanges(start=dgv$V2, end=dgv$V3)))
sedup <- read.table(file="data/segDups_hg19.bed", header=F, sep='\t',skip=1)
sedup <- sort(GRanges(seqnames=sedup$V1, ranges=IRanges(start=sedup$V2, end=sedup$V3)))
chrom <- paste("chr",c(1:22,"X"), sep="")
gaps <- keepSeqlevels(gaps, chrom[-23])
dgv <- keepSeqlevels(dgv, chrom)
sedup <- keepSeqlevels(sedup, chrom)
chrom <- as.character(c(1:23))
names(chrom) <- paste("chr",c(1:22,"X"), sep="")
gaps <- renameSeqlevels(gaps, chrom[-23])
dgv <- renameSeqlevels(dgv, chrom)
sedup <- renameSeqlevels(sedup, chrom)
gaps <- reduce(gaps)
dgv <- reduce(dgv)
sedup <- reduce(sedup)
#######

## filter on segments 
idx.ploidy <- which(ascat.segments.tcn.p$TCN <= -0.9 | ascat.segments.tcn.p$TCN > 0.9)
ascat.filter <- ascat.segments.tcn.p[idx.ploidy, ]
idx.probes <- which(ascat.filter$nProbes >= 10)
ascat.filter <- ascat.filter[idx.probes, ] # 7315 segments/ 6212 (0.9)
ascat.gr <- GRanges(seqnames=ascat.filter$Chr, ranges=IRanges(start=ascat.filter$Start, end=ascat.filter$End))
idx.gaps <- findOverlaps(ascat.gr,gaps) # just overlaps with centromere region, centromere region within cn alteration spanned by more than 100 SNPs!
#gaps.width <- ranges(idx.gaps, ranges(ascat.gr), ranges(gaps))@width
#idx.50 <- which(gaps.width/width(ascat.gr[idx.gaps@queryHits])> 0.5)
#idx.gaps <- idx.gaps[idx.50]
ascat.filter <- ascat.filter[-idx.gaps@queryHits,] #7228/ 6152

#### known variations in healthy population from DGV database
#ascat.gr <- GRanges(seqnames=ascat.filter$Chr, ranges=IRanges(start=ascat.filter$Start, end=ascat.filter$End))
#idx.dgv <- findOverlaps(ascat.gr,dgv) # 
#dgv.width <- ranges(idx.dgv, ranges(ascat.gr), ranges(dgv))@width
#idx.50 <- which(dgv.width/width(ascat.gr[idx.dgv@queryHits])> 0.5)# 3093
#idx.dgv <- idx.dgv[idx.50]
#ascat.filter <- ascat.filter[-unique(idx.dgv@queryHits),] # 4135

### segmental duplications
ascat.gr <- GRanges(seqnames=ascat.filter$Chr, ranges=IRanges(start=ascat.filter$Start, end=ascat.filter$End))
idx.sedup <- findOverlaps(ascat.gr,sedup) # just overlaps with centromere region, centromere region within cn alteration spanned by more than 100 SNPs!
sedup.width <- ranges(idx.sedup, ranges(ascat.gr), ranges(sedup))@width
idx.50 <- which(sedup.width/width(ascat.gr[idx.sedup@queryHits])> 0.5)
idx.sedup <- idx.sedup[idx.50]
ascat.filter <- ascat.filter[-idx.sedup@queryHits,] # 7151/6077

###
idx.x <- which(ascat.filter$Chr == 23)
ascat.filter <- ascat.filter[-idx.x,] # 6825/ 5781
save(ascat.filter, file='rd/AscatSegmentsFiltered.Rd')
load(file='rd/AscatSegmentsFiltered.Rd')

ascat.gain <- ascat.filter[ascat.filter$TCN > 0,] # 3722 /3348
ascat.loss <- ascat.filter[ascat.filter$TCN < 0,] # 3103 / 2433
gain.gr <- GRanges(seqnames=ascat.gain$Chr, ranges=IRanges(start=ascat.gain$Start, end=ascat.gain$End))
loss.gr <- GRanges(seqnames=ascat.loss$Chr, ranges=IRanges(start=ascat.loss$Start, end=ascat.loss$End))
save(ascat.gain, ascat.loss, loss.gr, gain.gr, file='rd/GainLossSamples_ASCAT.Rd')
load(file='rd/GainLossSamples_ASCAT.Rd')

### segments per allele
idx.loss <- as.numeric(rownames(ascat.loss))
loss.allele <- ascat.segments[idx.loss,]
idx.gain <- as.numeric(rownames(ascat.gain))
gain.allele <- ascat.segments[idx.gain,]
save(gain.allele, loss.allele, loss.gr, gain.gr, file='rd/GainLossAllele_ASCAT.Rd')
load(file='rd/GainLossAllele_ASCAT.Rd')

###
require("BSgenome.Hsapiens.UCSC.hg19")
hg19 <- BSgenome.Hsapiens.UCSC.hg19
hg19.chrom <- seqlengths(hg19)
hg19.chrom <- hg19.chrom[paste("chr",1:22,sep='')]
names(hg19.chrom) <- as.character(1:22)
seqlengths(gain.gr) <- hg19.chrom
seqlengths(loss.gr) <- hg19.chrom
gain.cov <- coverage(gain.gr)
loss.cov <- coverage(loss.gr)
###
loss.cov.gr <- list()
for(i in 1:length(loss.cov)){
	ranges <- successiveIRanges(runLength(loss.cov[[i]]))
	cov <- runValue(loss.cov[[i]])
	seq <- rep(names(loss.cov)[i], times=length(cov))
	loss.cov.gr[[i]] <- GRanges(seqnames=seq, ranges=ranges, coverage=cov)
}
help <- c(loss.cov.gr[[1]],loss.cov.gr[[2]],loss.cov.gr[[3]],loss.cov.gr[[4]],loss.cov.gr[[5]],loss.cov.gr[[6]],loss.cov.gr[[7]],loss.cov.gr[[8]],loss.cov.gr[[9]],loss.cov.gr[[10]],
		loss.cov.gr[[11]],loss.cov.gr[[12]],loss.cov.gr[[13]],loss.cov.gr[[14]],loss.cov.gr[[15]],loss.cov.gr[[16]],loss.cov.gr[[17]],loss.cov.gr[[18]],loss.cov.gr[[19]],loss.cov.gr[[20]],loss.cov.gr[[21]],
		loss.cov.gr[[22]])
loss.cov.gr <- help
# > summary(elementMetadata(loss.cov.gr)$coverage)
# Min. 1st Qu.  Median    Mean 3rd Qu.    Max. 
#  0.000   6.000   9.000   8.772  11.000  19.000 
###
elementMetadata(loss.cov.gr)$frequency <- elementMetadata(loss.cov.gr)$coverage/41
## gain
gain.cov.gr <- list()
for(i in 1:length(gain.cov)){
	ranges <- successiveIRanges(runLength(gain.cov[[i]]))
	cov <- runValue(gain.cov[[i]])
	seq <- rep(names(gain.cov)[i], times=length(cov))
	gain.cov.gr[[i]] <- GRanges(seqnames=seq, ranges=ranges, coverage=cov)
}
help <- c(gain.cov.gr[[1]],gain.cov.gr[[2]],gain.cov.gr[[3]],gain.cov.gr[[4]],gain.cov.gr[[5]],gain.cov.gr[[6]],gain.cov.gr[[7]],gain.cov.gr[[8]],gain.cov.gr[[9]],gain.cov.gr[[10]],
		gain.cov.gr[[11]],gain.cov.gr[[12]],gain.cov.gr[[13]],gain.cov.gr[[14]],gain.cov.gr[[15]],gain.cov.gr[[16]],gain.cov.gr[[17]],gain.cov.gr[[18]],gain.cov.gr[[19]],gain.cov.gr[[20]],gain.cov.gr[[21]],
		gain.cov.gr[[22]])
gain.cov.gr <- help
# > summary(elementMetadata(gain.cov.gr)$coverage)
# Min. 1st Qu.  Median    Mean 3rd Qu.    Max. 
# 0.000   5.000   7.000   6.822   8.000  15.000 
###
elementMetadata(gain.cov.gr)$frequency <- elementMetadata(gain.cov.gr)$coverage/41
#######
seqlengths(gain.cov.gr) <- seqlengths(loss.cov.gr) <- hg19.chrom 
save(loss.cov.gr, gain.cov.gr, file='rd/CNsegments_ASCAT.Rd') ##
#> summary(elementMetadata(loss.cov.gr)$frequency)
#Min. 1st Qu.  Median    Mean 3rd Qu.    Max. 
#0.0000  0.1463  0.2195  0.2140  0.2683  0.4634 
#> summary(elementMetadata(gain.cov.gr)$frequency)
#Min. 1st Qu.  Median    Mean 3rd Qu.    Max. 
#0.0000  0.1220  0.1707  0.1664  0.1951  0.3659 

source("plotIdeogram.r")

loss.frame <- as.data.frame(loss.cov.gr)
gain.frame <- as.data.frame(gain.cov.gr)
cyto <- read.table(file="data/cytoBand_hg19.txt", sep="\t", header=F)
pdf(file="figures/frequencyPlot_ASCAT_0.9.pdf", height=3)
nf <- layout(matrix(c(1:44), 1,44,byrow=T),width=rep(c(3,1,3,1),times=11))#, height=c(1,1))
par(oma=c(0,0,0,0), mar=c(0.5,0.1,0.5,0.1))
for(i in 1:11){
	segs.l <- loss.frame[loss.frame$seqnames==as.character(i),]
	segs.g <- gain.frame[gain.frame$seqnames==as.character(i),]
	max.g <- max(segs.g$coverage)
	max.l <- max(segs.l$coverage)
	max.cov <- NULL
	if(max.g >= max.l){
		if(max.g >= 8){
			max.cov <- max.g
		}else{
			max.cov <- 8
		}
	}else{
		if(max.l >= 8){
			max.cov <- max.l
		}else{
			max.cov <- 8
		}
	}
	#	
	#1
	plot(1,1,type="n",xlim=c(-(max.cov+0.2),0),ylim=c(as.numeric(seqlengths(loss.cov.gr)[i]),0),frame.plot=FALSE,yaxt="n",xaxt="n",ylab="frequency",xlab="",xaxs="i", yaxs="i")
	#lines(x=segs.l$start,y=-(segs.l$coverage),col="darkgreen", type='h')
	rect(ybottom=segs.l$start, xleft=0, ytop=segs.l$end, xright=-(segs.l$coverage), col="darkgreen", border="darkgreen")
	abline(v=-8.2, col='lightgrey', lty='dashed')
	#text(y=segs.l$end[1], x=-8.6,labels="20%",pos=4,col='darkgrey')
	#2
	plotIdeogram(i,cyto.data=cyto)
	#3
	plot(1,1,type="n",xlim=c(0,(max.cov+0.2)),ylim=c(as.numeric(seqlengths(gain.cov.gr)[i]),0),frame.plot=FALSE,yaxt="n",xaxt="n",ylab="frequency",xlab="", xaxs="i",yaxs="i")
	#lines(x=segs.g$start,y=(segs.g$coverage),col="red", type='h')
	rect(ybottom=segs.g$start, xleft=0, ytop=segs.g$end, xright=(segs.g$coverage), col="red", border="red")
	abline(v=8.2, col='lightgrey', lty='dashed')
	#text(y=segs.g$end[1], x=8.6,labels="20%",pos=4,col='darkgrey')
	plot.new()
}
nf <- layout(matrix(c(1:44), 1,44,byrow=T),width=rep(c(3,1,3,1),times=11))#, height=c(1,1))
par(oma=c(0,0,0,0), mar=c(0.5,0.1,0.5,0.1))
for(i in 12:22){
	segs.l <- loss.frame[loss.frame$seqnames==as.character(i),]
	segs.g <- gain.frame[gain.frame$seqnames==as.character(i),]
	max.g <- max(segs.g$coverage)
	max.l <- max(segs.l$coverage)
	max.cov <- NULL
	if(max.g >= max.l){
		if(max.g >= 8){
			max.cov <- max.g
		}else{
			max.cov <- 8
		}
	}else{
		if(max.l >= 8){
			max.cov <- max.l
		}else{
			max.cov <- 8
		}
	}
	#	
	#1
	plot(1,1,type="n",xlim=c(-(max.cov+0.2),0),ylim=c(as.numeric(seqlengths(loss.cov.gr)[i]),0),frame.plot=FALSE,yaxt="n",xaxt="n",ylab="frequency",xlab="",xaxs="i", yaxs="i")
	#lines(x=segs.l$start,y=-(segs.l$coverage),col="darkgreen", type='h')
	rect(ybottom=segs.l$start, xleft=0, ytop=segs.l$end, xright=-(segs.l$coverage), col="darkgreen", border="darkgreen")
	abline(v=-8.2, col='lightgrey', lty='dashed')
	#text(y=segs.l$end[1], x=-8.6,labels="20%",pos=4,col='darkgrey')
	#2
	plotIdeogram(i,cyto.data=cyto)
	#3
	plot(1,1,type="n",xlim=c(0,(max.cov+0.2)),ylim=c(as.numeric(seqlengths(gain.cov.gr)[i]),0),frame.plot=FALSE,yaxt="n",xaxt="n",ylab="frequency",xlab="", xaxs="i",yaxs="i")
	#lines(x=segs.g$start,y=(segs.g$coverage),col="red", type='h')
	rect(ybottom=segs.g$start, xleft=0, ytop=segs.g$end, xright=(segs.g$coverage), col="red", border="red")
	abline(v=8.2, col='lightgrey', lty='dashed')
	#text(y=segs.g$end[1], x=8.6,labels="20%",pos=4,col='darkgrey')
	plot.new()
}
dev.off()
save(loss.cov.gr, gain.cov.gr, loss.frame, gain.frame, file='rd/GainLossFreq_ASCAT.Rd')
load(file='rd/GainLossFreq_ASCAT.Rd')



#########################################################################################################
#########################################################################################################
#########################################################################################################


# allelic imbalances
load(file='rd/AscatSegmentsAllele.Rd')

idx.rows <- as.numeric(rownames(ascat.filter))
ascat.segments <- ascat.segments[idx.rows,] # 5781 rows
ascat.segments <- cbind(ascat.segments, AI = ifelse((ascat.segments$nA!=ascat.segments$nB | ((ascat.segments$nA==0) | (ascat.segments$nB==0))),1,0),LOH=ifelse(((ascat.segments$nA==0) | (ascat.segments$nB==0)) , 1, 0))
ascat.ai <- ascat.segments[ascat.segments$AI==1,]
freq.sample <- table(ascat.ai$SampleID)
#	OS_005 OS_011 OS_016 OS_021 OS_022 OS_028 OS_029 OS_034 OS_037 OS_038 OS_045 
#	12    159     22     44     65    127    121     45     63     63     92 
#	OS_046 OS_049 OS_050 OS_053 OS_072 OS_076 OS_080 OS_081 OS_083 OS_084 OS_085 
#	232    125     83    131    145     12     15    254    161     20     22 
#	OS_086 OS_087 OS_088 OS_089 OS_098 OS_102 OS_103 OS_110 OS_111 OS_115 OS_120 
#	96     80    256     42    102    155    246    204     15     74     23 
#	OS_124 OS_127 OS_137 OS_148 OS_151 OS_156 OS_157 OS_160 
#	117     57    195    122     89    164     92    175 
targets <- read.table(file="ASCAT2.1/targets.csv", header=T, sep=";", stringsAsFactors=F)
idx.targets <- match(targets$Probe, names(freq.sample)) # 37
targets <- targets[!is.na(idx.targets),] # 37
num.ai <- freq.sample[idx.targets[!is.na(idx.targets)]]
idx.good <- which(targets$Prognosis == "Good")
idx.poor <- which(targets$Prognosis == "Poor")
ai.good <- num.ai[idx.good]
ai.poor <- num.ai[idx.poor]
idx.met <- which(targets$Metastases == "yes")
idx.non <- which(targets$Metastases == "no")
ai.met <- num.ai[idx.met]
ai.non <- num.ai[idx.non]

pdf(file='figures/AI_wholeChromosome.pdf')
y <- c(ai.poor,ai.good)
m.poor <- mean(ai.poor)
m.good <- mean(ai.good)
x <- c(rep(1.25, times=length(ai.poor)),rep(1.75, times=length(ai.good)))
col.aber <- c(rep('red', times=length(ai.poor)),rep('green', times=length(ai.good)))
plot(x,y, xlim=c(1,2), axes=F,  xlab='', ylab='# allelic imbalances', type='n')
lines(x=c(1.2,1.3), y=c(m.poor,m.poor), lwd=2, col='grey')
lines(x=c(1.7,1.8), y=c(m.good,m.good), lwd=2, col='grey')
points(x,y,pch=19, col=col.aber)
axis(2)
axis(1, at=c(1.25, 1.75), labels=c('poor','good'))
box()
#
y <- c(ai.met,ai.non)
m.poor <- mean(ai.met)
m.good <- mean(ai.non)
x <- c(rep(1.25, times=length(ai.met)),rep(1.75, times=length(ai.non)))
col.aber <- c(rep('red', times=length(ai.met)),rep('green', times=length(ai.non)))
plot(x,y, xlim=c(1,2), axes=F,  xlab='', ylab='# allelic imbalances', type='n')
lines(x=c(1.2,1.3), y=c(m.poor,m.poor), lwd=2, col='grey')
lines(x=c(1.7,1.8), y=c(m.good,m.good), lwd=2, col='grey')
points(x,y,pch=19, col=col.aber)
axis(2)
axis(1, at=c(1.25, 1.75), labels=c('metastases','metastases-free'))
box()
dev.off()
wilcox.test(ai.poor, ai.good)
##Wilcoxon rank sum test with continuity correction
#data:  seg.met and seg.nmet 
#W = 201.5, p-value = 0.03667
#alternative hypothesis: true location shift is not equal to 0 
t.test(ai.poor, ai.good)
#Welch Two Sample t-test
#data:  ai.poor and ai.good
#t = 2.1137, df = 30.418, p-value = 0.0382
#alternative hypothesis: true difference in means is not equal to 0
#95 percent confidence interval:
#1.929415 110.401467
#sample estimates:
#mean of x mean of y 
#144.81250  88.64706
##
ascat.ai.chr6 <- ascat.ai[ascat.ai$Chr=="6",]
prognosis <- targets$Prognosis
names(prognosis) <-  targets$Probe
metastasis <- targets$Metastases
names(metastasis) <-  targets$Probe
#chr6	61000000	63300000	q11.1	acen
#chr6	63300000	63400000	q11.2	gneg
#chr6	63400000	70000000	q12	gpos100
#chr6	70000000	75900000	q13	gneg
#chr6	75900000	83900000	q14.1	gpos50
#chr6	83900000	84900000	q14.2	gneg
#chr6	84900000	88000000	q14.3	gpos50
#chr6	88000000	93100000	q15	gneg
#chr6	93100000	99500000	q16.1	gpos100
#chr6	99500000	100600000	q16.2	gneg
#chr6	100600000	105500000	q16.3	gpos100
#chr6	105500000	114600000	q21	gneg
#chr6	114600000	118300000	q22.1	gpos75
#chr6	118300000	118500000	q22.2	gneg
#chr6	118500000	126100000	q22.31	gpos100
#chr6	126100000	127100000	q22.32	gneg
#chr6	127100000	130300000	q22.33	gpos75
#chr6	130300000	131200000	q23.1	gneg
#chr6	131200000	135200000	q23.2	gpos50
#chr6	135200000	139000000	q23.3	gneg
#chr6	139000000	142800000	q24.1	gpos75
#chr6	142800000	145600000	q24.2	gneg
#chr6	145600000	149000000	q24.3	gpos75
#chr6	149000000	152500000	q25.1	gneg
#chr6	152500000	155500000	q25.2	gpos50
#chr6	155500000	161000000	q25.3	gneg
#chr6	161000000	164500000	q26	gpos50
#chr6	164500000	171115067	q27	gneg
chr6q.start <-  161000000
chr6q.end <- 171051005
idx.6q <- which(ascat.ai.chr6$End == chr6q.end)  
ascat.ai.chr6q <- ascat.ai.chr6[idx.6q,]
freq.samples <- table(ascat.ai.chr6q$SampleID[ascat.ai.chr6q$LOH==1])
idx.missing <- names(prognosis)[!(names(prognosis)%in%names(freq.samples))]
freq.samples.miss <- rep(0, times=length(idx.missing))
names(freq.samples.miss) <- idx.missing
freq.samples <- c(freq.samples, freq.samples.miss)
metastasis <- metastasis[names(freq.samples)]
idx.good <- which(metastasis == "no")
idx.poor <- which(metastasis == "yes")
ai.good <- freq.samples[idx.good]
ai.poor <- freq.samples[idx.poor]

status <- targets$RIP # 37
status[status=="yes"] <- 1
status[status=="no"] <- 0
status <- as.numeric(status)
months <- targets$FollowupMonths
samples <- targets$Probe
mets <- targets$Metastases
mets[mets=="yes"] <- 1
mets[mets=="no"] <- 0
mets <- as.numeric(mets)
mets.diag <- targets$MetsDiagnosis
mets.diag[mets.diag=="1" | mets.diag=="2"] <- 1
mets.diag[mets.diag!="1"] <- 0
mets.diag[is.na(mets.diag)] <- 0
mets.diag <- as.numeric(mets.diag)
#ploidy.status <- ploidy >= 3

#
require("survival")
d <- data.frame(samples=samples,status=status,months=months,mets=mets,mets.diag=mets.diag) #, ploidy=ploidy.status)
ai <- rep(TRUE, times=37)
ai[which(as.character(d$samples)%in%ascat.ai.chr6q$SampleID)] <- FALSE
loh <- rep(TRUE, times=37)
loh[which(as.character(d$samples)%in%ascat.ai.chr6q$SampleID[ascat.ai.chr6q$LOH==1])] <- FALSE

os.surv <- Surv(d$months, d$status)
os.ai <- survfit(os.surv ~ ai)
os.loh <-  survfit(os.surv ~ loh)
ai.surv <- survdiff(os.surv ~ ai)
loh.surv <- survdiff(os.surv ~ loh)

pdf(file="figures/surv/Module1_survival.pdf")
plot(os.loh, lty = 1, col = c("gray", "green"), main="Module 1 - MAPK9 & MAP3K5")
legend("bottomleft", legend = c("neutral", "deleted"), lty = 1:2, col = c("gray", "green"), box.col="white",box.lwd=0)
legend("bottomright", legend = "Chi-square p-value = 0.0456", box.col="white",box.lwd=0)
box()
dev.off()

pdf(file='figures/AI_chr6q.pdf')
y <- c(ai.poor,ai.good)
m.poor <- mean(ai.poor)
m.good <- mean(ai.good)
x <- c(rep(1.25, times=length(ai.poor)),rep(1.75, times=length(ai.good)))
col.aber <- c(rep('red', times=length(ai.poor)),rep('green', times=length(ai.good)))
plot(x,y, xlim=c(1,2), axes=F,  xlab='', ylab='# allelic imbalances', type='n')
lines(x=c(1.2,1.3), y=c(m.poor,m.poor), lwd=2, col='grey')
lines(x=c(1.7,1.8), y=c(m.good,m.good), lwd=2, col='grey')
points(x,y,pch=19, col=col.aber)
axis(2)
axis(1, at=c(1.25, 1.75), labels=c('poor','good'))
box()
#
y <- c(ai.met,ai.non)
m.poor <- mean(ai.met)
m.good <- mean(ai.non)
x <- c(rep(1.25, times=length(ai.met)),rep(1.75, times=length(ai.non)))
col.aber <- c(rep('red', times=length(ai.met)),rep('green', times=length(ai.non)))
plot(x,y, xlim=c(1,2), axes=F,  xlab='', ylab='# allelic imbalances', type='n')
lines(x=c(1.2,1.3), y=c(m.poor,m.poor), lwd=2, col='grey')
lines(x=c(1.7,1.8), y=c(m.good,m.good), lwd=2, col='grey')
points(x,y,pch=19, col=col.aber)
axis(2)
axis(1, at=c(1.25, 1.75), labels=c('metastases','metastases-free'))
box()
dev.off()
wilcox.test(ai.poor, ai.good)
##Wilcoxon rank sum test with continuity correction
#data:  seg.met and seg.nmet 
#W = 201.5, p-value = 0.0383 AI -- 0.101 LOH
#alternative hypothesis: true location shift is not equal to 0 
t.test(ai.poor, ai.good)
#Welch Two Sample t-test
#data:  ai.poor and ai.good
#t = 2.1137, df = 30.418, p-value = 0.04285
#alternative hypothesis: true difference in means is not equal to 0
#95 percent confidence interval:
#1.929415 110.401467
#sample estimates:
#mean of x mean of y 
#144.81250  88.64706








# plot frequency of gain, loss, allelic imbalance, LOH, CNNAI to define regions of high aberration frequency
# see plotFreq.R
# create matrix among all SNPs with corresponding TCN, TCNploidy, LOH, AI, ...
samplenames <- unique(ascat.segments$SampleID) # 41 samples
#
tcn.p <- list()
tcn <- list()
for(i in 1:length(samplenames)){
	segs.tcnp <- ascat.segments.tcn.p[which(ascat.segments.tcn.p$SampleID%in%samplenames[i]),]
	#
	segs.tcn <- ascat.segments.tcn[which(ascat.segments.tcn$SampleID%in%samplenames[i]),]
	#
	a <- NULL
	b <- NULL
	c <- NULL
	d <- NULL
	for(j in 1:dim(segs.tcnp)[1]){
		b <- c(b, rep(segs.tcnp[j,6], times=as.numeric(segs.tcnp$nProbes)[j]))
		a <- c(a, rep(segs.tcn[j,6], times=as.numeric(segs.tcn$nProbes)[j]))
	}
	tcn.p[[i]] <- b
	tcn[[i]] <- a
	gc()
}
tcn.p <- do.call('rbind',tcn.p)
tcn <- do.call('rbind',tcn)

colnames(tcn.p)  <- colnames(tcn)  <- rownames(ascat.bc$SNPpos) 
rownames(tcn.p)  <- rownames(tcn)  <- samplenames
save(tcn.p, tcn, file='rd/CNbySNPmarker.Rd')

#save(tcn, tcn.p, allele.a, allele.b, file='AlleleTotalCNperSNP.Rd')
#
tcn <- do.call('rbind',tcn)
allele.a <- do.call('rbind',allele.a)
allele.b <- do.call('rbind',allele.b)
colnames(tcn) <- colnames(tcn.p) <- colnames(allele.a) <- colnames(allele.b) <- rownames(ascat.bc$SNPpos)
rownames(tcn) <- rownames(tcn.p) <- rownames(allele.a) <- rownames(allele.b) <- samplenames
save(tcn.p, file='CNbySNPmarker.Rd')
#save(tcn, tcn.p, allele.a, allele.b, file='AlleleTotalCNperSNP_dataframe.Rd')
load(file='AlleleTotalCNperSNP_dataframe.Rd')

#
cn.gain <-  tcn > 2
cn.loss <- tcn < 2
cn.gain.p <- tcn.p > 0.6
cn.loss.p <- tcn.p < -0.6
loh <- allele.a == 0 | allele.b == 0
ai <- allele.a != allele.b
cnnai <- (allele.a == 0 | allele.b == 0) & (tcn.p < 0.6 & tcn.p > -0.6)
save(cn.gain, cn.loss, cn.gain.p, cn.loss.p,loh,cnnai, file='FreqPlots_GLAI.Rd')







# substitute tcn with mean lrr defined by ASPCF to run GISTIC --- worked!
samplenames <- unique(ascat.segments$SampleID) # 41 samples
aspcf.segs <- list()
for(i in 1:length(samplenames)){
	#
	idx.sample <- which(colnames(ascat.bc$Tumor_LogR_segmented)%in%samplenames[i])
	lrr <- ascat.bc$Tumor_LogR_segmented[,idx.sample]
	count <- 1
	segs <- list()
	j <- 1
	for(help in 1:length(lrr)){
		value <- lrr[j]
		k <- j
		while(value == lrr[k]){
			k <- k+1
			if((k-1) == length(lrr)) break		
		}
		segs[[count]] <- cbind(SampleID=samplenames[i], Chr=as.character(ascat.bc$SNPpos[j,1]), Start=as.character(ascat.bc$SNPpos[j,2]),End=as.character(ascat.bc$SNPpos[(k-1),2]),nProbes=k-j, LRR=value )
		j <- k
		count <- count+1
		if((k-1) == length(lrr)) break
	}
	aspcf.segs[[i]] <- do.call('rbind',segs)
}
aspcf.segs <- do.call('rbind', aspcf.segs)
save(aspcf.segs, file='rd/AspcfSegments.Rd')
load(file='AspcfSegments.Rd')

# for use in GISTIC
write.table(aspcf.segs, file='GISTIC/segmentationfile.txt', sep='\t',quote=FALSE, row.names=F,col.names=T)
write.table(ascat.bc$SNPpos, file='GISTIC/markers.txt', sep='\t',quote=FALSE, row.names=T, col.names=F)
write(samplenames, file='GISTIC/arraylist.txt')

## GISTIC segments using ASCAT segments
samplenames.all <- colnames(ascat.bc$Tumor_LogR_segmented)
samplenames <- unique(ascat.segments$SampleID)
output.segs <- ascat.output$segments[which(samplenames.all%in%samplenames)]
###
num.segments <- list()
lrr.segments <- list()
for(i in 1:length(samplenames)){
	idx <- which(ascat.segments.tcn.p$SampleID%in%samplenames[i])
	segs <- ascat.segments.tcn.p[idx,]
	num.segments[[i]] <- which((segs$nProbes>=10)&((segs$TCN>=0.6)| (segs$TCN<=-0.6)))
	lrr <- NULL
	for(j in 1:dim(segs)[1]){
		start <- output.segs[[i]][j,1]
		end <- output.segs[[i]][j,2]
		lrr <- c(lrr, mean(ascat.bc$Tumor_LogR_segmented[start:end,samplenames[i]]))
	}
	lrr.segments[[i]] <- cbind(segs[,1:5],LRR=lrr)
}
## segments containing at least 10 markers and >=|0.6| gain/loss
save(num.segments,lrr.segments, file='rd/SegmentsPerSample_0.6.Rd')
new.segments <- do.call('rbind', lrr.segments) # 12945 segments
write.table(new.segments, file='GISTIC/segmentationfile_ascat.txt', sep='\t',quote=FALSE, row.names=F,col.names=T)


segs <- list()
for(i in 1:length(lrr.segments)){
	segs[[i]] <- lrr.segments[[i]][num.segments[[i]],]
}
segs <- do.call('rbind', segs) # 6367 segments in total
#> summary(segs$LRR)
#	    Min.  1st Qu.   Median     Mean  3rd Qu.     Max. 
#	-2.33400 -0.27410  0.13090  0.02956  0.30640  1.71600 
save(segs, file='rd/Segments_0.6.Rd')

## get segments per sample
samples <- segs$SampleID[segs$Chr!=23] # 6058
sample.segs <- table(samples)
save(sample.segs, file='rd/SegmentsSamples_0.9.Rd')



##########
## GISTIC segments using ASCAT segments
load(file='AspcfSegments.Rd')
samplenames <- unique(aspcf.segs[,1])
no.os <- c('OS_111','OS_118','OS_120')
###
num.segments <- list()
lrr.segments <- list()
for(i in 1:length(samplenames)){
	idx <- which(aspcf.segs[,1]%in%samplenames[i])
	segs <- aspcf.segs[idx,]
	num.segments[[i]] <- which((segs[,5]>=10)&((as.numeric(segs[,6])>=0.2)| (as.numeric(segs[,6])<=-0.2)))
	lrr.segments[[i]] <- segs
	for(j in 1:dim(segs)[1]){
		start <- output.segs[[i]][j,1]
		end <- output.segs[[i]][j,2]
		lrr <- c(lrr, mean(ascat.bc$Tumor_LogR_segmented[start:end,samplenames[i]]))
	}
	lrr.segments[[i]] <- cbind(segs[,1:5],LRR=lrr)
}
## segments containing at least 10 markers and >=|0.12| gain/loss
save(num.segments,lrr.segments, file='rd/SegmentsPerSample_aspcf.Rd')

segs <- list()
for(i in 1:length(num.segments)){
	segs[[i]] <- lrr.segments[[i]][num.segments[[i]],]
}
segs <- do.call('rbind', segs) # 5131 segments in total
save(segs, file='rd/Segments_aspcf.Rd')

#> summary(as.numeric(segs[,6]))
#	     Min.  1st Qu.   Median     Mean  3rd Qu.     Max. 
#    -2.33400 -0.30690 -0.14520 -0.05281  0.23840  1.71600 

## get segments per sample
sample.segs <- unlist(lapply(num.segments, length))
names(sample.segs) <- samplenames
save(sample.segs, file='rd/SegmentsSamples.Rd')