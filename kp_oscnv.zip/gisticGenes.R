# TODO: Add comment
# 
# Author: kathrin
###############################################################################

# memory
memory.limit(8000)

# packages
require('DRI')
require("genoset")
library('org.Hs.eg.db')
require("GenomicRanges")

#
load(file="rd/GeneMirRanges.Rd")
load(file='rd/AscatBC.Rd')
load(file='rd/AscatOutput.Rd')

targets <- read.table(file="ASCAT2.1/targets.csv", header=T, sep=";", stringsAsFactors=F)
no.os <- targets$Probe[which(targets$OS==0)]
failed <- ascat.output$failedarrays
no.os <- unique(c(failed, no.os)) # 4 samples no OS and failed arrays
#	[1] "OS_017" "OS_026" "OS_118" "OS_113"

#expression data
eset <- read.table(file='results/AffyEset/tables/Eset_OS.csv', sep=',',header=T, stringsAsFactors=F)
eset <- eset[,!(colnames(eset)%in%no.os)]
# average gene cn data
locData.rd <- RangedData(ranges=IRanges(start=ascat.bc$SNPpos$Position,width=1,names=rownames(ascat.bc$SNPpos)),space=ascat.bc$SNPpos$Chr,universe="hg19")
idx.chr <- which(space(locData.rd)%in%(1:22))
locData.rd <- locData.rd[idx.chr,]

#rownames(tcn.p)  <- rownames(locData.rd)
genoset.ds <- GenoSet( locData=locData.rd, foo=as.matrix(ascat.bc$Tumor_LogR_segmented[idx.chr,]), annotation="SNP6" )
#> isGenomeOrder(gene.gr)
#[1] FALSE
gene.gr <- toGenomeOrder(gene.gr)
lrr.genes <- rangeSampleMeans(gene.gr, genoset.ds, "foo")
save(lrr.genes, file="rd/LRRGenes.Rd")
load(file="rd/LRRGenes.Rd")

## gistic peaks
gistic.peaks <- read.table("GISTIC/gistic_0.12_10/0.12.all_lesions.conf_75.txt", header=T, sep="\t", stringsAsFactors=FALSE)
idx.cn <- grep("CN values", gistic.peaks$Unique.Name)
gistic.cn <- gistic.peaks[idx.cn,] # significant 16 amplifications, 35 deletions
gistic.peaks <- gistic.peaks[-idx.cn,]
# genes
genes.amp <- readLines("GISTIC/gistic_0.12_10/0.12.amp_genes.conf_75.txt")#
genes.amp <- do.call("rbind",strsplit(genes.amp, split="\t")) # 16 peaks
amp <- NULL
loc.amp <- NULL
for(i in 2:dim(genes.amp)[2]){
	for(j in 5:length(genes.amp[,i])){
		if(genes.amp[j,i] != ""){
			amp <- c(amp, genes.amp[j,i]) # 420 genes
			loc.amp <- c(loc.amp, genes.amp[4,i])
		}
	}
}
amp <- gsub("\\[","", amp)
amp <- gsub("\\]","", amp)
#
genes.del <- readLines("GISTIC/gistic_0.12_10/0.12.del_genes.conf_75.txt")
genes.del <- do.call("rbind",strsplit(genes.del, split="\t")) # 35 peaks
del <- NULL
loc.del <- NULL
for(i in 2:dim(genes.del)[2]){
	for(j in 5:length(genes.del[,i])){
		if(genes.del[j,i] != ""){
			del <- c(del, genes.del[j,i]) # 1974 genes
			loc.del <- c(loc.del, genes.del[4,i])
		}
	}
}
del <- gsub("\\[","", del)
del <- gsub("\\]","", del)
idx.dups <- duplicated(del)
del <- del[!idx.dups]
loc.del <- loc.del[!idx.dups]
#genes all
genes <-  read.table("GISTIC/gistic_0.12_10/0.12.all_thresholded.by_genes.txt", header=T, sep="\t", stringsAsFactors=FALSE)
idx.loc.amp <- match(amp, genes$Gene.Symbol) 
ids.amp <- genes[idx.loc.amp,2] # 420
genes.amp <- genes[idx.loc.amp,1:3]
genes.amp <- lrr.genes[rownames(lrr.genes)%in%ids.amp,] # 396
idx.loc.del <- match(del, genes$Gene.Symbol) 
ids.del <- genes[idx.loc.del,2] # 1972
genes.del <- lrr.genes[rownames(lrr.genes)%in%ids.del,] # 1795
genes.del <- genes[idx.loc.del,1:3]

# one intersecetion GLIS3
del.cn <- cbind(Symbol=genes.del$Gene.Symbol, GeneID=genes.del$Locus.ID, PeakLoc=loc.del, gistic.cn[unlist(lapply(loc.del, grep, gistic.cn$Wide.Peak.Limits)),])
amp.cn <- cbind(Symbol=genes.amp$Gene.Symbol, GeneID=genes.amp$Locus.ID, PeakLoc=loc.amp, gistic.cn[unlist(lapply(loc.amp, grep, gistic.cn$Wide.Peak.Limits)),])
del.peaks <- cbind(Symbol=genes.del$Gene.Symbol, GeneID=genes.del$Locus.ID, PeakLoc=loc.del, gistic.peaks[unlist(lapply(loc.del, grep, gistic.peaks$Wide.Peak.Limits)),])
amp.peaks <- cbind(Symbol=genes.amp$Gene.Symbol, GeneID=genes.amp$Locus.ID, PeakLoc=loc.amp, gistic.peaks[unlist(lapply(loc.amp, grep, gistic.peaks$Wide.Peak.Limits)),])
## table for draft
table.amp <- list()
uni.peaks <- unique(amp.peaks$Unique.Name) # 16
for(i in 1:length(uni.peaks)){
	idx <- which(amp.peaks$Unique.Name%in%uni.peaks[i])
	freq <- sum(amp.peaks[idx[1], 13:53] > 0)/41
	table.amp[[i]] <- cbind(Peak= uni.peaks[i], Cytoband=amp.cn$Descriptor[idx[1]], Coordinates=gsub("\\(.*","",amp.cn$Wide.Peak.Limits[idx[1]]), NumGenes=length(idx), Q.value=amp.cn$q.values[idx[1]], Frequency=freq)
}
table.amp <- do.call("rbind", table.amp)
table.del <- list()
uni.peaks <- unique(del.peaks$Unique.Name) # 35
for(i in 1:length(uni.peaks)){
	freq <- sum(del.peaks[idx[1], 13:53] > 0)/41
	idx <- which(del.peaks$Unique.Name%in%uni.peaks[i])
	table.del[[i]] <- cbind(Peak= uni.peaks[i], Cytoband=del.cn$Descriptor[idx[1]], Coordinates=gsub("\\(.*","",del.cn$Wide.Peak.Limits[idx[1]]), NumGenes=length(idx), Q.value=del.cn$q.values[idx[1]], Frequency=freq)
}
table.del <- do.call("rbind", table.del)
write.table(table.del, file="tables/GISTIC_delPeaks.csv", col.names=T, row.names=F, sep=";")
write.table(table.amp, file="tables/GISTIC_ampPeaks.csv", col.names=T, row.names=F, sep=";")

# correlate with eset
# eset gain and loss
idx.del <- which(eset$GeneID%in%rownames(genes.del)) # 1078 genes out of 1972
idx.del <- which(eset$GeneID%in%genes.del$Locus.ID) # 1078 genes out of 1972
idx.genes <- which(eset$GeneID%in%rownames(lrr.genes))# 14673
eset.all <- eset[idx.genes,]
eset.del <- eset[idx.del,]
ids.del <- eset.del$GeneID
idx.amp <- which(eset$GeneID%in%rownames(genes.amp)) # 282 out of 396
idx.amp <- which(eset$GeneID%in%genes.amp$Locus.ID) # 282 out of 396
eset.amp <- eset[idx.amp,]
ids.amp <- eset.amp$GeneID
save(eset.del,ids.del, eset.amp,ids.amp, file='rd/GainLossEset_GISTIC.Rd')
load(file='rd/GainLossEset_GISTIC.Rd')

ids.del <- cbind(GeneID=ids.del, Symbol=as.character(del.peaks[match(ids.del,del.cn[,2]),1])) # 1084, 1063 unique
ids.amp <- cbind(GeneID=ids.amp, Symbol=as.character(amp.peaks[match(ids.amp,amp.cn[,2]),1])) # 284, 278 unique
write.table(ids.del,file='tables/Gistic_deletedGenes_affy.csv', row.names=F, sep=';',quote=T)
write.table(ids.amp,file='tables/Gistic_amplifGenes_affy.csv', row.names=F, sep=';',quote=T)

## cn in eset same gene order
idx.del <- match(ids.del[,1],rownames(genes.del))
idx.del <- match(ids.del[,1],genes.del$Locus.ID)
idx.genes <- match(eset.all$GeneID, rownames(lrr.genes))
del.peaks <- del.peaks[idx.del, ]
del.cn <- del.cn[idx.del, ]
lrr.del <- genes.del[idx.del,]
lrr.all <- lrr.genes[idx.genes,]

idx.amp <- match(ids.amp[,1],rownames(genes.amp))
idx.amp <- match(ids.amp[,1],genes.amp$Locus.ID)
amp.peaks <- amp.peaks[idx.amp, ]
amp.cn <- amp.cn[idx.amp, ]
lrr.amp <- genes.amp[idx.amp,]

##
idx.samples <- match(colnames(eset), colnames(lrr.del)) # 37 overlapping samples + GeneID, Symbol columns
idx.samples <- match(colnames(eset), colnames(del.cn)) # 37 overlapping samples + GeneID, Symbol columns
idx.samples <- match(colnames(eset.all), colnames(lrr.all))

eset.del <- eset.del[,!is.na(idx.samples)]
cn.del <- del.cn[,idx.samples[!is.na(idx.samples)]]
cn.del <- lrr.del[,idx.samples[!is.na(idx.samples)]]
eset.amp <- eset.amp[,!is.na(idx.samples)]
cn.amp <- amp.cn[,idx.samples[!is.na(idx.samples)]]
cn.amp <- lrr.amp[,idx.samples[!is.na(idx.samples)]]
eset.all <- eset.all[,!is.na(idx.samples)]
cn <- lrr.all[,idx.samples[!is.na(idx.samples)]]

peak.amp <- cn.amp[,-c(38:39)]
peak.amp[peak.amp > 0.9] <- 2
peak.amp[peak.amp > 0.12 & peak.amp <= 0.9] <- 1
peak.amp[peak.amp < -0.9] <- -2
peak.amp[peak.amp < -0.12 & peak.amp >= -0.9] <- -1
peak.amp[peak.amp > -0.12 & peak.amp < 0.12] <- 0
#
peak.del <- cn.del[,-c(38:39)]
peak.del[peak.del > 0.9] <- 2
peak.del[peak.del > 0.12 & peak.del <= 0.9] <- 1
peak.del[peak.del < -0.9] <- -2
peak.del[peak.del < -0.12 & peak.del >= -0.9] <- -1
peak.del[peak.del > -0.12 & peak.del < 0.12] <- 0

# correlation
require('DRI')
pc.del.genes <- drcorrelate(as.matrix(cn.del[,-c(38:39)]), as.matrix(eset.del[,-c(38:39)]), method='pearson')
# > summary(pc.del.genes)
# Min.  1st Qu.   Median     Mean  3rd Qu.     Max. 
# -0.53290  0.09497  0.27060  0.24760  0.40720  0.73870 
ids.del <- cbind(ids.del, PC=pc.del.genes) # 1084, 1063 unique
write.table(ids.del,file='tables/Gistic_deletedGenes_affy.csv', row.names=F, sep=';',quote=T)
pc.amp.genes <- drcorrelate(as.matrix(cn.amp[,-c(38:39)]), as.matrix(eset.amp[,-c(38:39)]), method='pearson')
# > summary(pc.amp.genes)
# Min.  1st Qu.   Median     Mean  3rd Qu.     Max. 
# -0.1043  0.1656  0.3322  0.3373  0.4970  0.8812
ids.amp <- cbind(ids.amp, PC=pc.amp.genes) # 1084, 1063 unique
write.table(ids.amp,file='tables/Gistic_amplifGenes_affy.csv', row.names=F, sep=';',quote=T)


# generate null distribution del for FDR calculation (1,000 permutations)
null.del <- drcorrelate.null(as.matrix(cn.del[,-c(38:39)]), as.matrix(eset.del[,-c(38:39)]), method="pearson", perm=1000)
# identify the correlation cutoff corresponding to your desired FDR
del.cutoff <- dri.fdrCutoff(pc.del.genes, null.del, targetFDR=0.1, bt=TRUE)
#> n.cutoff
# 645.0000  number of sign genes  0.227 # cutoff
del.cutoff <- del.cutoff[2]
# retrieve all genes that are significant at the determined cutoff, and

# generate null distribution amp for FDR calculation (1,000 permutations)
null.amp <- drcorrelate.null(as.matrix(cn.amp[,-c(38:39)]), as.matrix(eset.amp[,-c(38:39)]), method="pearson", perm=1000)
# identify the correlation cutoff corresponding to your desired FDR
amp.cutoff <- dri.fdrCutoff(pc.amp.genes, null.amp, targetFDR=0.1, bt=TRUE)
#> n.cutoff
# 207.0000  number of sign genes  0.182 # cutoff
amp.cutoff <- amp.cutoff[2]

# calculate gene-specific FDRs
gene_id <- rownames(cn.del)
hugo <- toTable(org.Hs.egSYMBOL2EG)
gene_name <- hugo$symbol[match(gene_id, hugo$gene_id)]
chr <- as.character(seqnames(gene.gr[rownames(cn.del)]))
nuc <- start(gene.gr[rownames(cn.del)])
Results.del <- dri.sig_genes(del.cutoff, pc.del.genes, null.del, gene_id=rownames(cn.del), gene_name=gene_name,chr=chr, nuc=nuc, method="drcorrelate") # 627
write.table(Results.del$positive, file="tables/PCdeletedGenes_GISTIC.csv", sep=";", row.names=F, col.names=T, quote=T)
#
gene_id <- rownames(cn.amp)
hugo <- toTable(org.Hs.egSYMBOL2EG)
gene_name <- hugo$symbol[match(gene_id, hugo$gene_id)]
chr <- as.character(seqnames(gene.gr[rownames(cn.amp)]))
nuc <- start(gene.gr[rownames(cn.amp)])
Results.amp <- dri.sig_genes(amp.cutoff, pc.amp.genes, null.amp, gene_id=rownames(cn.amp), gene_name=gene_name,chr=chr, nuc=nuc, method="drcorrelate") # 207
write.table(Results.amp$positive, file="tables/PCamplifiedGenes_GISTIC.csv", sep=";", row.names=F, col.names=T, quote=T)
#
#> intersect(Results.del$positive[,3],Results.amp$positive[,3])
#[1] "169792"
gistic.genes <- cbind(GeneID=unique(c(Results.del$positive[,3],Results.amp$positive[,3])),Symbol=unique(c(Results.del$positive[,4],Results.amp$positive[,4]))) # 826
save(gistic.genes, file='rd/genes_GISTIC.Rd')

save(pc.del.genes,null.del,del.cutoff,pc.amp.genes,null.amp,amp.cutoff,Results.del, Results.amp, file='rd/PearsonCorrelationGenes_GISTIC.Rd')
load(file='rd/PearsonCorrelationGenes_GISTIC.Rd')


## percent altered in ASCAT related to ploidy
load(file='rd/AscatSegmentsTCNploidy.Rd')
ascat.ranges <- GRanges(seqnames=ascat.segments.tcn.p$Chr, ranges=IRanges(start=ascat.segments.tcn.p$Start, end=ascat.segments.tcn.p$End))
genes.amp <- gene.gr[which(names(gene.gr)%in%Results.amp$positive[,3]),]
idx.amp <- findOverlaps(genes.amp, ascat.ranges, type="any")
amp.ascat <- matrix(0, ncol=41, nrow=205, dimnames=list(names(genes.amp), unique(ascat.segments.tcn.p$SampleID)))
for(i in 1:dim(amp.ascat)[1]){
	index <- idx.amp[idx.amp@queryHits==i]
	if(length(index@queryHits)==dim(amp.ascat)[2]){
		segs <- ascat.segments.tcn.p[index@subjectHits,]
		samples.amp <- segs$SampleID[segs$TCN > 0.9]
		amp.ascat[i, samples.amp] <- 1 
	}else{
		segs <- ascat.segments.tcn.p[index@subjectHits,]
		dups <- segs$SampleID[duplicated(segs$SampleID)]
		idx.dups <- which(segs$SampleID%in%dups)
		segs.uni <- segs[-idx.dups,]
		samples.uni <- segs.uni$SampleID[segs.uni$TCN >= 0.9]
		amp.ascat[i, samples.uni] <- 1
		for(j in 1:length(dups)){
			segs.dups <- segs[segs$SampleID%in%dups[j],]
			if(any(segs.dups$TCN>= 0.9)){
				amp.ascat[i, dups[j]] <- 1
			}
		}
	}
}
#
genes.del <- gene.gr[which(names(gene.gr)%in%Results.del$positive[,3]),]
idx.del <- findOverlaps(genes.del, ascat.ranges, type="any")
del.ascat <- matrix(0, ncol=41, nrow=622, dimnames=list(names(genes.del), unique(ascat.segments.tcn.p$SampleID)))
for(i in 1:dim(del.ascat)[1]){
	index <- idx.del[idx.del@queryHits==i]
	if(length(index@queryHits)==dim(del.ascat)[2]){
		segs <- ascat.segments.tcn.p[index@subjectHits,]
		sample.del <- segs$SampleID[segs$TCN <= -0.9]
		del.ascat[i, sample.del] <- -1 
	}else{
		segs <- ascat.segments.tcn.p[index@subjectHits,]
		dups <- segs$SampleID[duplicated(segs$SampleID)]
		idx.dups <- which(segs$SampleID%in%dups)
		segs.uni <- segs[-idx.dups,]
		sample.uni <- segs.uni$SampleID[segs.uni$TCN <= -0.9]
		del.ascat[i, sample.uni] <- -1
		for(j in 1:length(dups)){
			segs.dups <- segs[segs$SampleID%in%dups[j],]
			if(any(segs.dups$TCN> 0.9)){
				del.ascat[i, dups[j]] <- -1
			}
		}
	}
}
ascat.gistic <- rbind(amp.ascat, del.ascat) # one duplicated
save(ascat.gistic, file="rd/ASCAT_CN_gistic.Rd")



### correlate all
pc.genes <- drcorrelate(as.matrix(cn), as.matrix(eset.all), method='pearson')
d.all <- density(pc.genes)
plot(d.all, col="grey", lty="dashed")
pc.gistic <- pc.genes[which(names(pc.genes)%in%unique(c(ids.del, ids.amp)))] 
d.gistic <- density(pc.gistic)
lines(d.gistic)
freq.genes <- unique(c(rownames(cn.loss.freq), rownames(cn.gain.freq)))
#> length(freq.genes)
#[1] 8507
pc.freq <- pc.genes[which(names(pc.genes)%in%freq.genes)] # 5616
d.freq <- density(pc.freq)
lines(d.freq, col="red")
pdf(file='figures/PCorrelation_gistic.pdf')
plot(density(pc.genes), xlim=c(-1,1), lty=2,lwd=1, col='grey', xlab='correlation','')
lines(density(pc.freq), col='blue', lty=1, lwd=1)
lines(density(pc.gistic), col='red', lty=1, lwd=1)
dev.off()

ks.test(pc.freq, pc.genes, alternative='less')
#Two-sample Kolmogorov-Smirnov test
#data:  pc.freq and pc.genes
#D^- = 0.0737, p-value < 2.2e-16
#alternative hypothesis: the CDF of x lies below that of y

ks.test(pc.gistic, pc.genes, alternative='less')
#Two-sample Kolmogorov-Smirnov test
#data:  pc.freq and pc.genes
#D^- = 0.1182, p-value = 7.882e-16
#alternative hypothesis: the CDF of x lies below that of y

ks.test(pc.gistic, pc.freq, alternative='less')
#Two-sample Kolmogorov-Smirnov test
#data:  pc.freq and pc.genes
#D^- = 0.0556, p-value = 0.001167
#alternative hypothesis: the CDF of x lies below that of y
