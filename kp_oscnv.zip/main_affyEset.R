# Analysis Affymetrix 1ST Exon array
# 
# Author: kathrin
###############################################################################


# load required libraries
require('oligo')
require('pd.hugene.1.0.st.v1')
require('affy')
require('affyPLM')

# dir
data.dir <- 'data/mR/'
filenames <- dir(data.dir,pattern='.CEL')


# read-in affymetrix exon array data HuGene-1st-v1
raw.data <- ReadAffy(filenames=filenames,celfile.path=data.dir)
#	AffyBatch object
#	size of arrays=1050x1050 features (32 kb)
#	cdf=HuGene-1_0-st-v1 (32321 affyids)
#	number of samples=49
#	number of genes=32321
#	annotation=hugene10stv1
#	notes=
save(raw.data,file='results/AffyEset/rd/RawData.rd')


# raw expression matrix
raw.exprs <- exprs(raw.data)
# Quality control
# --------------------------------------------------------------------------------------|

# PLM = Probe Level Model --------------------------------------------------------------
# Bolstad, B. M., Collin, F., Brettschneider, J., Simpson, K., Cope, L., Irizarry, R. A.
# & Speed, T. P. (2005). Bioinformatics and Computational Biology Solutions Using R and
# Bioconductor chapter Quality Assessment of Affymetrix GeneChip Data,pp. 33-47.
QC.all <- fitPLM(raw.data)
save(QC.all,file='results/AffyEset/rd/QCall.rd')
load('results/AffyEset/rd/QCall.rd')
# image plots of PLM residuals' signs
#jpeg(filename='mouse/figures/PLM-residuals.jpg',width=2000,height=2000)
#dimplot <- ceiling(sqrt(length(filenames)))
#par(mfrow=c(dimplot,dimplot)) 
#for(chip.nr in 1:length(filenames)) image(QC.all,which=chip.nr,type='sign.resids')
#dev.off()
# boxplot RLE = Relative Log Expression
pdf(file='results/AffyEset/figures/RLE-plot.pdf')
Mbox(QC.all, las=2)
dev.off()
# boxpolot NUSE = Normalized Unscaled Standard Errors
pdf(file='results/AffyEset/figures/NUSE-plot.pdf')
NUSE(QC.all, las=2)
dev.off()
# average-linkage clustering
# distance matrix compute using euclidean distances
raw.dist <- dist(t(raw.exprs))
# UPGMA using average-linkage
raw.hclust <- hclust(raw.dist,method='average')
pdf(file='results/AffyEset/figures/RawHclust.pdf')
plot(raw.hclust,main='Raw data, hs (average-linkage)')
dev.off()

# image plots of PLM residuals' signs
samples <- sub('.CEL','',sampleNames(raw.data))
for(chip.nr in 1:length(filenames)){
	png(filename=paste('results/AffyEset/figures/PLM-residuals_',chip.nr,'.png',sep=''))
	par(mfrow=c(2,2))
	image(raw.data[,chip.nr],main=paste(samples[chip.nr],'- raw data'))
	image(QC.all,which=chip.nr,type='weights',main=paste(samples[chip.nr],'- weights'))
	image(QC.all,which=chip.nr,type='resids',main=paste(samples[chip.nr],'- residuals'))
	image(QC.all,which=chip.nr,type='sign.resids',main=paste(samples[chip.nr],'- sign residuals'))
	dev.off()
}

pdf(file='results/AffyEset/figures/boxplot_rawData.pdf')
par(mar=c(7,5,5,2))
boxplot(raw.data, las=2, col='yellow', main='Raw data', names=samples, las=2, ylab='Log2 intensities')
dev.off()

# MA plots
pdf(file='results/AffyEset/figures/maplot_plmData.pdf', height=200, width=400)
par(mfrow=c(5,10))
MAplot(QC.all, cex=0.75)
mtext('M', 2, outer=TRUE)
mtext('A', 1, outer=TRUE)
dev.off()

# read in cels using oligo
targets <- read.table(file='data/targets.csv', header=TRUE, sep=',',stringsAsFactors=FALSE)
filenames <- paste(targets$Probe,'.CEL',sep='')
filenames <- filenames[targets$mRNA==1&targets$miRNA==1]
(raw.oligo <- read.celfiles(filenames=paste(data.dir,filenames,sep='')))
#	GeneFeatureSet (storageMode: lockedEnvironment)
#	assayData: 1102500 features, 45 samples 
#	element names: exprs 
#	protocolData
#	rowNames: OS_005.CEL OS_011.CEL ... OS_160.CEL (45 total)
#	varLabels: exprs dates
#	varMetadata: labelDescription channel
#	phenoData
#	rowNames: OS_005.CEL OS_011.CEL ... OS_160.CEL (45 total)
#	varLabels: index
#	varMetadata: labelDescription channel
#	featureData: none
#	experimentData: use 'experimentData(object)'
#	Annotation: pd.hugene.1.0.st.v1 
save(raw.oligo,file='results/AffyEset/rd/RawOligo.rd')

# normalize eset using rma, just include core probes in summary
(rma.oligo <- oligo::rma(raw.oligo, background=TRUE, normalize=TRUE, target="core"))
#	ExpressionSet (storageMode: lockedEnvironment)
#	assayData: 33297 features, 45 samples 
#	element names: exprs 
#	protocolData
#	rowNames: OS_005.CEL OS_011.CEL ... OS_160.CEL (45 total)
#	varLabels: exprs dates
#	varMetadata: labelDescription channel
#	phenoData
#	rowNames: OS_005.CEL OS_011.CEL ... OS_160.CEL (45 total)
#	varLabels: index
#	varMetadata: labelDescription channel
#	featureData: none
#	experimentData: use 'experimentData(object)'
#	Annotation: pd.hugene.1.0.st.v1 
# annotate normalized eset data
anno <- getNetAffx(rma.oligo, type = 'transcript')
featureData(rma.oligo) <- anno
save(rma.oligo,file='results/AffyEset/rd/RmaOligo.rd')
load(file='results/AffyEset/rd/RmaOligo.rd')

# generate annotation table
#	> varLabels(featureData(rma.oligo))
#	[1] "transcriptclusterid" "probesetid"          "seqname"            
#	[4] "strand"              "start"               "stop"               
#	[7] "totalprobes"         "geneassignment"      "mrnaassignment"     
#	[10] "swissprot"           "unigene"             "gobiologicalprocess"
#	[13] "gocellularcomponent" "gomolecularfunction" "pathway"            
#	[16] "proteindomains"      "crosshybtype"        "category"     
anno <- cbind(tclusterid=featureData(rma.oligo)[[1]],psetid=featureData(rma.oligo)[[2]],seqname=featureData(rma.oligo)[[3]],strand=featureData(rma.oligo)[[4]],
		start=featureData(rma.oligo)[[5]], stop=featureData(rma.oligo)[[6]],
		numprobes=featureData(rma.oligo)[[7]],geneassignment=featureData(rma.oligo)[[8]],mrnaassignment=featureData(rma.oligo)[[9]],
		unigene=featureData(rma.oligo)[[11]],goBP=featureData(rma.oligo)[[12]],goCC=featureData(rma.oligo)[[13]],goMF=featureData(rma.oligo)[[14]],pathway=featureData(rma.oligo)[[13]],
		crosshyb=featureData(rma.oligo)[[17]],category=featureData(rma.oligo)[[18]])
# controls
#	> table(anno[,16])
#	     control->affx control->bgp->antigenomic          flmrna->unmapped 
#                     57                        45                       227 
#                   main            normgene->exon          normgene->intron 
#      	      28536                      1195                      2904 
is.main <- grep('main', anno[,16])

# eset matrix
eset <- exprs(rma.oligo)[is.main,]
anno.eset <- anno[is.main,]
is.cross <- which(anno.eset[,15]==1) # no crosshybridization allowed
eset <- eset[is.cross,]
anno.eset <- anno.eset[is.cross,]
#  25557 transcript cluster remain!

# get rid of genes with no variation and overall samples low expression
#	> summary(as.numeric(eset))
#	 Min. 1st Qu.  Median    Mean 3rd Qu.    Max. 
#     2.093   3.802   5.024   5.207   6.329  13.380 
is.small <- eset <= quantile(as.numeric(eset), prob=0.30)
eset.ctrl <-  exprs(rma.oligo)[which(anno[,16]%in%c('control->bgp->antigenomic')),]
png(filename='results/AffyEset/figures/hist_antiGenomic.png')
hist(as.numeric(eset.ctrl), breaks=50, main='Intensity antigenomic bg',xlab='log2 expression')		#
abline(v=quantile(as.numeric(eset), prob=0.30), col='red')
dev.off()

# set NA to low expressed genes
eset.na <- eset
eset.na[is.small] <- NA
sum.na <- rowSums(apply(eset.na,2,is.na))
is.20 <- sum.na < 20
eset <- eset[is.20,]
anno.eset <- anno.eset[is.20,]
# 17487 transcript cluster remain!

# generate annotated eset matrix
samplenames <- sub(pattern='.CEL', replacement='',colnames(eset))
colnames(eset) <- samplenames
gene.ass <- do.call('rbind', strsplit(anno.eset[,8], split=' // '))
entrez.ass <-  do.call('rbind',strsplit(gene.ass[,5],split=' /// '))[,1]
entrez.ass[is.na(entrez.ass)] <- '---'
eset.os <- cbind(ID= rownames(eset), eset, anno.eset[,1:2], GeneID=entrez.ass, Symbol=gene.ass[,2], Description=gene.ass[,3], Chromosome=anno.eset[,3], Strand=anno.eset[,4],
		Start=anno.eset[,5],Stop=anno.eset[,6],Band=gene.ass[,4], Unigene=anno.eset[,10],
		NumProbes=anno.eset[,7],GO_bioprocess=anno.eset[,11],GO_cellcomponent=anno.eset[,12],GO_molfunction=anno.eset[,13],Pathway=anno.eset[,14])
write.table(eset.os, file='results/AffyEset/tables/Eset_OS.csv', col.names=TRUE, row.names=FALSE,quote=TRUE,sep=',')

# differential expression poor vs good responder
require('limma')
targets.prognosis <- targets[targets$mRNA==1&targets$miRNA==1&!is.na(targets$Prognosis),]
eset.response <- eset
sampleresponse <- targets.prognosis$Probe
sampleresponse[targets.prognosis$Prognosis=='Good'] <-  paste(sampleresponse[targets.prognosis$Prognosis=='Good'],'_good',sep='')
sampleresponse[targets.prognosis$Prognosis=='Poor'] <-  paste(sampleresponse[targets.prognosis$Prognosis=='Poor'],'_poor',sep='')
coleset <- sub('.CEL','',colnames(eset.response))
eset.response <- eset.response[,match(targets.prognosis$Probe,coleset)]
colnames(eset.response) <- sampleresponse
#
samples <- as.factor(targets.prognosis$Prognosis)
design <- model.matrix(~0 + samples)
colnames(design) <- levels(samples)
# fit linear model
fit1 <- lmFit(eset.response, design)
# gererate contrast matrix to indicate which samples should be compared
contrast <- makeContrasts('Poor - Good', levels=design)
fit2 <- contrasts.fit(fit1, contrast)
# run emprical bazes to estimate variance
fit.ebayes <- eBayes(fit2)
# run t.test to get differential expression results
response <- topTable(fit.ebayes, number=dim(eset.response)[1], adjust.method='BH')
idx.anno <- match(response$ID, eset.os[,1])
response <- cbind(response, eset.os[idx.anno,47:62])
save(response,eset.response, file='results/AffyEset/rd/DEGS_response.rd')
write.table(response, file='results/AffyEset/tables/DEGs_response.csv', row.names=FALSE, col.names=TRUE, sep=',',quote=TRUE)

# differential expression poor vs good responder
require('limma')
targets.metastasis <- targets[targets$mRNA==1&targets$miRNA==1&!is.na(targets$MetastasesPlus),]
eset.metastasis <- eset
samplemetastasis <- targets.metastasis$Probe
samplemetastasis[targets.metastasis$MetastasesPlus=='yes'] <-  paste(samplemetastasis[targets.metastasis$MetastasesPlus=='yes'],'_met',sep='')
samplemetastasis[targets.metastasis$MetastasesPlus=='no'] <-  paste(samplemetastasis[targets.metastasis$MetastasesPlus=='no'],'_non',sep='')
coleset <- sub('.CEL','',colnames(eset.metastasis))
eset.metastasis <- eset.metastasis[,match(targets.metastasis$Probe,coleset)]
colnames(eset.metastasis) <- samplemetastasis
#
samples <- as.factor(targets.metastasis$MetastasesPlus)
design <- model.matrix(~0 + samples)
colnames(design) <- levels(samples)
# fit linear model
fit1 <- lmFit(eset.metastasis, design)
# gererate contrast matrix to indicate which samples should be compared
contrast <- makeContrasts('yes - no', levels=design)
fit2 <- contrasts.fit(fit1, contrast)
# run emprical bazes to estimate variance
fit.ebayes <- eBayes(fit2)
# run t.test to get differential expression results
metastasis <- topTable(fit.ebayes, number=dim(eset.metastasis)[1], adjust.method='BH')
idx.anno <- match(metastasis$ID, eset.os[,1])
metastasis <- cbind(metastasis, eset.os[idx.anno,47:62])
save(metastasis,eset.metastasis, file='results/AffyEset/rd/DEGS_metastasis.rd')
write.table(metastasis, file='results/AffyEset/tables/DEGs_metastasis.csv', row.names=FALSE, col.names=TRUE, sep=',',quote=TRUE)
