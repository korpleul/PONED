# hub genes within network -- done
# GO terms per module
# hub gene per module -- done
# tables gistic results -- done
# tables for node attributes
# table alteration in which sample - matrix for picture
# local degree, global degree, p-val, FDR, correlation, cytoband 
# survival?
# Author: kathrin
###############################################################################

## figures GISTIC significant peaks
## figures modules with samples altered and GO?
## figures supplementaries null distributuions
## figure survival curve?
## tables gistic results and peaks
## ploidy correalted with age?, percent aberrant tumor associated with survival?

# memory
memory.limit(8000)

# required packages
require("graph")
require("BioNet")
require("igraph")
require("RBGL")
require("GOstats")
require("rbsurv")
require("survival")
library('org.Hs.eg.db')

# load data
load(file="rd/GISTIC_network.Rd")
# [1] "communitites" "fdr.linker"   "observed.mod" "p.linker"     "sig.nel"
hugo <- toTable(org.Hs.egSYMBOL2EG)
load(file='rd/HPDRrelease9.rd') # release 9
#	[1] "gistic.genes" "hprd.ids"     "ppi"          "ppi.nel"
eset <- read.table(file='results/AffyEset/tables/Eset_OS.csv', sep=',',header=T, stringsAsFactors=F)

# map genes on ppi
ppi.nodes <- nodes(ppi.nel)
ppi.nodes <- ppi.nodes[ppi.nodes!="-"]
ppi.nel <- (subNetwork(ppi.nodes, ppi.nel))

# network hub
global.degree <- graph::degree(sig.nel)
global.bin <- table(global.degree)[-1]
pdf(file="figures/NodeDegree_gistic.pdf")
plot(x=log2(as.numeric(names(global.bin))),y=log2(global.bin/sum(global.bin)),type='p',pch=20,col='darkgrey',xlab='node degree',ylab='Proportion of proteins',
		axes=FALSE,main='Node degree distributions \nand average node degrees')
xlabels <- c(1,2,5,10,20,50)
ylabels <- c(0.5,0.2,0.1,0.01,0.001,0.0001)
axis(1, at=log2(xlabels), labels=xlabels)
axis(2, at= log2(ylabels), labels=ylabels,las=2)
abline(v=log2(mean(global.degree)),col='blue',lwd=2)
text(x=log2(mean(global.degree)), y=log2(0.1),labels="average degree\n3.33", pos=4)
abline(v=log2(quantile(global.degree, probs = 0.95 )),col='red',lwd=2)
text(x=log2(quantile(global.degree, probs = 0.95 )), y=log2(0.1),labels=quantile(global.degree, probs = 0.95 ), pos=4)

dev.off()
#
global.hub <- cbind(GeneID=names(global.degree[global.degree>=quantile(global.degree, probs = 0.95 )]), Degree=global.degree[global.degree>=quantile(global.degree, probs = 0.95 )]) # 47 interactions
global.hub <- cbind(global.hub, Symbol=hugo$symbol[match(global.hub[,1],hugo$gene_id)])
write.table(global.hub, file="tables/HubGenes_gistic.csv", col.names=T, row.names=F, sep=";")

# get communitites
comm.networks <- list()
comm.genes <- list()
comm.hub <- list()
comm.inter <- list()
comm.modul <- list()
comm.size <- list()
comm.edges <- list()
for(i in unique(communitites$membership)){ # 26 modules
	comm.genes[[i]] <- communitites$names[communitites$membership==i]
	comm.networks[[i]] <-subNetwork(comm.genes[[i]] ,sig.nel, neighbors="none")
	names <- names(graph::degree(comm.networks[[i]]))[which.max(graph::degree(comm.networks[[i]]))]
	deg <- graph::degree(comm.networks[[i]])[which.max(graph::degree(comm.networks[[i]]))]
	comm.hub[[i]] <- c(names,deg)
	comm.inter[[i]] <- (length(edgeData(comm.networks[[i]]))/2)/numNodes(comm.networks[[i]])
	comm.modul[[i]] <- mean(communitites$modularity[communitites$membership==i])
	comm.size[[i]] <- length(comm.genes[[i]])
	comm.edges[[i]] <- length(edgeData(comm.networks[[i]]))/2
}
comm.hub <- do.call("rbind",comm.hub)
comm.hub <- cbind(Community=1:26, GeneID=comm.hub[,1], Degree=comm.hub[,2])
comm.hub <- cbind(comm.hub, Symbol=hugo$symbol[match(comm.hub[,2],hugo$gene_id)], MeanModularity=unlist(comm.modul), InterConnected=unlist(comm.inter), NumNodes=unlist(comm.size), NumEdges=unlist(comm.edges))
write.table(comm.hub, file="tables/HubGenes_community_gistic.csv", col.names=T, row.names=F, sep=";")
##
save(comm.genes, comm.networks, comm.hub, file="rd/Community_genesNetworks.Rd")
load(file="rd/Community_genesNetworks.Rd")

# save communitiy IDs for cytoscape
for(i in 1:26){
	write(comm.genes[[i]], file=paste("tables/cyto/module_",i,".txt",sep=""))
}
#####




# GO analysis for community members to define biological context
library("org.Hs.eg.db")
hgCutoff <- 0.5
entrez.universe <- unique(hugo$gene_id)
comm.bp <- list()
comm.mf <- list()
comm.cc <- list()
for(i in 1:length(comm.genes)){
	bp <- new("GOHyperGParams",
		 geneIds=comm.genes[[i]],
		 universeGeneIds=entrez.universe,
		 annotation="org.Hs.eg.db",
		 ontology="BP",
		 pvalueCutoff=hgCutoff,
		 conditional=FALSE,
		 testDirection="over")
 	hgOver <-  hyperGTest(bp)
	comm.bp[[i]] <- summary(hgOver)
 	mf <- new("GOHyperGParams",
		 geneIds=comm.genes[[i]],
		 universeGeneIds=entrez.universe,
		 annotation="org.Hs.eg.db",
		 ontology="MF",
		 pvalueCutoff=hgCutoff,
		 conditional=FALSE,
		testDirection="over")
hgOver <-  hyperGTest(mf)
comm.mf[[i]] <- summary(hgOver)
	cc <- new("GOHyperGParams",
		 geneIds=comm.genes[[i]],
		 universeGeneIds=entrez.universe,
		 annotation="org.Hs.eg.db",
		 ontology="CC",
		 pvalueCutoff=hgCutoff,
		 conditional=FALSE,
		 testDirection="over")
 hgOver <-  hyperGTest(cc)
 comm.cc[[i]] <- summary(hgOver)
}
save(comm.bp, comm.mf, comm.cc, file="rd/GOcommunities.Rd")

###
table.bp <- list()
for(i in 1:length(comm.bp)){
	fdr <- p.adjust(comm.bp[[i]]$Pvalue, method="fdr")
	idx.p <- fdr < 0.1
	if(sum(idx.p)!=0){
		table.bp[[i]] <- cbind(Module=paste("Module",i), comm.bp[[i]][idx.p,], FDR=fdr[idx.p])
	}else{
		table.bp[[i]] <- NULL
	}
}
table.bp <- do.call("rbind",table.bp)
write.table(table.bp, file="tables/GObp_communities.csv", col.names=T, row.names=F, sep=";")

## figure about frequency per sample and community
load(file="rd/ASCAT_CN_gistic.Rd")
gene.samples <- list()
pdf(file="figures/Module_sampleAlteration.pdf", height=5)
for(i in 1:length(comm.genes)){
	altered <- comm.genes[[i]][which(comm.genes[[i]]%in%rownames(ascat.gistic))]
	altered.sym <- hugo$symbol[match(altered,hugo$gene_id)]
	gene.samples[[i]] <- ascat.gistic[altered,]
	par(mgp=c(0.1,0.1,0.1), mar=c(1,6,5,1))
	plot(x=NA, xlim=c(1,dim(ascat.gistic)[2]), ylim=c(1,length(altered)), axes=FALSE, xlab="", ylab="", main=paste("Module",i))
	# Now set the plot region to grey
	rect(par("usr")[1], par("usr")[3], par("usr")[2], par("usr")[4], col = 
					"grey")
	for(j in 1:length(altered)){
		x.del <- which(gene.samples[[i]][j,]==-1)
		x.amp <- which(gene.samples[[i]][j,]==1)
		if(length(x.del)!=0){
			points(x=x.del, y=rep(j, times=length(x.del)), pch=19,col="darkgreen")
			x.del <- NULL
		}
		if(length(x.amp)!=0){
			points(x=x.amp, y=rep(j, times=length(x.amp)), pch=19,col="red")
			x.amp <- NULL
		}
	}
	y.grid <- seq(1.5,length(altered),1)
	x.grid <- seq(1.4, 41, 1)
	abline(h=y.grid, col="white")
	abline(v=x.grid, col="white")
	axis(side=2, at=1:length(altered), labels=altered.sym, las=2, tick=F, cex.axis=0.6)
	axis(side=3, at=1:41, colnames(ascat.gistic), las=2, tick=F, cex.axis=0.6)
	box()
}
dev.off()

# node attributes altered %, direction
nodes <- nodes(sig.nel)
idx.gistic <- match(nodes, rownames(ascat.gistic))
#> sum(!is.na(idx.gistic))
#[1] 254
nodes.altered <- cbind(nodes, "=", "NA")
nodes.altered[is.na(idx.gistic),3] <- "0.0000"
freq <- rowSums(ascat.gistic != 0)/41
nodes.altered[!is.na(idx.gistic),3] <- freq[idx.gistic[!is.na(idx.gistic)]]
nodes.dir <- cbind(nodes, "=", "NA")
nodes.dir[is.na(idx.gistic),3] <- "no"
direction <- rep("no",times=dim(ascat.gistic)[1])
direction[rowSums(ascat.gistic)<0] <- "del"
direction[rowSums(ascat.gistic)>0] <- "amp"
nodes.dir[!is.na(idx.gistic),3] <- direction[idx.gistic[!is.na(idx.gistic)]]
write.table(nodes.altered, file="tables/cyto/alterFreq.NA", sep=" ", row.names=F, col.names=F)
write.table(nodes.dir, file="tables/cyto/alterDirection.NA", sep=" ", row.names=F, col.names=F)

# survival
# survival analysis crteria: metastases!
load(file="rd/ASCAT_CN_gistic.Rd")

targets <- read.table(file="ASCAT2.1/targets.csv", header=T, sep=";", stringsAsFactors=F)
targets <- targets[targets$Probe%in%colnames(ascat.gistic),] # 37
ascat.gistic <- ascat.gistic[,targets$Probe]
status <- targets$RIP # 37
status[status=="yes"] <- 1
status[status=="no"] <- 0
status <- as.numeric(status)
months <- targets$FollowupMonths
samples <- targets$Probe
mets <- targets$Metastases
mets[mets=="yes"] <- 1
mets[mets=="no"] <- 0
mets <- as.numeric(mets)
mets.diag <- targets$MetsDiagnosis
mets.diag[mets.diag=="1" | mets.diag=="2"] <- 1
mets.diag[mets.diag!="1"] <- 0
mets.diag[is.na(mets.diag)] <- 0
mets.diag <- as.numeric(mets.diag)
#ploidy.status <- ploidy >= 3

#
d <- data.frame(samples=samples,status=status,months=months,mets=mets,mets.diag=mets.diag) #, ploidy=ploidy.status)
### hub genes survival
# mod 1
genes <- comm.genes[[1]]
genes <- genes[genes%in%rownames(ascat.gistic)]
alter.comm <- ascat.gistic[genes[c(1,5)], ]
hub.st <-  colSums(alter.comm) != 0 #OR (alter.comm) != 0
os <- survfit(os.surv ~ hub.st)
hub.surv <- survdiff(os.surv ~ hub.st)
pdf(file="figures/surv/Module1_survival.pdf")
plot(os, lty = 1, col = c("gray", "green"), main="Module 1 - MAPK9 & MAP3K5")
legend("bottomleft", legend = c("neutral", "deleted"), lty = 1:2, col = c("gray", "green"), box.col="white",box.lwd=0)
legend("bottomright", legend = "Chi-square p-value = 0.0456", box.col="white",box.lwd=0)
box()
dev.off()

# mod 2
genes <- comm.genes[[2]]
genes <- genes[genes%in%rownames(ascat.gistic)]
alter.comm <- ascat.gistic[genes[c(6)], ]
hub.st <-  colSums(alter.comm) != 0 #OR 
hub.st <- (alter.comm) != 0
os <- survfit(os.surv ~ hub.st)
hub.surv <- survdiff(os.surv ~ hub.st)
pdf(file="figures/surv/Module2_survival.pdf")
plot(os, lty = 1, col = c("gray", "green"), main="Module 2 - EZR")
legend("bottomleft", legend = c("neutral", "deleted"), lty = 1:2, col = c("gray", "green"), box.col="white",box.lwd=0)
legend("bottomright", legend = "Chi-square p-value = 0.0385", box.col="white",box.lwd=0)
box()
dev.off()

# mod 3 no found
genes <- comm.genes[[3]]
genes <- genes[genes%in%rownames(ascat.gistic)]
alter.comm <- ascat.gistic[genes[c(2,9)], ]
hub.st <-  colSums(alter.comm) != 0 #OR 
hub.st <- (alter.comm) != 0
os <- survfit(os.surv ~ hub.st)
hub.surv <- survdiff(os.surv ~ hub.st)
pdf(file="figures/surv/Module2_survival.pdf")
plot(os, lty = 1, col = c("green", "gray"), main="Module 2 - EZR")
legend("bottomleft", legend = c("neutral", "deleted"), lty = 1:2, col = c("gray", "green"), box.col="white",box.lwd=0)
legend("bottomright", legend = "Chi-square p-value = 0.0385", box.col="white",box.lwd=0)
box()
dev.off()
# mod 4
genes <- comm.genes[[4]]
genes <- genes[genes%in%rownames(ascat.gistic)]
alter.comm <- ascat.gistic[genes[c(2)], ]
hub.st <-  colSums(alter.comm) != 0 #OR 
hub.st <- (alter.comm) != 0
os <- survfit(os.surv ~ hub.st)
hub.surv <- survdiff(os.surv ~ hub.st)
pdf(file="figures/surv/Module4_survival.pdf")
plot(os, lty = 1, col = c("gray", "green"), main="Module 4 - EEF1A1")
legend("bottomleft", legend = c("neutral", "deleted"), lty = 1:2, col = c("gray", "green"), box.col="white",box.lwd=0)
legend("bottomright", legend = "Chi-square p-value = 0.0122", box.col="white",box.lwd=0)
box()
dev.off()

# mod 5
genes <- comm.genes[[5]]
genes <- genes[genes%in%rownames(ascat.gistic)]
alter.comm <- ascat.gistic[genes[c(2)], ]
hub.st <-  colSums(alter.comm) != 0 #OR 
hub.st <- (alter.comm) != 0
os <- survfit(os.surv ~ hub.st)
hub.surv <- survdiff(os.surv ~ hub.st)
pdf(file="figures/surv/Module5_survival.pdf")
plot(os, lty = 1, col = c("gray", "green"), main="Module 5 - UBE3A")
legend("bottomleft", legend = c("neutral", "deleted"), lty = 1:2, col = c("gray", "green"), box.col="white",box.lwd=0)
legend("bottomright", legend = "Chi-square p-value = 0.0398", box.col="white",box.lwd=0)
box()
dev.off()


# mod 6 no
genes <- comm.genes[[6]]
genes <- genes[genes%in%rownames(ascat.gistic)]
alter.comm <- ascat.gistic[genes[c(9)], ]
hub.st <-  colSums(alter.comm) != 0 #OR 
hub.st <- (alter.comm) != 0
os <- survfit(os.surv ~ hub.st)
hub.surv <- survdiff(os.surv ~ hub.st)
pdf(file="figures/surv/Module5_survival.pdf")
plot(os, lty = 1, col = c("green", "gray"), main="Module 5 - UBE3A")
legend("bottomleft", legend = c("neutral", "deleted"), lty = 1:2, col = c("gray", "green"), box.col="white",box.lwd=0)
legend("bottomright", legend = "Chi-square p-value = 0.0398", box.col="white",box.lwd=0)
box()
dev.off()

# mod 7 
genes <- comm.genes[[7]]
genes <- genes[genes%in%rownames(ascat.gistic)]
alter.comm <- ascat.gistic[genes[c(2,6)], ]
hub.st <-  colSums(alter.comm) != 0 #OR 
hub.st <- (alter.comm) != 0
os <- survfit(os.surv ~ hub.st)
hub.surv <- survdiff(os.surv ~ hub.st)
pdf(file="figures/surv/Module7_survival.pdf")
plot(os, lty = 1, col = c("gray", "green"), main="Module 7 - DLL1 & ADAM10")
legend("bottomleft", legend = c("neutral", "deleted"), lty = 1:2, col = c("gray", "green"), box.col="white",box.lwd=0)
legend("bottomright", legend = "Chi-square p-value = 0.04", box.col="white",box.lwd=0)
box()
dev.off()

# mod 8 
genes <- comm.genes[[8]]
genes <- genes[genes%in%rownames(ascat.gistic)]
alter.comm <- ascat.gistic[genes[c(1,8)], ]
hub.st <-  colSums(alter.comm) != 0 #OR 
hub.st <- (alter.comm) != 0
os <- survfit(os.surv ~ hub.st)
hub.surv <- survdiff(os.surv ~ hub.st)
pdf(file="figures/surv/Module7_survival.pdf")
plot(os, lty = 1, col = c("gray", "green"), main="Module 7 - DLL1 & ADAM10")
legend("bottomleft", legend = c("neutral", "deleted"), lty = 1:2, col = c("gray", "green"), box.col="white",box.lwd=0)
legend("bottomright", legend = "Chi-square p-value = 0.04", box.col="white",box.lwd=0)
box()
dev.off()
# mod 9 
genes <- comm.genes[[9]]
genes <- genes[genes%in%rownames(ascat.gistic)]
alter.comm <- ascat.gistic[genes[c(9,10)], ]
hub.st <-  colSums(alter.comm) != 0 #OR 
hub.st <- (alter.comm) != 0
os <- survfit(os.surv ~ hub.st)
hub.surv <- survdiff(os.surv ~ hub.st)
pdf(file="figures/surv/Module7_survival.pdf")
plot(os, lty = 1, col = c("gray", "green"), main="Module 7 - DLL1 & ADAM10")
legend("bottomleft", legend = c("neutral", "deleted"), lty = 1:2, col = c("gray", "green"), box.col="white",box.lwd=0)
legend("bottomright", legend = "Chi-square p-value = 0.04", box.col="white",box.lwd=0)
box()
dev.off()
# mod 10 
genes <- comm.genes[[10]]
genes <- genes[genes%in%rownames(ascat.gistic)]
alter.comm <- ascat.gistic[genes[c(5,4)], ]
hub.st <-  colSums(alter.comm) != 0 #OR 
hub.st <- (alter.comm) != 0
os <- survfit(os.surv ~ hub.st)
hub.surv <- survdiff(os.surv ~ hub.st)
pdf(file="figures/surv/Module7_survival.pdf")
plot(os, lty = 1, col = c("gray", "green"), main="Module 7 - DLL1 & ADAM10")
legend("bottomleft", legend = c("neutral", "deleted"), lty = 1:2, col = c("gray", "green"), box.col="white",box.lwd=0)
legend("bottomright", legend = "Chi-square p-value = 0.04", box.col="white",box.lwd=0)
box()
dev.off()
# mod 11 
genes <- comm.genes[[11]]
genes <- genes[genes%in%rownames(ascat.gistic)]
alter.comm <- ascat.gistic[genes, ]
hub.st <-  colSums(alter.comm) != 0 #OR 
hub.st <- (alter.comm) != 0
os <- survfit(os.surv ~ hub.st)
hub.surv <- survdiff(os.surv ~ hub.st)
pdf(file="figures/surv/Module7_survival.pdf")
plot(os, lty = 1, col = c("gray", "green"), main="Module 7 - DLL1 & ADAM10")
legend("bottomleft", legend = c("neutral", "deleted"), lty = 1:2, col = c("gray", "green"), box.col="white",box.lwd=0)
legend("bottomright", legend = "Chi-square p-value = 0.04", box.col="white",box.lwd=0)
box()
dev.off()
# mod 12
genes <- comm.genes[[12]]
genes <- genes[genes%in%rownames(ascat.gistic)]
alter.comm <- ascat.gistic[genes[c(2,3)], ]
hub.st <-  colSums(alter.comm) != 0 #OR 
hub.st <- (alter.comm) != 0
os <- survfit(os.surv ~ hub.st)
hub.surv <- survdiff(os.surv ~ hub.st)
pdf(file="figures/surv/Module7_survival.pdf")
plot(os, lty = 1, col = c("gray", "green"), main="Module 7 - DLL1 & ADAM10")
legend("bottomleft", legend = c("neutral", "deleted"), lty = 1:2, col = c("gray", "green"), box.col="white",box.lwd=0)
legend("bottomright", legend = "Chi-square p-value = 0.04", box.col="white",box.lwd=0)
box()
dev.off()
# mod 13 
genes <- comm.genes[[13]]
genes <- genes[genes%in%rownames(ascat.gistic)]
alter.comm <- ascat.gistic[genes[c(9)], ]
hub.st <-  colSums(alter.comm) != 0 #OR 
hub.st <- (alter.comm) != 0
os <- survfit(os.surv ~ hub.st)
hub.surv <- survdiff(os.surv ~ hub.st)
pdf(file="figures/surv/Module7_survival.pdf")
plot(os, lty = 1, col = c("gray", "green"), main="Module 7 - DLL1 & ADAM10")
legend("bottomleft", legend = c("neutral", "deleted"), lty = 1:2, col = c("gray", "green"), box.col="white",box.lwd=0)
legend("bottomright", legend = "Chi-square p-value = 0.04", box.col="white",box.lwd=0)
box()
dev.off()
# mod 14 
genes <- comm.genes[[14]]
genes <- genes[genes%in%rownames(ascat.gistic)]
alter.comm <- ascat.gistic[genes, ]
hub.st <-  colSums(alter.comm) != 0 #OR 
hub.st <- (alter.comm) != 0
os <- survfit(os.surv ~ hub.st)
hub.surv <- survdiff(os.surv ~ hub.st)
pdf(file="figures/surv/Module7_survival.pdf")
plot(os, lty = 1, col = c("gray", "green"), main="Module 7 - DLL1 & ADAM10")
legend("bottomleft", legend = c("neutral", "deleted"), lty = 1:2, col = c("gray", "green"), box.col="white",box.lwd=0)
legend("bottomright", legend = "Chi-square p-value = 0.04", box.col="white",box.lwd=0)
box()
dev.off()
# mod 15 
genes <- comm.genes[[15]]
genes <- genes[genes%in%rownames(ascat.gistic)]
alter.comm <- ascat.gistic[genes[c(1)], ]
hub.st <-  colSums(alter.comm) != 0 #OR 
hub.st <- (alter.comm) != 0
os <- survfit(os.surv ~ hub.st)
hub.surv <- survdiff(os.surv ~ hub.st)
pdf(file="figures/surv/Module15_survival.pdf")
plot(os, lty = 1, col = c("gray", "green"), main="Module 15 - TCP1")
legend("bottomleft", legend = c("neutral", "deleted"), lty = 1:2, col = c("gray", "green"), box.col="white",box.lwd=0)
legend("bottomright", legend = "Chi-square p-value = 0.0385", box.col="white",box.lwd=0)
box()
dev.off()
# mod 16 
genes <- comm.genes[[16]]
genes <- genes[genes%in%rownames(ascat.gistic)]
alter.comm <- ascat.gistic[genes[c(5)], ]
hub.st <-  colSums(alter.comm) != 0 #OR 
hub.st <- (alter.comm) != 0
os <- survfit(os.surv ~ hub.st)
hub.surv <- survdiff(os.surv ~ hub.st)
pdf(file="figures/surv/Module15_survival.pdf")
plot(os, lty = 1, col = c("gray", "green"), main="Module 15 - TCP1")
legend("bottomleft", legend = c("neutral", "deleted"), lty = 1:2, col = c("gray", "green"), box.col="white",box.lwd=0)
legend("bottomright", legend = "Chi-square p-value = 0.0385", box.col="white",box.lwd=0)
box()
dev.off()
# mod 17 
genes <- comm.genes[[17]]
genes <- genes[genes%in%rownames(ascat.gistic)]
alter.comm <- ascat.gistic[genes[c(4)], ]
hub.st <-  colSums(alter.comm) != 0 #OR 
hub.st <- (alter.comm) != 0
os <- survfit(os.surv ~ hub.st)
hub.surv <- survdiff(os.surv ~ hub.st)
pdf(file="figures/surv/Module17_survival.pdf")
plot(os, lty = 1, col = c("gray", "green"), main="Module 17 - CDKN2A")
legend("bottomleft", legend = c("neutral", "deleted"), lty = 1:2, col = c("gray", "green"), box.col="white",box.lwd=0)
legend("bottomright", legend = "Chi-square p-value = 0.0202", box.col="white",box.lwd=0)
box()
dev.off()
# mod 18 
genes <- comm.genes[[18]]
genes <- genes[genes%in%rownames(ascat.gistic)]
alter.comm <- ascat.gistic[genes[c(1)], ]
hub.st <-  colSums(alter.comm) != 0 #OR 
hub.st <- (alter.comm) != 0
os <- survfit(os.surv ~ hub.st)
hub.surv <- survdiff(os.surv ~ hub.st)
pdf(file="figures/surv/Module18_survival.pdf")
plot(os, lty = 1, col = c("gray", "green"), main="Module 18 - IGF2R")
legend("bottomleft", legend = c("neutral", "deleted"), lty = 1:2, col = c("gray", "green"), box.col="white",box.lwd=0)
legend("bottomright", legend = "Chi-square p-value = 0.0385", box.col="white",box.lwd=0)
box()
dev.off()

# mod 19 
genes <- comm.genes[[19]]
genes <- genes[genes%in%rownames(ascat.gistic)]
alter.comm <- ascat.gistic[genes[c(4)], ]
hub.st <-  colSums(alter.comm) != 0 #OR 
hub.st <- (alter.comm) != 0
os <- survfit(os.surv ~ hub.st)
hub.surv <- survdiff(os.surv ~ hub.st)
pdf(file="figures/surv/Module18_survival.pdf")
plot(os, lty = 1, col = c("gray", "green"), main="Module 18 - IGF2R")
legend("bottomleft", legend = c("neutral", "deleted"), lty = 1:2, col = c("gray", "green"), box.col="white",box.lwd=0)
legend("bottomright", legend = "Chi-square p-value = 0.0385", box.col="white",box.lwd=0)
box()
dev.off()

# mod 20 
genes <- comm.genes[[20]]
genes <- genes[genes%in%rownames(ascat.gistic)]
alter.comm <- ascat.gistic[genes[c(3)], ]
hub.st <-  colSums(alter.comm) != 0 #OR 
hub.st <- (alter.comm) != 0
os <- survfit(os.surv ~ hub.st)
hub.surv <- survdiff(os.surv ~ hub.st)
pdf(file="figures/surv/Module20_survival.pdf")
plot(os, lty = 1, col = c("gray", "green"), main="Module 20 - ANXA11")
legend("bottomleft", legend = c("neutral", "deleted"), lty = 1:2, col = c("gray", "green"), box.col="white",box.lwd=0)
legend("bottomright", legend = "Chi-square p-value = 0.0385", box.col="white",box.lwd=0)
box()
dev.off()
# mod 21 
genes <- comm.genes[[21]]
genes <- genes[genes%in%rownames(ascat.gistic)]
alter.comm <- ascat.gistic[genes[c(1,2)], ]
hub.st <-  colSums(alter.comm) != 0 #OR 
hub.st <- (alter.comm) != 0
os <- survfit(os.surv ~ hub.st)
hub.surv <- survdiff(os.surv ~ hub.st)
pdf(file="figures/surv/Module18_survival.pdf")
plot(os, lty = 1, col = c("gray", "green"), main="Module 18 - IGF2R")
legend("bottomleft", legend = c("neutral", "deleted"), lty = 1:2, col = c("gray", "green"), box.col="white",box.lwd=0)
legend("bottomright", legend = "Chi-square p-value = 0.0385", box.col="white",box.lwd=0)
box()
dev.off()
# mod 22
genes <- comm.genes[[22]]
genes <- genes[genes%in%rownames(ascat.gistic)]
alter.comm <- ascat.gistic[genes[c(1)], ]
hub.st <-  colSums(alter.comm) != 0 #OR 
hub.st <- (alter.comm) != 0
os <- survfit(os.surv ~ hub.st)
hub.surv <- survdiff(os.surv ~ hub.st)
pdf(file="figures/surv/Module18_survival.pdf")
plot(os, lty = 1, col = c("gray", "green"), main="Module 18 - IGF2R")
legend("bottomleft", legend = c("neutral", "deleted"), lty = 1:2, col = c("gray", "green"), box.col="white",box.lwd=0)
legend("bottomright", legend = "Chi-square p-value = 0.0385", box.col="white",box.lwd=0)
box()
dev.off()
# mod 23
genes <- comm.genes[[23]]
genes <- genes[genes%in%rownames(ascat.gistic)]
alter.comm <- ascat.gistic[genes[c(8)], ]
hub.st <-  colSums(alter.comm) != 0 #OR 
hub.st <- (alter.comm) != 0
os <- survfit(os.surv ~ hub.st)
hub.surv <- survdiff(os.surv ~ hub.st)
pdf(file="figures/surv/Module23_survival.pdf")
plot(os, lty = 1, col = c("gray", "green"), main="Module 23 - SHPRH")
legend("bottomleft", legend = c("neutral", "deleted"), lty = 1:2, col = c("gray", "green"), box.col="white",box.lwd=0)
legend("bottomright", legend = "Chi-square p-value = 0.0456", box.col="white",box.lwd=0)
box()
dev.off()
# mod 24
genes <- comm.genes[[24]]
genes <- genes[genes%in%rownames(ascat.gistic)]
alter.comm <- ascat.gistic[genes[c(2)], ]
hub.st <-  colSums(alter.comm) != 0 #OR 
hub.st <- (alter.comm) != 0
os <- survfit(os.surv ~ hub.st)
hub.surv <- survdiff(os.surv ~ hub.st)
pdf(file="figures/surv/Module23_survival.pdf")
plot(os, lty = 1, col = c("gray", "green"), main="Module 23 - SHPRH")
legend("bottomleft", legend = c("neutral", "deleted"), lty = 1:2, col = c("gray", "green"), box.col="white",box.lwd=0)
legend("bottomright", legend = "Chi-square p-value = 0.0456", box.col="white",box.lwd=0)
box()
dev.off()
# mod 25
genes <- comm.genes[[25]]
genes <- genes[genes%in%rownames(ascat.gistic)]
alter.comm <- ascat.gistic[genes[c(4)], ]
hub.st <-  colSums(alter.comm) != 0 #OR 
hub.st <- (alter.comm) != 0
os <- survfit(os.surv ~ hub.st)
hub.surv <- survdiff(os.surv ~ hub.st)
pdf(file="figures/surv/Module23_survival.pdf")
plot(os, lty = 1, col = c("gray", "green"), main="Module 23 - SHPRH")
legend("bottomleft", legend = c("neutral", "deleted"), lty = 1:2, col = c("gray", "green"), box.col="white",box.lwd=0)
legend("bottomright", legend = "Chi-square p-value = 0.0456", box.col="white",box.lwd=0)
box()
dev.off()
# mod 26
genes <- comm.genes[[26]]
genes <- genes[genes%in%rownames(ascat.gistic)]
alter.comm <- ascat.gistic[genes[c(1,2)], ]
hub.st <-  colSums(alter.comm) != 0 #OR 
hub.st <- (alter.comm) != 0
os <- survfit(os.surv ~ hub.st)
hub.surv <- survdiff(os.surv ~ hub.st)
pdf(file="figures/surv/Module23_survival.pdf")
plot(os, lty = 1, col = c("gray", "green"), main="Module 23 - SHPRH")
legend("bottomleft", legend = c("neutral", "deleted"), lty = 1:2, col = c("gray", "green"), box.col="white",box.lwd=0)
legend("bottomright", legend = "Chi-square p-value = 0.0456", box.col="white",box.lwd=0)
box()
dev.off()



os.surv <- Surv(d$months, d$status)
os.hub <- list()
hub.surv <- list()
mod.idx <- c(1:5, 8,9,13,16,17,19,20)
for(i in 1:length(mod.idx)){
	x <- hub.status[which(eset.id%in%comm.genes[[mod.idx[i]]]),]
	
	hub.st <- hub.status[i,] != 0
	os.hub[[i]] <- survfit(os.surv ~ hub.st)
	hub.surv[[i]] <- survdiff(os.surv ~ hub.st)
}
#Call:
#		survdiff(formula = os.surv ~ mets, data = d)
#N Observed Expected (O-E)^2/E (O-E)^2/V
#mets=0 28        0     7.37      7.37      22.8
#mets=1 16       11     3.63     14.98      22.8
#Chisq= 22.8  on 1 degrees of freedom, p= 1.78e-06 <--- p-value!
#Call:
#		survdiff(formula = os.surv ~ ploidy, data = d)
#N Observed Expected (O-E)^2/E (O-E)^2/V
#ploidy=FALSE 23        3     5.53      1.15      3.75
#ploidy=TRUE  14        5     2.47      2.58      3.75
#Chisq= 3.8  on 1 degrees of freedom, p= 0.0527  , 3.4 == 0.00843

pdf(file="figures/survival_ModHubs.pdf")
plot(os.hub[[8]], lty = 1, col = c("darkblue", "darkred"), main="CDKN2A")
legend("bottomleft", legend = c("neutral", "deleted"), lty = 1:2, col = c("darkblue", "darkred"), box.col="white",box.lwd=0)
box()
plot(os.hub[[15]], lty = 1, col = c("darkblue", "darkred"), main="UBE3A")
legend("bottomleft", legend = c("neutral", "deleted"), lty = 1:2, col = c("darkblue", "darkred"), box.col="white",box.lwd=0)
box()
dev.off()











