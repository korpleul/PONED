# Understanding 1 the genetic complexity of osteosarcoma by a network approach
# Poos et al., submitted, 2014 
#
# Author: kathrin
###############################################################################

## set working directory to OSsamples_genomicAlterations directory
setwd("../OSsamples_genomicAlterations")

## run ASCAT to recieve chromosomal regions of copy number gains and losses
# 1. data were pre-processed using PennCNV affy (for details see http://www.openbioinformatics.org/penncnv/penncnv_tutorial_affy_gw6.html) to recieve LRR and BAF  values from Affy SNP chips, data are stored in the data/SNP/ dir.
# 2. ASCAT was run to compute CNV segments of the samples
source("runASCAT.R")

## run GISTIC 2.0 using the ASPCF segmented data from ASCAT, files are stored in firectory GISTIC.
## Parameters LRR +/- 0.12 and at least 10 consecutive SNP markers

## Next correlate genes within GISTIC regions with corresponding expression
# 1. normalize expression data from Affy HuGene1ST
source("main_affyEset.R")
# 2. determine genes within GISTIC regions and correlate LRR with with expression data
source("gisticGenes.R")

## Generate network
source("pathwayGistic.R")

## Annotate network for visulaization within cytoscape and functional annotation
source("networkAnnotation.R")

## Visualize within Cytoscape!!
